'use strict';
// Development page only; never loaded by production Home. Learning writes stay
// on the isolated preview origin through the existing LearningEngine adapter.
(()=>{
 const $=id=>document.getElementById(id),field=$('field'),world=$('world');
 const engine=new MeteorPhysics.Engine(),learning=window.MeteorLearning.create();let frame=null,last=null,accumulator=0,pointer=null,rect=null,language=learning.language,disposed=false,wrongUntil=0,kickUntil=0,bank=0,visualX=0,shieldUntil=0,epoch=0,lastWrong=null;
 const audio=window.MeteorAudio.create({onInterrupted:()=>pause('audio-interruption')});
 const corpses=new Map();
 // Decorative tiers use measured field dimensions, never device or answer state.
 const effectDetail=()=>reducedMotion?'reduced':engine.width<600||engine.height<400?'compact':'full';
 // Interlocking partitions cover the original body. Each piece carries the
 // complete original rock material/silhouette beneath its own fracture mask.
 const cuts=[
  'polygon(0 0,52% 0,49% 25%,57% 35%,46% 51%,25% 46%,0 53%)',
  'polygon(52% 0,100% 0,100% 53%,75% 57%,65% 47%,46% 51%,57% 35%,49% 25%)',
  'polygon(0 53%,25% 46%,46% 51%,53% 72%,44% 100%,0 100%)',
  'polygon(46% 51%,65% 47%,75% 57%,100% 53%,100% 100%,44% 100%,53% 72%)'
 ];
 const removers=[],nodes={meteors:new Map(),projectiles:new Map(),effects:new Map()};
 const text=(th,en)=>language==='th'?th:en;
 const reducedMotion=window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches||false;
 let camera=null;
 function view(){if(!camera||camera.width!==engine.width||camera.danger!==engine.danger)camera=MeteorProjection.create(engine.width,engine.danger);return camera;}
 const listen=(node,type,fn,options)=>{node.addEventListener(type,fn,options);removers.push(()=>node.removeEventListener(type,fn,options));};
 function release(){const id=pointer?.id;pointer=null;if(id!==undefined)try{if(world.hasPointerCapture(id))world.releasePointerCapture(id);}catch{}}
 function cancelFrame(){epoch++;if(frame!==null)cancelAnimationFrame(frame);frame=last=null;accumulator=0;}
 function measure(){rect=field.getBoundingClientRect();return {width:rect.width,height:rect.height};}
 function stopSpeech(){learning.cancelSpeech();audio.speech(false);}
 function resize(){if(disposed)return;const size=measure();if(Math.abs(size.width-engine.width)<1&&Math.abs(size.height-engine.height)<1)return;release();cancelFrame();stopSpeech();audio.pause();engine.resize(size.width,size.height);corpses.clear();bank=0;visualX=engine.ufo.x;render();}
 function sync(kind,items,draw){
  const map=nodes[kind],root=$(kind),alive=new Set(items.map(item=>item.id));
  for(const [id,node] of map)if(!alive.has(id)){node.remove();map.delete(id);}
  for(const item of items){let node=map.get(item.id);if(!node){node=document.createElement('div');node.className=kind==='meteors'?'meteor':kind==='projectiles'?'projectile':'effect '+item.kind;root.append(node);map.set(item.id,node);}draw(node,item);}
 }
 function render(){
  const camera=view();
  const parallax=(reducedMotion?0:(engine.ufo.x-engine.width/2)*-.025)+'px';
  if($('scene').style.getPropertyValue?.('--parallax-x')!==parallax)$('scene').style.setProperty('--parallax-x',parallax);
  field.dataset.phase=engine.phase;
  $('danger').style.top=engine.danger+'px';field.dataset.threat=String(engine.phase==='ACTIVE'&&engine.meteors.some(m=>m.alive&&m.y+m.r>engine.danger-engine.radius*2));$('flight-zone').style.top=engine.bounds.top+'px';
  $('ufo').style.transform=`translate(${engine.ufo.x-30}px,${engine.ufo.y-17}px)`;
  $('ufo').style.setProperty('--thrust-room',Math.max(10,engine.height-engine.ufo.y-6)+'px');$('ufo').style.setProperty('--bank',reducedMotion?'0deg':bank+'deg');$('ufo').style.setProperty('--drive',String(reducedMotion?0:Math.min(1,Math.abs(bank)/8)));field.dataset.thrust=String(Math.abs(bank)>.5);
  $('shield').dataset.hit=String(engine.time<shieldUntil);$('combo').dataset.pulse=String(engine.effects.some(e=>e.kind==='correct'&&e.life<=.34&&e.life>=.1));$('score').dataset.pulse=$('combo').dataset.pulse;
  // Existing result/transition state drives emphasis; it never gates input.
  const milestone=String(engine.combo>0&&engine.combo%5===0&&$('combo').dataset.pulse==='true'),advance=String(engine.phase==='FEEDBACK'&&engine.reason==='correct');
  if($('combo').dataset.milestone!==milestone)$('combo').dataset.milestone=milestone;
  if($('wave').dataset.advance!==advance)$('wave').dataset.advance=advance;
  $('shield').textContent=text('เกราะ ','Shield ')+('◆'.repeat(engine.shield)+'◇'.repeat(3-engine.shield));
  $('score').textContent=text('คะแนน ','Score ')+engine.score;$('combo').textContent='COMBO '+engine.combo;$('wave').textContent='WAVE '+engine.wave;
  const correctEffect=engine.effects.find(e=>e.kind==='correct'&&e.life<=.46),correctPose=correctEffect&&corpses.get(correctEffect.id);
  $('prompt').dataset.feedback=String(!!correctPose?.result);$('prompt').textContent=correctPose?.result?learning.resultText(correctPose.result):learning.prompt();
  $('language').textContent=language==='th'?'EN':'ไทย';$('pause').textContent=text('พัก','Pause');$('exit').textContent=text('ออก','Exit');$('home').textContent=text('กลับ Home','Return to Home');
  for(const key of ['music','sfx']){$(key).textContent=key.toUpperCase()+' · '+(audio[key]?'ON':'OFF');$(key).setAttribute('aria-pressed',String(audio[key]));}
  $('audio-status').textContent=audio.state.failed?text('เสียงไม่พร้อมใช้งาน · ลองเล่นต่ออีกครั้ง','Audio unavailable · try Resume again'):'';
  $('fire').disabled=engine.phase!=='ACTIVE';$('pause').disabled=!['ACTIVE','FEEDBACK','GAME_OVER'].includes(engine.phase);$('level').disabled=!['READY','GAME_OVER','EXITING'].includes(engine.phase);
  sync('meteors',engine.meteors.filter(m=>m.alive),(node,m)=>{
    if(!node.children.length){
      const trail=document.createElement('span'),rock=document.createElement('span'),label=document.createElement('span'),hanzi=document.createElement('b'),pinyin=document.createElement('span');
      trail.className='meteor-trail';rock.className='meteor-rock';label.className='meteor-label';
      hanzi.className='meteor-hanzi';hanzi.lang='zh-CN';pinyin.className='meteor-pinyin';pinyin.lang='zh-Latn';
      label.append(hanzi);label.append(pinyin);node.append(trail);node.append(rock);node.append(label);
    }
    const answer=learning.answer(m.label),label=node.children[2],zh=answer?.zh||m.label,py=answer?.py||'',position=camera.point(m.x,m.y),available=m.r*2-10;
    label.style.width=(available+10)+'px';label.style.transform=camera.billboard(m.x-m.r,m.y-m.r,position.x,position.y,available+10);
    label.children[0].textContent=zh;label.children[1].textContent=py;label.dataset.length=String([...zh].length);
    // Screen-space text stays readable; only the camera projects the rock.
    label.style.setProperty('--hanzi-fit',available/Math.max(1,[...zh].length)+'px');
    label.style.setProperty('--pinyin-size',Math.max(11,Math.min(12,available/(Math.max(1,[...py].length)*.62)))+'px');
    node.setAttribute('aria-label',answer?`${answer.zh}, ${answer.py}`:m.label);node.style.setProperty('--spin',reducedMotion?'0deg':(Math.sin(engine.time*.7+m.id)*9)+'deg');node.dataset.tone=String(m.slot);node.style.setProperty('--drift',(reducedMotion?0:Math.atan2(m.vx,m.vy)*180/Math.PI)+'deg');node.dataset.near=String(m.y+m.r>engine.danger-engine.radius*2);node.style.width=node.style.height=m.r*2+'px';node.style.transform=camera.transform(m.x-m.r,m.y-m.r,m.y);
  });
  sync('projectiles',engine.projectiles,(node,p)=>{node.style.transform=camera.transform(p.x-5,p.y-3,p.y);});
  // Engine effect lifetime owns presentation. Death proxies have no collider/input.
  const livingEffects=new Set(engine.effects.map(e=>e.id));
  for(const id of corpses.keys())if(!livingEffects.has(id))corpses.delete(id);
  let shakeX=0,shakeY=0;
  sync('effects',engine.effects,(node,e)=>{const small=e.kind==='muzzle',size=small?36:108,total=small?.12:.6,age=Math.max(0,total-e.life);
   if(small&&!node.children.length){
    node.dataset.detail=effectDetail();
    for(const name of reducedMotion?['muzzle-core']:['muzzle-core','muzzle-wing wing-left','muzzle-wing wing-right','muzzle-ring']){const layer=document.createElement('span');layer.className=name;node.append(layer);}
   }
   if(!node.children.length&&!small){
    node.dataset.detail=effectDetail();
    for(const name of ['contact-flash','shock-ring']){const layer=document.createElement('span');layer.className=name;node.append(layer);}
    const pose=corpses.get(e.id);
    if(pose){const body=document.createElement('div');body.className='death-body';body.style.width=body.style.height=pose.r*2+'px';body.style.left=(54+pose.x-e.x-pose.r)+'px';body.style.top=(54+pose.y-e.y-pose.r)+'px';body.dataset.tone=String(pose.slot);body.style.setProperty('--spin',pose.spin+'deg');
     for(let i=0;i<4;i++){const chunk=document.createElement('span'),rock=document.createElement('span');chunk.className='major-chunk chunk-'+i;chunk.style.clipPath=cuts[i];rock.className='meteor-rock';chunk.append(rock);body.append(chunk);}
     const intact=document.createElement('span'),crack=document.createElement('span');intact.className='meteor-rock intact-body';crack.className='body-crack';body.append(intact);body.append(crack);node.append(body);}
    for(let i=0;i<4;i++){const shard=document.createElement('i');shard.className='fragment spark';shard.style.setProperty('--angle',(i*90+e.id%35)+'deg');node.append(shard);}
    for(let i=0;i<5;i++){const debris=document.createElement('span');debris.className='rock-chip chip-'+i;node.append(debris);}
    for(let i=0;i<3;i++){const dust=document.createElement('span');dust.className='impact-dust dust-'+i;node.append(dust);}
    if(!reducedMotion){
     for(const name of ['energy-burst','impact-halo']){const layer=document.createElement('span');layer.className=name;node.append(layer);}
     // Fixed per-impact node budget; no random draws, timers or free-running particles.
     const count=node.dataset.detail==='full'?4:2;
     for(let i=0;i<count;i++){const shard=document.createElement('span');shard.className='energy-shard';shard.style.setProperty('--ex',[-.9,.8,-.45,.55][i]);shard.style.setProperty('--ey',[-1.4,-1.1,.55,.8][i]);shard.style.setProperty('--er',[-38,47,113,-129][i]+'deg');node.append(shard);}
    }
    const cue=document.createElement('b');cue.className='impact-cue';cue.textContent=e.kind==='correct'?'✓':'✕';node.append(cue);
   }
   const pose=corpses.get(e.id),separation=Math.max(0,age-.055);
   if(pose){
    const body=[...node.children].find(n=>n.className==='death-body');
    node.style.setProperty('--chip-origin-x',(54+pose.x-e.x)+'px');node.style.setProperty('--chip-origin-y',(54+pose.y-e.y)+'px');
    // Upward projectile impulse plus four distinct angular velocities. Numeric
    // physics continues untouched during the 55ms visual mass/crack hold.
    for(let i=0;i<4;i++){
     const chunk=body.children[i],vx=[-96,83,-76,106][i],vy=[-88,-112,50,29][i],angular=[-94,123,78,-116][i];
     chunk.style.transform=reducedMotion?'translate(0px,0px) rotate(0deg)':`translate(${vx*separation}px,${vy*separation+65*separation*separation}px) rotate(${angular*separation}deg)`;
    }
    body.style.setProperty('--intact-opacity',String(age<.055?1:Math.max(0,1-(age-.055)/.035)));
    body.style.setProperty('--crack-opacity',String(age<.018?0:Math.min(1,(age-.018)/.025)*Math.max(0,1-Math.max(0,age-.12)/.13)));
    if(!pose.breakSound&&age>=.055){pose.breakSound=true;audio.play('breakup');}
    if(!pose.verdictSound&&age>=.14){pose.verdictSound=true;audio.play(e.kind);}
    if(e.kind==='correct'&&!pose.speechStarted&&age>=.22&&audio.state.sfx){pose.speechStarted=true;audio.speech(true);learning.speakCorrect(()=>audio.speech(false));}
    if(pose.penalized&&!pose.shieldSound&&age>=.25){pose.shieldSound=true;audio.play('shield');}
    if(pose.ended&&!pose.endSound&&age>=.32){pose.endSound=true;audio.play('game-over');}
    if(!reducedMotion&&age>=.055&&age<.17){const strength=2.5*(1-(age-.055)/.115);shakeX=Math.sin(age*137)*strength;shakeY=Math.cos(age*113)*strength*.65;}
   }
   // All added VFX expire with the engine's existing 120/600ms effects.
   node.style.setProperty('--shot-fade',String(Math.max(0,1-age/.12)));
   node.style.setProperty('--shot-scale',String(reducedMotion?1:.65+age*5));
   node.style.setProperty('--burst-opacity',String(age<.055?0:Math.min(1,(age-.055)/.035)*Math.max(0,1-Math.max(0,age-.12)/.16)));
   node.style.setProperty('--halo-opacity',String(Math.max(0,1-age/.24)));
   node.style.setProperty('--blast-scale',String(reducedMotion?1:.55+Math.min(age,.32)*3));
   node.style.setProperty('--eject-distance',reducedMotion?'0px':Math.min(separation,.32)*125+'px');
   node.style.setProperty('--spread',reducedMotion?'0px':Math.max(0,age-.05)*70+'px');
   node.style.setProperty('--break',reducedMotion?'0px':Math.min(1,Math.max(0,age-.05)/.13)*22+'px');
   node.style.setProperty('--body-opacity',String(reducedMotion?Math.max(0,1-Math.max(0,age-.12)/.2):Math.max(0,1-Math.max(0,age-.26)/.29)));
   node.style.setProperty('--dust-opacity',String(age<.09?0:Math.min(1,(age-.09)/.08)*Math.max(0,1-Math.max(0,age-.21)/.25)));
   node.style.setProperty('--dust-drift',reducedMotion?'0px':separation*40+'px');
   node.style.setProperty('--chip-spread',reducedMotion?'0px':separation*58+'px');
   node.style.setProperty('--chip-turn',reducedMotion?'0deg':separation*120+'deg');
   node.style.setProperty('--ring-scale',String(reducedMotion?1:.55+Math.min(age,.3)*2));
   node.style.setProperty('--flash-opacity',String(Math.max(0,1-age/.12)));
   node.style.setProperty('--cue-opacity',String(age<.14?0:Math.min(1,(age-.14)/.08)*Math.min(1,Math.max(0,.5-age)/.12)));
   node.style.transform=camera.transform(e.x-size/2,e.y-size/2,e.y)+' scale(1)';
   node.style.opacity=String(Math.min(1,Math.max(0,e.life/(small?.08:.12))));});
  $('scene').style.setProperty('--shake-x',shakeX+'px');$('scene').style.setProperty('--shake-y',shakeY+'px');
  // Verdict text shares the impact's 140ms beat, not the logical scoring instant.
  const pendingWrongVerdict=engine.effects.some(e=>e.kind==='wrong'&&e.life>.46);
  field.dataset.kick=String(engine.time<kickUntil);const wrong=engine.phase==='ACTIVE'&&engine.time<wrongUntil&&!pendingWrongVerdict;
  $('status').dataset.wrong=String(wrong);$('status').textContent=wrong&&lastWrong?learning.resultText(lastWrong):engine.phase==='FEEDBACK'&&engine.reason==='escaped'?text('✕ เป้าหลุด','✕ Target escaped'):'';
  // A final recovery hit can end the run. Keep its physical breakup visible for
  // 500ms, while Game Over input/capture lock remains immediate. No new timer.
  const finalImpact=engine.phase==='GAME_OVER'&&engine.effects.some(e=>['correct','wrong'].includes(e.kind)&&e.life>.1);
  const overlay=!['ACTIVE','FEEDBACK'].includes(engine.phase)&&!finalImpact;world.dataset.phase=engine.phase;$('overlay').hidden=!overlay;$('home').hidden=engine.phase!=='EXITING';
  if(!overlay)return;
  const paused=engine.phase==='PAUSED',ready=engine.phase==='READY',ended=engine.phase==='GAME_OVER',exit=engine.phase==='EXITING',correct=engine.reason==='correct';
  $('overlay-title').textContent=exit?text('ออกจากสนามแล้ว','Playfield closed'):paused?text('พักเกม','Paused'):ready?text('ลาก · เล็ง · ยิง','Drag · align · fire'):ended?text('จบรอบ','Run complete'):correct?text('✓ ยิงถูกเป้า!','✓ Target hit!'):text('✕ เป้าหมายหลุดไป','✕ Target escaped');
  const target=learning.current?.target;
  $('overlay-copy').textContent=exit?text('การเคลื่อนไหวและ input หยุดแล้ว','Movement and input have stopped'):paused?text('ไม่มีเวลาหรือเกราะลดระหว่างพัก','Time and Shield stay frozen while paused'):ready?text('มือขวาลากยาน · FIRE ซ้าย · ยิงคำจีนตามความหมาย','Drag with your right thumb; FIRE on the left. Shoot the Chinese word.'):target?`${target.zh} · ${target.py} · ${learning.meaning(target)} · ${text('คะแนน ','Score ')}${engine.score}`:text('เลือก HSK เพื่อเริ่มรอบคำศัพท์จริง','Choose an HSK level to start a real vocabulary round');
  $('primary').textContent=paused?text('เล่นต่อ','Resume'):ready?text('เริ่มภารกิจ','Start mission'):text('เริ่มใหม่','Restart');
 }
 function events(){for(const e of engine.drain()){
  if(e.type==='correct'||e.type==='wrong'){
   const m=engine.meteors.find(m=>!m.alive&&m.label===e.label);
   const fx=[...engine.effects].reverse().find(f=>f.kind===e.type&&f.x===e.x&&f.y===e.y);
   const result=learning.feedback(e.type,e.label,{x:e.x,y:e.y});
   if(m&&fx)corpses.set(fx.id,{x:m.x,y:m.y,r:m.r,slot:m.slot,spin:reducedMotion?0:Math.sin(engine.time*.7+m.id)*9,penalized:!!e.penalized,ended:engine.phase==='GAME_OVER',result});
   audio.play('contact');
  }
  if(e.type==='wrong'){lastWrong=learning.lastResult;wrongUntil=engine.time+.9;if(e.penalized)shieldUntil=engine.time+.55;}
  if(e.type==='escape-correct'&&e.penalized){shieldUntil=engine.time+.55;audio.play('shield');}
  if(e.type==='fire'){kickUntil=engine.time+.15;audio.play('fire');}
  if(e.type==='resolved'&&engine.phase==='GAME_OVER'){release();if(e.reason==='escaped')audio.play('game-over');}
  if(e.type==='wave'){
   corpses.clear();wrongUntil=kickUntil=shieldUntil=0;lastWrong=null;learning.wave(engine.target,engine.wave);
   if(pointer){pointer.x=pointer.latestX;pointer.y=pointer.latestY;pointer.ufoX=engine.ufo.x;pointer.ufoY=engine.ufo.y;}
   bank=0;visualX=engine.ufo.x;
   audio.play('wave');
  }
 }}
 function vehicle(dt){
  const velocity=(engine.ufo.x-visualX)/Math.max(dt,.001);visualX=engine.ufo.x;
  const target=engine.phase==='ACTIVE'?Math.max(-12,Math.min(12,velocity*.04)):0;
  bank+=(target-bank)*(1-Math.exp(-dt/(Math.abs(target)>Math.abs(bank)?.075:.12)));
  if(Math.abs(bank)<.05)bank=0;
 }
 function loop(now,token){
  if(token!==epoch)return;frame=null;if(disposed||engine.phase==='PAUSED'||engine.phase==='EXITING')return;
  const elapsed=last===null?1/60:Math.min(.05,Math.max(0,(now-last)/1000));if(last!==null)accumulator+=elapsed;last=now;
  while(accumulator>=1/60){engine.step(1/60);accumulator-=1/60;}
  events();vehicle(elapsed);render();frame=requestAnimationFrame(next=>loop(next,token));
 }
 function run(){if(disposed||frame!==null)return;last=null;accumulator=0;const token=epoch;frame=requestAnimationFrame(now=>loop(now,token));}
 function start(event){if(disposed)return;release();cancelFrame();stopSpeech();learning.setLevel($('level').value);learning.start();audio.start(event);const size=measure();engine.measure(size.width,size.height);engine.start();corpses.clear();wrongUntil=kickUntil=bank=shieldUntil=0;lastWrong=null;visualX=engine.ufo.x;events();render();run();}
 function pause(reason='manual'){if(disposed)return;release();cancelFrame();stopSpeech();audio.pause();engine.pause(reason);render();}
 function resume(event){if(disposed||document.hidden)return;if(engine.resume()){audio.resume(event);rect=field.getBoundingClientRect();render();run();}}
 function fire(event){if(disposed)return false;if(engine.phase==='ACTIVE')audio.unlock(event);const accepted=engine.fire();events();render();return accepted;}
 function exit(){if(disposed)return;release();cancelFrame();stopSpeech();audio.exit();engine.exit();corpses.clear();wrongUntil=kickUntil=bank=shieldUntil=0;lastWrong=null;visualX=engine.ufo.x;render();$('primary').focus();}
 function dispose(){if(disposed)return;exit();audio.dispose();disposed=true;observer?.disconnect();for(const remove of removers)remove();}
 listen(world,'pointerdown',e=>{
  if(e.target?.closest?.('button,a,#overlay')||disposed||engine.phase!=='ACTIVE'||pointer||e.pointerType==='mouse'&&e.button!==0)return;
  rect=field.getBoundingClientRect();const x=e.clientX-rect.left,y=e.clientY-rect.top;if(y<engine.bounds.top||x<0||x>engine.width)return;
  e.preventDefault();pointer={id:e.pointerId,x,y,latestX:x,latestY:y,ufoX:engine.ufo.x,ufoY:engine.ufo.y};try{world.setPointerCapture(e.pointerId);}catch{release();}
 },{passive:false});
 listen(world,'pointermove',e=>{
  if(!pointer||pointer.id!==e.pointerId||!['ACTIVE','FEEDBACK'].includes(engine.phase))return;
  e.preventDefault();pointer.latestX=e.clientX-rect.left;pointer.latestY=e.clientY-rect.top;
  if(engine.phase==='ACTIVE')engine.moveTo(pointer.ufoX+pointer.latestX-pointer.x,pointer.ufoY+pointer.latestY-pointer.y);
  render();
 },{passive:false});
 const up=e=>{if(pointer?.id===e.pointerId)release();};for(const name of ['pointerup','pointercancel','lostpointercapture'])listen(world,name,up);
 listen($('fire'),'pointerdown',e=>{if(e.pointerType==='mouse'&&e.button!==0)return;e.preventDefault();e.stopPropagation();fire(e);},{passive:false});
 // Keyboard-generated clicks remain accessible; pointer clicks are already handled above.
 listen($('fire'),'click',e=>{if(e.detail===0)fire(e);});
 listen($('pause'),'click',()=>pause());listen($('exit'),'click',()=>{exit();if(document.body.dataset.production==='true')window.location.replace($('home').href);});
 listen($('primary'),'click',e=>{if(engine.phase==='PAUSED')resume(e);else if(['READY','GAME_OVER','EXITING'].includes(engine.phase))start(e);});
 listen($('music'),'click',e=>{audio.toggleMusic(e);render();});listen($('sfx'),'click',e=>{audio.toggleSfx(e);if(!audio.state.sfx)stopSpeech();render();});
 listen($('language'),'click',()=>{language=learning.setLanguage(language==='th'?'en':'th');document.documentElement.lang=language;render();});
 listen($('level'),'change',()=>{learning.setLevel($('level').value);render();});
 listen(document,'keydown',e=>{if(e.repeat||/^(INPUT|SELECT|TEXTAREA)$/.test(e.target?.tagName||''))return;if(e.code==='Space'&&engine.phase==='ACTIVE'){e.preventDefault();fire(e);}else if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','a','d'].includes(e.key)&&engine.phase==='ACTIVE'){e.preventDefault();engine.moveTo(engine.ufo.x+(['ArrowLeft','a'].includes(e.key)?-16:['ArrowRight','d'].includes(e.key)?16:0),engine.ufo.y+(e.key==='ArrowUp'?-10:e.key==='ArrowDown'?10:0));render();}});
 listen(document,'visibilitychange',()=>{if(document.hidden)pause('background');});
 listen(window,'orientationchange',()=>pause('orientation'));listen(window,'resize',resize);listen(window,'pagehide',e=>{if(e.persisted)pause('background');else dispose();});
 const observer=typeof ResizeObserver==='undefined'?null:new ResizeObserver(resize);observer?.observe(field);
 $('level').value=learning.level;document.documentElement.lang=language;const size=measure();engine.measure(size.width,size.height);render();
 // Development QA access only; this script is absent from production dist.
 window.MeteorLab={start,pause,resume,exit,dispose,fire,get engine(){return engine},get learning(){return learning},get audio(){return audio.state},get impactCount(){return corpses.size}};
})();
