'use strict';
// Home presentation. Canonical controls still own HSK, settings, language and launches.
(()=>{
 if(document.querySelector('.home-scene'))return; // A single ambient/presentation owner, including restored pages.
 const root=document.createElement('section');root.className='home-scene';root.setAttribute('aria-labelledby','home-headline');
 root.innerHTML=`<div class="home-world" aria-hidden="true"><img class="home-world-art" src="assets/home-world.webp" width="941" height="1672" alt="" loading="lazy" fetchpriority="high"><img class="home-world-depth" src="assets/home-world.webp" width="941" height="1672" alt="" loading="lazy"><div class="home-world-light"></div><div class="home-world-stars"></div><div class="home-world-haze"></div></div>
 <div class="home-brand" aria-label="Hanzi Blaster"><span>HANZI</span><b>BLASTER</b></div><p class="home-tagline">เรียนภาษาจีนผ่านเกมอาร์เคด</p>
 <div class="home-intro"><h1 id="home-headline" class="home-headline">PLAY.<br> BLAST.<br> LEARN CHINESE.</h1><p>เล่น · ยิงคำ · เรียนภาษาจีน</p></div>
 <div class="home-entry"><div class="home-hsk" role="group" aria-labelledby="home-hsk-label"><span id="home-hsk-label">เลือกระดับ HSK</span><div class="home-hsk-choices"></div></div><a class="home-play" href="#mode-lobby"><span>PLAY</span><span aria-hidden="true">›</span></a><a class="home-explore" href="#mode-lobby">สำรวจโหมดเกม <span aria-hidden="true">↗</span></a></div>
 <div class="home-destinations"><button type="button" class="home-destination home-adventure"><strong>CHINESE<br>ADVENTURE</strong><span>ผจญภัยจีน</span><i aria-hidden="true">›</i></button><button type="button" class="home-destination home-writing"><strong>WRITING LAB</strong><span>ฝึกเขียนจีน</span><i aria-hidden="true">›</i></button></div>
 <div class="home-tools"><button type="button" class="home-review"><span aria-hidden="true">↻</span>ทบทวนวันนี้</button><a href="#learning-progress"><span aria-hidden="true">▥</span>ดูความคืบหน้า</a><button type="button" class="home-more"><span aria-hidden="true">···</span>ตัวเลือกเพิ่มเติม</button></div><div class="home-save-status"></div>`;
 $('launch').before(root);
 const choices=root.querySelector('.home-hsk-choices'),buttons=[];
 for(const option of $('level').options){if(!/^[1-5]$/.test(option.value))continue;const button=document.createElement('button');button.type='button';button.dataset.hsk=option.value;button.setAttribute('aria-label',HSK.label(option.value));button.innerHTML='<b>'+option.value+'</b><small>HSK '+option.value+'</small>';button.onclick=()=>HSK.select(option.value);choices.append(button);buttons.push(button);}
 // Keep the original Home mirrors and cloud status identity; only their placement changes.
 $('home-level').classList.add('home-native-level');$('home-level').tabIndex=-1;$('home-level').setAttribute('aria-hidden','true');choices.append($('home-level'));
 root.querySelector('.home-save-status').append($('home-cloud-status'));
 root.querySelector('.home-adventure').onclick=()=>$('quick-start').click();
 root.querySelector('.home-writing').onclick=()=>$('open-writing').click();
 root.querySelector('.home-review').onclick=()=>$('daily-review').click();
 root.querySelector('.home-more').onclick=()=>$('home-settings').click();
 function sync(){for(const button of buttons)button.setAttribute('aria-pressed',String(button.dataset.hsk===$('level').value));root.querySelector('.home-play').setAttribute('aria-label',UI.t('เลือกโหมดแล้วเริ่มเล่น'));root.querySelector('#home-hsk-label').textContent=UI.t($('level').value==='all'?'ผสม · HSK 1–5':'เลือกระดับ HSK');UI.apply(root);}
 $('level').addEventListener('change',sync);UI.onChange(sync);sync();
 // CSS owns ambient motion. No timer or frame loop; do not move live controls.
 let pageSuspended=false;
 function ambient(){
  // Intersection callbacks can arrive after a route/BFCache restore. Read current
  // geometry at lifecycle boundaries, rather than retaining an old hidden-view result.
  const bounds=root.getBoundingClientRect(),inView=bounds.width>0&&bounds.bottom>0&&bounds.top<window.innerHeight;
  const paused=pageSuspended||!inView||document.hidden||!document.body.classList.contains('home-view')||document.body.classList.contains('playing')||!!document.querySelector('dialog[open]');if(root.classList.contains('home-ambient-paused')!==paused)root.classList.toggle('home-ambient-paused',paused);
 }
 if(typeof IntersectionObserver!=='undefined')new IntersectionObserver(ambient).observe(root);
 const observer=new MutationObserver(ambient);observer.observe(document.body,{attributes:true,attributeFilter:['class']});for(const dialog of document.querySelectorAll('dialog'))observer.observe(dialog,{attributes:true,attributeFilter:['open']});
 document.addEventListener('visibilitychange',ambient);window.addEventListener('hashchange',ambient);
 window.addEventListener('pagehide',()=>{pageSuspended=true;ambient();});
 window.addEventListener('pageshow',()=>{pageSuspended=false;ambient();});ambient();
})();
