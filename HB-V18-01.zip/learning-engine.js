'use strict';
// Additive migration: the original vocabulary IDs and progress store remain authoritative.
const LearningEngine=(()=>{
 let encounter=String(Date.now())+'-'+Math.random(),started=0;
 const num=v=>Number.isFinite(v)?v:0;
 function begin(){encounter=String(Date.now())+'-'+Math.random();}
 function state(w){const s=learning[w.id];if(!s)return 'NEW';if(num(s.recentMistakes)>0||s.streak===0&&s.wrong>0||num(s.avgResponse)>9000)return 'WEAK';if(s.streak>=5&&num(s.correctEncounters)>=3)return 'MASTERED';if(s.streak>=3)return 'FAMILIAR';return 'LEARNING';}
 function priority(w){const s=learning[w.id];return !s?1:1+Math.min(8,num(s.recentMistakes)*2)+Math.min(4,s.wrong/(s.correct+1))+(num(s.avgResponse)>9000?2:0)+(s.streak<3?2:0);}
 function weak(source){return source.filter(w=>state(w)==='WEAK'||state(w)==='LEARNING').sort((a,b)=>priority(b)-priority(a));}
 function mark(){started=performance.now();}
 function record(word,ok,ms=null){const now=Date.now(),s=learning[word.id]||{streak:0,correct:0,wrong:0,due:0};s.streak=ok?Math.min(s.streak+1,20):0;s.correct=num(s.correct)+(ok?1:0);s.wrong=num(s.wrong)+(ok?0:1);s.recentMistakes=ok?Math.max(0,num(s.recentMistakes)-1):Math.min(5,num(s.recentMistakes)+1);if(ok&&s.lastCorrectEncounter!==encounter){s.correctEncounters=num(s.correctEncounters)+1;s.lastCorrectEncounter=encounter;}if(s.lastEncounter!==encounter){s.encounters=num(s.encounters)+1;s.lastEncounter=encounter;}if(Number.isFinite(ms)&&ms>=0&&ms<60000){s.responseSamples=num(s.responseSamples)+1;s.avgResponse=s.responseSamples===1?ms:num(s.avgResponse)*.75+ms*.25;}s.last=now;s.due=now+(ok?(s.streak>=5&&s.correctEncounters>=3?7*86400000:s.streak>=3?86400000:600000):180000);learning[word.id]=s;s.mastery=state(word);try{localStorage.setItem('hanzi-learning-v1',JSON.stringify(learning));}catch{$('learning-storage').textContent='เก็บความคืบหน้าได้เฉพาะรอบนี้';}try{window.BetaCloud?.recordWord(word,ok,s);}catch{}return s;}
 function elapsed(){return Math.max(0,performance.now()-started);}
 // Weighted indexed bags: build once, remove/pick in O(log n). The old category
 // quotas, priority weights, mastered discount and five-item recent rule remain.
 function round(source,count,key,distinctCount=0){
  const unique=[...new Map(source.map(w=>[w.id,w])).values()],recent=new Set(readRecent(key)),now=Date.now();
  const rows=unique.map(w=>{const status=state(w);return {w,category:status==='WEAK'||status==='LEARNING'?'weak':learning[w.id]&&learning[w.id].due<=now?'review':'normal',normal:status==='MASTERED'&&learning[w.id].due>now?.15:1,weak:priority(w),fresh:!recent.has(w.id),bags:[]};});
  function bag(items,weight){
   const weights=items.map(r=>r[weight]),tree=new Float64Array(items.length+1);let total=0,left=items.length;
   for(let i=1;i<=items.length;i++){tree[i]+=weights[i-1];const parent=i+(i&-i);if(parent<tree.length)tree[parent]+=tree[i];total+=weights[i-1];}
   const result={get left(){return left;},take(){let value=Math.random()*total,index=0,bit=1;while(bit*2<=items.length)bit*=2;for(;bit;bit>>=1){const next=index+bit;if(next<=items.length&&tree[next]<=value){index=next;value-=tree[next];}}return items[Math.min(index,items.length-1)];},remove(i){const value=weights[i];if(!value)return;weights[i]=0;left--;total-=value;for(let j=i+1;j<tree.length;j+=j&-j)tree[j]-=value;if(!left)total=0;}};
   items.forEach((r,i)=>r.bags.push(()=>result.remove(i)));return result;
  }
  function pair(items,weight){return {all:bag(items,weight),fresh:bag(items.filter(r=>r.fresh),weight)};}
  const groups={};for(const type of ['normal','weak','review'])groups[type]=pair(rows.filter(r=>r.category===type),type==='weak'?'weak':'normal');
  const fallback={normal:pair(rows,'normal'),weak:pair(rows,'weak')};
  const plan=shuffle(Array.from({length:count},(_,i)=>i<Math.round(count*.3)?'weak':i<Math.round(count*.5)?'review':'normal')),selected=[],distinct=[];
  for(const type of plan){let pool=groups[type];if(!pool.all.left)pool=fallback[type==='weak'?'weak':'normal'];if(!pool.all.left)break;
   const pick=(selected.length<5&&pool.fresh.left?pool.fresh:pool.all).take();pick.bags.forEach(remove=>remove());selected.push(pick.w);
   if(distinctCount&&distinct.every(w=>compatible(w,pick.w))){distinct.push(pick.w);if(distinct.length===distinctCount)break;}
  }
  try{localStorage.setItem('hanzi-round-v2:'+key,JSON.stringify(selected.slice(0,5).map(w=>w.id)));}catch{}
  return distinctCount?distinct:selected;
 }
 // Same full-pool category-plan distribution as before, but stop once enough
 // compatible words are selected. Never build an unused full vocabulary order.
 function roundDistinct(source,count,key){return round(source,source.length,key,count);}
 function readRecent(key){try{const x=JSON.parse(localStorage.getItem('hanzi-round-v2:'+key)||'[]');return Array.isArray(x)?x:[];}catch{return [];}}
 // Endless mode traverses the complete pool. Only actual questions consume the
 // persistent deck; ending after three answers cannot discard the other twelve.
 const decks=new Map();
 function endlessNext(source,key){
  const byId=new Map(source.map(w=>[w.id,w])),ids=[...byId.keys()],signature=ids.join(',');
  if(!ids.length)return null;
  const storageKey='hanzi-endless-deck-v1:'+key;let d=decks.get(key);
  if(!d||d.signature!==signature){
   try{d=JSON.parse(localStorage.getItem(storageKey)||'null');}catch{d=null;}
   if(!d||d.signature!==signature||!Array.isArray(d.remaining)||d.remaining.some(id=>!byId.has(id))||new Set(d.remaining).size!==d.remaining.length)d={signature,remaining:shuffle(ids),recent:[],sinceReview:0,cycle:1};
   d.recent=Array.isArray(d.recent)?d.recent.filter(id=>byId.has(id)).slice(-8):[];
   d.sinceReview=Number.isFinite(d.sinceReview)?d.sinceReview:0;d.cycle=Number.isInteger(d.cycle)&&d.cycle>0?d.cycle:1;decks.set(key,d);
  }
  if(!d.remaining.length){d.remaining=shuffle(ids);d.cycle++;}
  const recentText=new Set(d.recent.map(id=>byId.get(id)?.zh));let picked=null,review=false;
  if(d.sinceReview>=4){
   const remainingIds=new Set(d.remaining);
   const eligible=weak(source).filter(w=>!remainingIds.has(w.id)&&!d.recent.includes(w.id)&&!recentText.has(w.zh));
   if(eligible.length){const candidates=shuffle(eligible.slice(0,20));picked=candidates[0];review=true;d.sinceReview=0;}
  }
  if(!picked){
   let index=d.remaining.findIndex(id=>!d.recent.includes(id)&&!recentText.has(byId.get(id).zh));
   if(index<0)index=d.remaining.findIndex(id=>byId.get(id).zh!==byId.get(d.recent.at(-1))?.zh);
   if(index<0)index=0;
   picked=byId.get(d.remaining.splice(index,1)[0]);d.sinceReview++;
  }
  d.recent.push(picked.id);d.recent=d.recent.slice(-8);
  try{localStorage.setItem(storageKey,JSON.stringify(d));}catch{}
  const status=document.getElementById('endless-coverage');if(status){status.hidden=false;status.textContent=`รอบวน ${d.cycle} · พบ ${ids.length-d.remaining.length}/${ids.length} คำ${review?' · ทบทวนคำที่ยังไม่แม่น':''}`;}
  return picked;
 }
 return {begin,state,priority,weak,record,mark,elapsed,round,roundDistinct,endlessNext,excludePause:ms=>{started+=ms;}};
})();
