'use strict';
// V2C presentation. The original journey/round/storage/audio owners remain authoritative.
(()=>{
 const body=document.body,journey=$('journey'),chapters=$('chapters'),arena=document.querySelector('.arena');
 const root=document.createElement('section');root.className='adventure-scene';root.setAttribute('aria-label',UI.t('ผจญภัยจีน'));
 const world=document.createElement('div');world.className='adventure-world';world.setAttribute('aria-hidden','true');
 for(const name of ['cosmos','haze','particles']){const layer=document.createElement('div');layer.className='adventure-'+name;world.append(layer);}
 const plane=document.createElement('div');plane.className='adventure-plane';
 const image=document.createElement('img');image.src='assets/adventure-world.webp';image.alt='';image.width=900;image.height=1600;image.decoding='async';image.className='adventure-world-art';image.setAttribute('aria-hidden','true');plane.append(image);
 // Geometry is a live route diagram, not artwork or a new progression model.
 const ns='http://www.w3.org/2000/svg',route=document.createElementNS(ns,'svg');route.classList.add('adventure-route');route.setAttribute('viewBox','0 0 100 100');route.setAttribute('preserveAspectRatio','none');route.setAttribute('aria-hidden','true');
 const positions=[[50,74.7],[50,53.5],[69,40.9],[78.5,32.2],[82.5,26.9],[83,20]];
 const connections=[];for(let i=0;i<positions.length-1;i++){const line=document.createElementNS(ns,'path');line.setAttribute('d',`M${positions[i].join(' ')} L${positions[i+1].join(' ')}`);line.setAttribute('vector-effect','non-scaling-stroke');route.append(line);connections.push(line);}plane.append(route);
 const head=document.createElement('header');head.className='adventure-head';
 const brand=document.createElement('div');brand.className='adventure-brand';brand.innerHTML='<span>HANZI</span><b>BLASTER</b><small>v1.3.0</small>';
 const state=document.createElement('div');state.className='adventure-state';head.append(brand,state);
 const hskControl=document.createElement('label');hskControl.className='adventure-hsk-control';hskControl.setAttribute('for','level');
 const hskText=document.createElement('span');hskText.className='adventure-hsk-text';hskText.setAttribute('aria-hidden','true');hskControl.append(hskText);state.append(hskControl);
 const mission=document.createElement('div');mission.className='adventure-mission';
 const eyebrow=document.createElement('span');eyebrow.className='adventure-eyebrow';
 const destination=document.createElement('h1');destination.className='adventure-destination';
 const rule=document.createElement('p');rule.className='adventure-rule';mission.append(eyebrow,destination,rule);
 const cta=document.createElement('div');cta.className='adventure-action';
 const support=document.createElement('nav');support.className='adventure-support';
 const back=document.createElement('button');back.type='button';back.className='adventure-back';back.onclick=()=>{if(active)return;location.hash='mode-lobby';update();returnFocus();};
 const language=document.querySelector('.language-picker');
 const hud=arena.querySelector('.hud'),question=arena.querySelector('.question'),field=$('field'),bottom=arena.querySelector('.bottom'),foot=arena.querySelector('.arena-foot'),overdrive=$('overdrive-panel');
 const questionTabIndex=question.getAttribute?.('tabindex');
 const play=document.createElement('div');play.className='adventure-play';
 const parked=new Map();let mounted=false,phase=null,lastSignature='',questionView=null,returnEpoch=0;
 function move(node,parent){if(!parked.has(node)){const marker=document.createComment('V2C original position');node.before(marker);parked.set(node,marker);}if(node.parentNode!==parent)parent.append(node);}
 function restore(node){const marker=parked.get(node);if(marker){marker.replaceWith(node);parked.delete(node);}}
 function mount(){
  if(mounted)return;mounted=true;returnEpoch++;body.classList.add('adventure-view');body.append(root);root.append(world,plane,head,mission,cta,support,play);
  move($('level'),hskControl);move($('chapter-progress'),state);move(chapters,plane);move(language,support);support.append(back);
  window.scrollTo({top:0,left:0,behavior:'instant'});
 }
 function unmount(){
  if(!mounted)return;mounted=false;phase=null;lastSignature='';questionView=null;returnEpoch++;
  for(const [node,marker]of [...parked].reverse())marker.replaceWith(node);parked.clear();root.remove();
  body.classList.remove('adventure-view','adventure-map','adventure-playing','adventure-results','adventure-ambient-paused');
  if(root.dataset.inputState!==undefined)delete root.dataset.inputState;
  if(question.getAttribute?.('tabindex')!==questionTabIndex){if(questionTabIndex==null)question.removeAttribute('tabindex');else question.setAttribute('tabindex',questionTabIndex);}
 }
 function phaseLayout(next){
  if(phase===next)return;phase=next;root.dataset.phase=next;
  const result=$('results');
  restore($('results-home'));
  for(const name of ['map','playing','results'])body.classList.toggle('adventure-'+name,next===name);
  if(next==='playing'){
   restore($('start'));restore($('results'));move(hud,play);move(question,play);move(field,play);move(bottom,play);move(overdrive,play);move(foot,play);move($('boss-panel'),play);
  }else{
   for(const node of [hud,question,field,bottom,overdrive,foot,$('boss-panel')])restore(node);
   if(next==='results'){restore($('start'));move(result,cta);const actions=result.querySelector('.result-actions');if(actions)move($('results-home'),actions);}else{restore(result);move($('start'),cta);}
  }
  // Keep the owner's results focus when append/reparent loses native focus.
  if(next==='results'&&document.activeElement===body)result.focus({preventScroll:true});
  window.scrollTo({top:0,left:0,behavior:'instant'});
 }
 function text(node,value){if(node.textContent!==value)node.textContent=value;}
 function attribute(node,name,value){if(node.getAttribute?.(name)!==value)node.setAttribute(name,value);}
 function returnFocus(){
  const epoch=returnEpoch;
  queueMicrotask(()=>{const target=document.querySelector('.mission-nav a[href="#mode-lobby"]');if(epoch===returnEpoch&&!mounted&&!active&&$('results').hidden&&location.hash==='#mode-lobby'&&target?.getClientRects().length)target.focus({preventScroll:true});});
 }
 function continuity(){
  const targets=$('targets'),paused=document.hidden||!!$('exit-dialog').open||!!$('howto-dialog')?.open;
  const input=phase!=='playing'?phase:paused?'paused':[...(targets?.children||[])].some(node=>!node.disabled)?'ready':'feedback';
  if(root.dataset.inputState!==input)root.dataset.inputState=input;
  const view=targets?.firstElementChild;
  // Reading anchor only: never a native text input or answer/input owner.
  if(input==='ready'&&view&&view!==questionView){questionView=view;if(question.tabIndex!==-1)question.tabIndex=-1;
   const focused=document.activeElement;if(focused===body||[$('start'),$('again'),$('next-chapter'),$('next')].includes(focused))question.focus({preventScroll:true});
  }
 }
 function update(){
  const mode=active?sessionMode:$('mode').value;
  const requested=location.hash==='#journey'||active&&mode==='campaign';
  if(!requested||mode!=='campaign'||$('sentence-dialog').open||$('writing-lab')?.open){unmount();return;}
  mount();phaseLayout(active?'playing':!$('results').hidden&&sessionMode==='campaign'?'results':'map');
  if(root.dataset.campaignPhase!==campaignPhase)root.dataset.campaignPhase=campaignPhase;
  const ch=CHAPTERS[selectedChapter],done=stageUnlocked();
  text(hskText,HSK.label($('level').value));
  text(eyebrow,phase==='playing'?UI.t(campaignPhase==='boss'?'BOSS':'ช่วงฝึก'):phase==='results'?UI.t($('results').querySelector('.eyebrow')?.textContent||''):UI.t('ภารกิจจีนในชีวิตจริง'));text(destination,UI.t(ch.name));
  text(rule,UI.t(phase==='playing'?$('boss-stage')?.textContent||'':phase==='results'?'ดูคะแนนและทบทวนคำที่พลาดด้านล่าง':'ฝึก 8 คำ → บอส 5 พลังชีวิต'));
  text(back,UI.t('กลับไปเลือกโหมด'));if(back.hidden!==active)back.hidden=active;
  attribute(root,'aria-label',UI.t('ผจญภัยจีน'));attribute(support,'aria-label',UI.t('เมนูหลัก'));
  const compact=window.matchMedia?.('(max-height:550px) and (min-width:700px)').matches||false;
  const layout=compact?[[30,74.7],[42,53.5],[57,40.9],[73,32.2],[87,26.9],[99,20]]:positions;
  const signature=selectedChapter+':'+done+':'+UI.language+':'+active+':'+compact;
  if(signature!==lastSignature||chapters.children[0]?.dataset.routeStep===undefined){
   lastSignature=signature;
   [...chapters.children].forEach((button,i)=>{
    const [x,y]=layout[i];button.dataset.routeStep=String(i+1);button.style.setProperty('--route-x',x+'%');button.style.setProperty('--route-y',y+'%');
    // Accessible labels describe original states. Do not modify disabled/onclick.
    button.setAttribute('aria-label',`${i+1}. ${UI.t(CHAPTERS[i].name)} · ${UI.t(i<done?'✓ ผ่านแล้ว · เล่นซ้ำได้':i>done?'ผ่านด่านก่อนหน้าเพื่อเปิด':'พร้อมออกผจญภัย')}`);
   });
   connections.forEach((line,i)=>{line.setAttribute('d',`M${layout[i].join(' ')} L${layout[i+1].join(' ')}`);line.classList.toggle('route-completed',i<done);});
  }
  body.classList.toggle('adventure-ambient-paused',document.hidden||!!$('exit-dialog').open||!!$('howto-dialog')?.open);
  const wrong=phase==='playing'&&!!field.querySelector('.target.wrong');
  root.classList.toggle('adventure-answer-wrong',wrong);
  root.classList.toggle('adventure-answer-correct',phase==='playing'&&!wrong&&!!field.querySelector('.target.correct'));
  continuity();
 }
 // The Hub card now opens the existing mission map before the original Start action.
 // This changes entry composition only; the original #start still starts the round.
 $('quick-start').onclick=()=>{if(active)return;$('mode').value='campaign';selectedChapter=Math.min(stageUnlocked(),CHAPTERS.length-1);settings();location.hash='journey';update();};
 // Returning from a finished campaign follows the existing Hub destination.
 $('results-home').addEventListener('click',()=>{if(mounted&&!active){location.hash='mode-lobby';update();returnFocus();}});
 const observer=new MutationObserver(update);
 observer.observe(body,{attributes:true,attributeFilter:['class']});
 observer.observe(chapters,{childList:true});observer.observe($('chapter-progress'),{childList:true,subtree:true,characterData:true});
  observer.observe($('results'),{attributes:true,attributeFilter:['hidden']});
 observer.observe($('round'),{childList:true,subtree:true,characterData:true});
 observer.observe(field,{childList:true,subtree:true,attributes:true,attributeFilter:['class']});
 for(const dialog of [$('exit-dialog'),$('howto-dialog'),$('sentence-dialog'),$('writing-lab')])if(dialog)observer.observe(dialog,{attributes:true,attributeFilter:['open']});
 window.addEventListener('resize',update);window.addEventListener('hashchange',update);document.addEventListener('visibilitychange',update);UI.onChange(update);update();
})();
