'use strict';
const ChoiceMemory=(()=>{
 let cache={};try{const saved=JSON.parse(localStorage.getItem('hanzi-choice-memory')||'{}');if(saved&&typeof saved==='object'&&!Array.isArray(saved))cache=saved;}catch{}
 function choose(source,count,seed=[]){if(!seed.length)return distinct(source,count);const key=seed[0].id+':'+count,previous=Array.isArray(cache[key])?cache[key]:[],fresh=shuffle(source.filter(w=>!previous.includes(w.id))),old=shuffle(source.filter(w=>previous.includes(w.id)));const options=distinct([...fresh,...old],count,seed,true);cache[key]=options.filter(w=>!seed.some(s=>s.id===w.id)).map(w=>w.id);const keys=Object.keys(cache);for(const k of keys.slice(0,Math.max(0,keys.length-100)))delete cache[k];try{localStorage.setItem('hanzi-choice-memory',JSON.stringify(cache));}catch{}return options;}
 return {choose};
})();
