window.HANZI_SUPABASE={"url":"https://xmgwfsygjmmcatlngygg.supabase.co","key":"sb_publishable_IELvYEVFEzNrL2ijv42d-Q_XukwuT38","enabled":true};
