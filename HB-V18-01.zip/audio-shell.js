/* Audio follows existing mode/dialog owners; it never launches or pauses gameplay. */
(()=>{
 'use strict';if(window.HanziAudioShell)return;const audio=window.HanziAudio;if(!audio)return;
 const ufo=/\/ufo-meteor\//.test(location.pathname),listeners=[];
 function on(target,name,fn,capture=false){target.addEventListener(name,fn,capture);listeners.push(()=>target.removeEventListener(name,fn,capture));}
 function sync(){
  if(ufo)return;let theme='shell';const playing=typeof active!=='undefined'&&active;
  if(document.getElementById('writing-lab')?.open||document.getElementById('sentence-dialog')?.open)theme='focus';
  else if(playing)theme=sessionMode==='campaign'?'adventure':'training';
  else if(location.hash==='#journey'||document.body.classList.contains('adventure-view'))theme='adventure';
  const paused=playing&&(typeof exitPaused!=='undefined'&&exitPaused||!!document.getElementById('howto-dialog')?.open||sessionMode==='bubbles'&&typeof BubbleField!=='undefined'&&BubbleField.paused)||!!document.querySelector('#sentence-body [data-sentence="resume"]');
  audio.setTheme(theme);audio.setLifecycle({hidden:document.hidden,paused:!!paused});
 }
 function gesture(e){if(ufo||!audio.validGesture(e))return;sync();audio.unlock(e);const b=e.target.closest?.('button,a');if(b&&b.id!=='ufo-meteor-card'){const mode=b.dataset.mode;if(b.id==='open-writing'||b.id==='sentence-card')audio.prepare('focus');else if(mode)audio.prepare(mode==='campaign'?'adventure':'training');else if(b.dataset.chapter)audio.prepare('adventure');}}
 on(document,'pointerdown',gesture,true);on(document,'pointerup',gesture,true);on(document,'touchend',gesture,true);on(document,'keydown',gesture,true);on(document,'click',e=>{
  gesture(e);if(!audio.validGesture(e)||ufo)return;
  const b=e.target.closest('button,a,summary');if(!b||b.disabled)return;
  if(b.matches('[data-audio-toggle],.audio-preferences *'))return;
  // Answer correctness is owned by gameplay callbacks, never by UI hit detection.
  if(b.matches('.target,.match-card,[data-sentence^="answer-"],.bubble'))return;
  const id=b.id,nav=b.closest('.mission-nav'),write=b.dataset.write,sentence=b.dataset.sentence;
  if(id==='ufo-meteor-card'){audio.handoff(true);return;}
  if(write==='close'||sentence==='close'||['exit','results-home','sentence-close','exit-confirm'].includes(id))audio.cue('exit');
  else if(['start','again','quick-start'].includes(id)||b.matches('.home-play')||sentence==='start')audio.cue(id==='start'&&typeof sessionMode!=='undefined'&&sessionMode==='campaign'?'mission-enter':'launch');
  else if(b.dataset.hsk)audio.cue('hsk');
  else if(id==='open-settings'||b.tagName==='SUMMARY')audio.cue('open');
  else if(b.matches('.mission-settings-close'))audio.cue('close');
  else if(b.matches('.mode-tile,.mode-card,button[data-mode]')||id==='sentence-card'||id==='open-writing')audio.cue('enter');
  else if(nav||b.matches('.home-explore,[data-chapter]'))audio.cue('nav');
 },true);
 on(document,'change',e=>{if(e.isTrusted&&e.target.matches('select[id*="level"],#mission-level'))audio.cue('hsk');});
 on(document,'visibilitychange',()=>{audio.setLifecycle({hidden:document.hidden});if(document.hidden){window.LearningAudio?.cancel?.();if(typeof LearningAudio!=='undefined')LearningAudio.cancel();}sync();});
 on(window,'pagehide',e=>{audio.setLifecycle({pageHidden:true});if(typeof LearningAudio!=='undefined')LearningAudio.cancel();if(!e.persisted)audio.dispose();});
 on(window,'pageshow',e=>{audio.reloadPreferences();if(e.persisted&&!ufo&&audio.external)audio.handoff(false);audio.setLifecycle({pageHidden:false,hidden:document.hidden});sync();});on(window,'hashchange',sync);on(window,'popstate',sync);
 // Observe state owners, not every stroke SVG, bubble, particle or answer class.
 const observer=new MutationObserver(sync);if(!ufo){observer.observe(document.body,{attributes:true,attributeFilter:['class']});for(const dialog of document.querySelectorAll('dialog'))observer.observe(dialog,{attributes:true,attributeFilter:['open']});const cover=document.getElementById('bubble-cover');if(cover)observer.observe(cover,{attributes:true,attributeFilter:['hidden']});const sentence=document.getElementById('sentence-body');if(sentence)observer.observe(sentence,{childList:true});}else audio.handoff(true);
 // Small controls mount inside the canonical settings panel / UFO options only.
 const parent=document.getElementById(ufo?'overlay':'settings-panel'),controls=document.createElement('fieldset');controls.className='audio-preferences';
 if(parent){controls.innerHTML='<legend></legend>'+['music','sfx'].map(kind=>'<div class="audio-setting"><button type="button" data-audio-toggle="'+kind+'"></button><label><span></span><input type="range" min="0" max="100" step="1" data-audio-volume="'+kind+'"></label><output></output></div>').join('');parent.append(controls);}
 function labels(){const en=ufo?(document.documentElement.lang||'th')==='en':typeof UI!=='undefined'&&UI.language==='en';if(!parent)return;const t=key=>!ufo&&typeof UI!=='undefined'?UI.t(key):en?({เสียง:'AUDIO',เพลง:'Music',เอฟเฟกต์:'SFX',ระดับเสียง:'Volume',เปิด:'On',ปิด:'Off'}[key]||key):key;controls.querySelector('legend').textContent=t('เสียง');for(const kind of ['music','sfx']){const row=controls.querySelector('[data-audio-toggle="'+kind+'"]').parentNode,button=row.querySelector('button'),range=row.querySelector('input'),name=t(kind==='music'?'เพลง':'เอฟเฟกต์');button.textContent=name+' · '+t(audio.prefs[kind]?'เปิด':'ปิด');button.setAttribute('aria-pressed',String(audio.prefs[kind]));range.setAttribute('aria-label',name+' '+t('ระดับเสียง'));range.value=Math.round(audio.prefs[kind+'Volume']*100);row.querySelector('label span').textContent=t('ระดับเสียง');row.querySelector('output').textContent=range.value+'%';}}
 controls.addEventListener('click',e=>{const key=e.target.closest('[data-audio-toggle]')?.dataset.audioToggle;if(!key)return;audio.unlock(e);audio.setPreference(key,!audio.prefs[key]);});controls.addEventListener('input',e=>{const kind=e.target.dataset.audioVolume;if(kind)audio.setPreference(kind+'Volume',+e.target.value/100);});
 // Diagnostics stay in the owner, never serialize every cue into live UI DOM.
 const unsubscribe=audio.subscribe(labels);if(typeof UI!=='undefined')listeners.push(UI.onChange(labels));else{const language=new MutationObserver(labels);language.observe(document.documentElement,{attributes:true,attributeFilter:['lang']});listeners.push(()=>language.disconnect());}labels();sync();
 window.HanziAudioShell={sync,get state(){return audio.state;},dispose(){observer.disconnect();listeners.splice(0).forEach(off=>off());unsubscribe();audio.onState=null;controls.remove();audio.dispose();}};
})();
