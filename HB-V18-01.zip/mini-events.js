'use strict';
const MiniEvents=(()=>{
 let event=null,used=0,nextAt=Infinity,recent=null,speedMS=0;let enabled=true;
 const banner=()=>$('mini-event');
 function reset(){event=null;used=0;speedMS=0;nextAt=7+Math.floor(Math.random()*3);if(banner())banner().hidden=true;}
 function eligible(){return enabled&&!config.review&&!['campaign','match','listening'].includes(sessionMode);}
 function start(type){if(type==='recovery'&&(!hasLives()||lives>=3))return false;event={type,left:type==='speed'?3:1,correct:0};speedMS=0;used++;recent=type;paint();return true;}
 function before(){if(!eligible())return;if(!event&&used<2&&answered>=nextAt&&(sessionMode==='endless'||sessionMode==='timed'||roundLimit-answered>=3)){const types=['speed','double',...(hasLives()&&lives<3?['recovery']:[])].filter(t=>t!==recent);start(shuffle(types)[0]);}paint();}
 function paint(){const el=banner();if(!el)return;el.hidden=!event;if(event)el.textContent=event.type==='speed'?`⚡ SPEED BURST · ถูก 3 ข้อในเวลาตอบรวม 15 วิ · เหลือ ${event.left} ข้อ (ไม่นับเวลาเฉลย)`:event.type==='recovery'?'♥ RECOVERY CHANCE · ถูกฟื้น 1 HP · ผิดไม่เสีย HP':'🔥 DOUBLE SCORE · ข้อนี้คะแนน ×2';}
 function multiplier(){return event?.type==='double'?2:1;}
 function protects(){return event?.type==='recovery';}
 function answer(ok,ms){if(!event)return;const type=event.type;event.correct+=ok?1:0;event.left--;speedMS+=Math.min(60000,Math.max(0,ms));let message='';if(type==='recovery'){if(ok)lives=Math.min(3,lives+1);message=ok?'♥ ฟื้นพลัง +1':'โอกาสฟื้นพลังจบแล้ว · ลองต่อได้';}if(type==='double')message=ok?'🔥 รับคะแนนสองเท่าแล้ว':'จบช่วงคะแนนสองเท่า';if(type==='speed'&&event.left===0){const win=event.correct===3&&speedMS<=15000;if(win)score+=200;message=win?'⚡ SPEED BURST สำเร็จ +200':'⚡ จบ Speed Burst · กลับสู่รอบปกติ';}if(event.left===0){event=null;nextAt=answered+5+Math.floor(Math.random()*3);if(banner()){banner().hidden=false;banner().textContent=message;}}else paint();}
 return {reset,before,start,multiplier,protects,answer,get event(){return event},get used(){return used},set enabled(v){enabled=v}};
})();
