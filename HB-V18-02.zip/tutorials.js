'use strict';
const Tutorials=(()=>{
 let doneCallback=null,kind='listening',step=0;
 const dialog=document.createElement('dialog');dialog.id='howto-dialog';dialog.setAttribute('aria-label','วิธีเล่น');document.body.append(dialog);
 function seen(mode){try{return localStorage.getItem('hanzi-howto-v1:'+mode)==='done';}catch{return false;}}
 function open(mode,callback=null){kind=mode;step=0;doneCallback=callback;dialog.showModal();draw();}
 function draw(){
  const listening=kind==='listening',boss=kind==='boss',question=active&&typeof currentBossQuestion!=='undefined'?currentBossQuestion:null;
  const pinyinAnswers=question?.type==='hanzi-pinyin',meaningAnswers=listening||kind==='match'||['hanzi-meaning','sentence'].includes(question?.type);
  const title=question?question.label:listening?'ฟังคำนี้ แล้วเลือกความหมาย':boss?'เลือกคำจีนที่แปลว่า “น้ำ”':MODES[kind]?.name||'วิธีเล่น';
  const help=listening?'กดฟัง แล้วลองเลือกคำตอบด้านล่าง':boss?'ตอบถูกยิงเกราะ · หลบพลาดเสียหัวใจ · ตอบศัพท์ผิดมีเฉลย':MODES[kind]?.help||'';
  const example=kind==='match'?'จับคู่ 水 กับ น้ำ':pinyinAnswers?'อ่าน 水 แล้วเลือก shuǐ':question?.type==='pinyin-hanzi'?'อ่าน shuǐ แล้วเลือก 水':meaningAnswers?'อ่าน 水 แล้วเลือก น้ำ':kind==='bubbles'?'แตะฟองที่แปลว่า น้ำ':'เลือกคำที่แปลว่า น้ำ';
  const options=pinyinAnswers?['shuǐ','shū','xuéxiào']:meaningAnswers?['น้ำ','หนังสือ','โรงเรียน']:['水','书','学校'];
  dialog.innerHTML=`<button class="tutorial-close" data-tutorial="close" aria-label="ปิดวิธีเล่น">✕</button><span class="eyebrow">${listening?'ฟัง → เลือกความหมาย':boss?'หลบ → ยิง → ปิดฉาก':'ลองเล่นหนึ่งข้อ'}</span><h2>${UI.t(title)}</h2><p>${UI.t(help)}</p>${listening?'<button class="primary" data-tutorial="listen">🔊 ฟังตัวอย่าง</button>':boss?'<div class="tutorial-armor">🛡 เกราะบอส <b>5 / 5</b></div>':'<p class="tutorial-example">'+UI.t(example)+'</p>'}<div class="tutorial-options ${kind==='bubbles'?'tutorial-bubbles':''}">${options.map((v,i)=>`<button data-tutorial="answer-${i}">${meaningAnswers?UI.t(v):v}${!meaningAnswers&&!pinyinAnswers?Pinyin.html(['shuǐ','shū','xuéxiào'][i]):''}</button>`).join('')}</div><p id="tutorial-note" role="status">ตัวอย่างนี้ไม่คิดคะแนน</p><button class="primary" data-tutorial="start" hidden>${doneCallback?'เริ่มเลย →':'เข้าใจแล้ว · กลับไปเล่น'}</button>`;
 }

 function close(resume=true){dialog.close();doneCallback=null;if(resume&&exitPaused)cancelRoundExit();}
 dialog.addEventListener('click',e=>{const a=e.target.closest('[data-tutorial]')?.dataset.tutorial;if(!a)return;
  if(a==='close'){close();return;}
  if(a==='listen'){step=1;speak({zh:'水'});}
  if(a.startsWith('answer-')){if(kind==='listening'&&step===0){dialog.querySelector('#tutorial-note').textContent='ฟังก่อน แล้วลองเลือกคำตอบ';return;}const ok=a==='answer-0';dialog.querySelector('#tutorial-note').textContent=ok?'✓ ถูกต้อง! 水'+Pinyin.inline('shuǐ')+' = '+UI.t('น้ำ'):'ลองอีกครั้ง · น้ำ คือ 水';if(ok){step=2;if(kind==='boss')dialog.querySelector('.tutorial-armor').textContent='💥 เกราะบอส 4 / 5';dialog.querySelector('[data-tutorial="start"]').hidden=false;}}
  if(a==='start'&&step===2){try{localStorage.setItem('hanzi-howto-v1:'+kind,'done');}catch{}const next=doneCallback;close();if(next)next();}
 });
 dialog.addEventListener('cancel',e=>{e.preventDefault();close();});
 const help=document.getElementById('howto');if(help)help.onclick=()=>{const mode=active?sessionMode:document.getElementById('mode').value;if(active){requestRoundExit();document.getElementById('exit-dialog').close();}open(mode);};
 return {seen,open};
})();
