'use strict';
// Mirrors existing settings; canonical controls still own rules and persistence.
(()=>{
 const homeLevel=$('home-level'),homePinyin=$('home-pinyin');
 homeLevel.innerHTML=$('level').innerHTML;
 function sync(){homeLevel.value=$('level').value;homePinyin.checked=Pinyin.enabled;featureMode();}
 homeLevel.onchange=()=>{$('level').value=homeLevel.value;$('level').dispatchEvent(new Event('change',{bubbles:true}));sync();};
 homePinyin.onchange=()=>{$('pinyin').checked=homePinyin.checked;$('pinyin').dispatchEvent(new Event('change',{bubbles:true}));sync();};
 $('home-settings').onclick=()=>$('open-settings').click();
 $('level').addEventListener('change',sync);$('pinyin').addEventListener('change',sync);
 UI.onChange(()=>{sync();renderBoard();});
 const feedback=$('feedback-mode');try{feedback.value=localStorage.getItem('hanzi-feedback-v1')==='manual'?'manual':'auto';}catch{}
 feedback.onchange=()=>{try{localStorage.setItem('hanzi-feedback-v1',feedback.value);}catch{}};
 $('results-home').onclick=()=>{$('results').hidden=true;document.body.classList.remove('setup-open');$('mode-lobby').scrollIntoView({behavior:'smooth',block:'start'});
  // Training returns to the existing visible Modes navigation, never Guardian.
  // Other families retain their own accepted return behavior in this batch.
  const training=['practice','match','timed','endless','arcade','listening'].includes(sessionMode);
  if(training)queueMicrotask(()=>{
   const target=document.querySelector('.mission-nav a[href="#mode-lobby"]');
   if(!active&&$('results').hidden&&location.hash==='#mode-lobby'&&target?.getClientRects().length)target.focus({preventScroll:true});
  });
  else $('open-combat').focus({preventScroll:true});
 };
 // Use one settings label, not a second mode menu hidden behind Home.
 document.querySelector('#settings-panel>summary').textContent='ระดับศัพท์และตัวช่วย';
 window.HanziInterface={sync};sync();
})();
