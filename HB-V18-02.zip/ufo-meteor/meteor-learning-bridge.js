'use strict';
// Production route adapter for shared learning modules. These globals mirror
// the main controller's canonical selection helpers without loading its DOM.
const shuffle=a=>{const b=[...a];for(let i=b.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[b[i],b[j]]=[b[j],b[i]]}return b};
const equivalences=['哪里 哪儿','那里 那儿','这里 这儿','星期日 星期天','汉语 中文','饭店 饭馆','外 外边 外面','里 里面','后 后面','前 前面','上 上面','下 下面','学 学习','说 说话','睡 睡觉','事 事情','些 一些 有些 有的','帮 帮忙','但 但是','正 正在','能 会 可以','想 要','好看 漂亮','几 多少','日 天','玩 好玩儿','时 时间 时候','国 外国','男孩儿 小孩儿 小朋友 孩子','周 星期','跑 跑步','游 游泳','元 块','不错 好','不客气 没关系 没事','早 早上','快 快要','和 跟','出 出去 出来','进 进去 进来','制订 制定','擅长 善于','立即 立刻 马上','批 批准','当成 当作 看作 视为','姥姥 外婆','姥爷 外公','儿女 子女','泪 泪水 眼泪','停止 止 停','寻找 找 搜 搜索','好像 似乎 仿佛','提供 供给'];
const group=w=>equivalences.findIndex(s=>s.split(' ').includes(w.zh));
const compatible=(a,b)=>a.zh!==b.zh&&a.th!==b.th&&(!a.english||!b.english||a.english.toLowerCase()!==b.english.toLowerCase())&&(group(a)<0||group(a)!==group(b));
function distinct(source,count,seed=[],ordered=false){const result=[...seed];for(const w of ordered?source:shuffle(source)){if(result.every(a=>compatible(a,w)))result.push(w);if(result.length>=count)break}return result}
const $=id=>document.getElementById(id);
let learning={};
try{const saved=JSON.parse(localStorage.getItem('hanzi-learning-v1')||'{}');if(saved&&typeof saved==='object'&&!Array.isArray(saved))learning=saved;}catch{}
