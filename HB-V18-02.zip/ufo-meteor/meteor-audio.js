'use strict';
// Original, isolated UFO score and synthesis. No production audio/settings/data.
(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory();
 else root.MeteorAudio=factory();
})(typeof window==='undefined'?globalThis:window,()=>{
 const BPM=112,BEAT=60/BPM,BARS=8,RATE=24000;
 const frequency=midi=>440*Math.pow(2,(midi-69)/12);
 function random(seed){let n=seed>>>0;return ()=>{n^=n<<13;n^=n>>>17;n^=n<<5;return (n>>>0)/4294967296*2-1;};}
 // Eight-bar D-minor / Bb / F / C score. Events wrap into the same stereo buffer,
 // including release/echo tails: the last beat and first beat share one timeline.
 function compose(sampleRate=RATE){
  const length=Math.round(BEAT*BARS*4*sampleRate),left=new Float32Array(length),right=new Float32Array(length),rnd=random(0x55464f31);
  function add(at,duration,voice,pan=0){
   const start=Math.round(at*sampleRate),count=Math.ceil(duration*sampleRate),l=Math.sqrt((1-pan)/2),r=Math.sqrt((1+pan)/2);
   for(let i=0;i<count;i++){const t=i/sampleRate,value=voice(t,i),j=((start+i)%length+length)%length;left[j]+=value*l;right[j]+=value*r;}
  }
  const roots=[38,34,41,36],chords=[[50,53,57,60],[46,50,53,57],[53,57,60,64],[48,52,55,62]];
  for(let bar=0;bar<BARS;bar++){
   const chord=Math.floor(bar/2),root=frequency(roots[chord]);
   if(bar%2===0)for(let n=0;n<4;n++){
    const f=frequency(chords[chord][n]),duration=BEAT*8+.35;
    add(bar*4*BEAT,duration,t=>{
     const envelope=Math.min(1,t/.35)*Math.min(1,Math.max(0,(duration-t)/.5));
     return (Math.sin(2*Math.PI*f*t)+.25*Math.sin(2*Math.PI*f*2.002*t))*.022*envelope;
    },(n%2?1:-1)*.6);
   }
   for(let beat=0;beat<4;beat++){
    const at=(bar*4+beat)*BEAT;
    add(at,.22,t=>Math.sin(2*Math.PI*(48*t+8*.035*(1-Math.exp(-t/.035))))*.16*Math.exp(-t*23));
    for(let eighth=0;eighth<2;eighth++){
     const hit=at+eighth*BEAT/2,accent=eighth===0?1:.55;
     add(hit,BEAT*.4,t=>{
      const envelope=Math.min(1,t/.012)*Math.exp(-t*12),phase=2*Math.PI*root*t;
      return (Math.sin(phase)+.25*Math.sin(phase*2)+.1*Math.sin(phase*3))*.11*accent*envelope;
     });
     let prior=0;add(hit,.055,(t)=>{const white=rnd(),high=white-prior;prior=white;return high*.018*Math.exp(-t*85);},eighth?.3:-.25);
    }
    if(beat===1||beat===3){let smooth=0;add(at,.12,t=>{smooth=smooth*.75+rnd()*.25;return smooth*.085*Math.exp(-t*28);});}
    if((bar+beat)%3!==0){
     const f=frequency(chords[chord][(beat+bar)%4]+12),pan=beat%2?.42:-.42;
     const pluck=t=>(Math.sin(2*Math.PI*f*t)+.18*Math.sin(2*Math.PI*f*2*t))*.043*Math.min(1,t/.009)*Math.exp(-t*11);
     add(at+BEAT/2,.38,pluck,pan);add(at+BEAT*1.25,.38,t=>pluck(t)*.25,-pan);
    }
   }
  }
  let peak=0;for(let i=0;i<length;i++)peak=Math.max(peak,Math.abs(left[i]),Math.abs(right[i]));
  const scale=.6/Math.max(.6,peak);for(let i=0;i<length;i++){left[i]*=scale;right[i]*=scale;}
  return {left,right,sampleRate,bpm:BPM,bars:BARS,duration:length/sampleRate};
 }
 class Audio{
  constructor({host=typeof window==='undefined'?{}:window,storage,onInterrupted=()=>{}}={}){
   this.host=host;this.storage=storage;try{this.storage??=host.localStorage;}catch{}
   this.global=host.HanziAudio;this.global?.handoff(true);this.music=this.global?this.global.prefs.music:this.read('hanzi-ufo-music');this.sfx=this.global?this.global.prefs.sfx:this.read('hanzi-ufo-sfx','hanzi-fx');this.onInterrupted=onInterrupted;
   this.ctx=null;this.active=false;this.allowed=false;this.disposed=false;this.generation=0;this.unlocking=false;this.voices=new Set();
   this.track=null;this.musicSource=null;this.musicOffset=0;this.musicAt=0;this.noise=null;this.duckUntil=0;this.duckDepth=1;this.speechDuck=false;this.failed=false;
   if(this.global)this.global.externalState=()=>this.state;
   this.unsubscribe=this.global?.subscribe(p=>{const wasMusic=this.music;this.music=p.music;this.sfx=p.sfx;if(!this.music)this.stopMusic();else if(!wasMusic)this.ensureMusic();if(!this.sfx)this.stopVoices();if(this.sfxBus)this.sfxBus.gain.value=.8*p.sfxVolume/.6;this.speech(this.speechDuck);});
  }
  read(key,fallback=null){try{const value=this.storage?.getItem(key);return (value===null&&fallback?this.storage?.getItem(fallback):value)!=='off';}catch{return true;}}
  save(key,value){try{this.storage?.setItem(key,value?'on':'off');}catch{}}
  validGesture(event){return event?.isTrusted===true&&['pointerdown','click','keydown'].includes(event.type)&&!event.repeat;}
  unlock(event){
   if(this.disposed||!this.active||!this.validGesture(event)||(!this.music&&!this.sfx))return false;
   const token=this.generation;
   this.global?.unlock(event);
   try{
    if(!this.ctx){
     const Context=this.host.AudioContext||this.host.webkitAudioContext;if(!Context){this.failed=true;return false;}
     this.ctx=this.global?this.global.context():new Context();const c=this.ctx;
     this.musicBus=c.createGain();this.sfxBus=c.createGain();this.master=c.createGain();this.limiter=c.createDynamicsCompressor();
     this.musicBus.gain.value=this.musicLevel();this.sfxBus.gain.value=.8*(this.global?.prefs.sfxVolume??.6)/.6;this.master.gain.value=.75;
     this.limiter.threshold.value=-12;this.limiter.knee.value=10;this.limiter.ratio.value=5;this.limiter.attack.value=.004;this.limiter.release.value=.18;
     this.musicBus.connect(this.master);this.sfxBus.connect(this.master);this.master.connect(this.global?this.global.limiter:this.limiter);if(!this.global)this.limiter.connect(c.destination);
     c.onstatechange=()=>{if(!this.disposed&&this.active&&(c.state==='interrupted'||c.state==='suspended'&&!this.unlocking)){this.pause();this.onInterrupted();}};
    }
    this.allowed=true;this.failed=false;this.unlocking=true;
    // resume() is called synchronously in the actual gesture, before buffer work.
    const resumed=this.ctx.resume();
    if(this.ctx.state==='running')this.ensureMusic();
    Promise.resolve(resumed).then(()=>{
     if(token!==this.generation||this.disposed){if(!this.active&&this.ctx?.state==='running')this.suspend();return;}
     this.unlocking=false;if(this.active&&this.allowed&&this.ctx.state==='running')this.ensureMusic();
    }).catch(()=>{if(token===this.generation){this.unlocking=false;this.allowed=false;this.failed=true;}});
    return true;
   }catch{this.unlocking=false;this.allowed=false;this.failed=true;return false;}
  }
  musicLevel(){return .3*(this.global?.prefs.musicVolume??.4)/.4;}
  ensureMusic(){
   if(!this.active||!this.allowed||!this.music||this.musicSource||this.ctx?.state!=='running')return;
   if(!this.track){const data=compose();this.track=this.ctx.createBuffer(2,data.left.length,data.sampleRate);this.track.getChannelData(0).set(data.left);this.track.getChannelData(1).set(data.right);}
   const source=this.ctx.createBufferSource();source.buffer=this.track;source.loop=true;source.connect(this.musicBus);
   this.musicBus.gain.cancelScheduledValues(this.ctx.currentTime);this.musicBus.gain.setValueAtTime(0,this.ctx.currentTime);this.musicBus.gain.linearRampToValueAtTime(this.musicLevel(),this.ctx.currentTime+.12);
   source.start(this.ctx.currentTime,this.musicOffset%this.track.duration);this.musicAt=this.ctx.currentTime;this.musicSource=source;this.global?.log('ufo-track-start');
  }
  stopMusic(reset=false){
   if(this.musicSource){this.musicOffset=(this.musicOffset+Math.max(0,this.ctx.currentTime-this.musicAt))%this.track.duration;try{this.musicSource.stop();this.musicSource.disconnect();}catch{}this.musicSource=null;}
   if(reset)this.musicOffset=0;this.global?.log('ufo-track-stop');
  }
  suspend(){try{Promise.resolve(this.ctx?.suspend()).catch(()=>{});}catch{}}
  start(event){if(this.disposed)return;this.generation++;this.stopVoices();this.stopMusic(true);this.active=true;this.allowed=false;this.duckUntil=0;this.duckDepth=1;this.speechDuck=false;this.unlock(event);}
  resume(event){if(this.disposed)return;this.generation++;this.active=true;this.allowed=false;this.unlock(event);}
  pause(){if(this.disposed)return;this.generation++;this.active=false;this.allowed=false;this.unlocking=false;this.speechDuck=false;this.stopVoices();this.suspend();this.global?.log('ufo-pause');}
  exit(){this.pause();this.stopMusic(true);this.duckUntil=0;this.duckDepth=1;this.speechDuck=false;}
  dispose(){if(this.disposed)return;this.exit();this.disposed=true;this.unsubscribe?.();if(this.ctx)this.ctx.onstatechange=null;for(const node of [this.musicBus,this.sfxBus,this.master,this.limiter])try{node?.disconnect();}catch{}if(this.global){this.global.externalState=null;this.global.handoff(false);}else if(this.ctx){try{Promise.resolve(this.ctx.close()).catch(()=>{});}catch{}}this.track=this.noise=null;}
  toggleMusic(event){if(this.global){this.global.setPreference('music',!this.music);if(this.music)this.unlock(event);return this.music;}this.music=!this.music;this.save('hanzi-ufo-music',this.music);if(!this.music)this.stopMusic();else this.unlock(event);return this.music;}
  toggleSfx(event){if(this.global){this.global.setPreference('sfx',!this.sfx);if(this.sfx)this.unlock(event);return this.sfx;}this.sfx=!this.sfx;this.save('hanzi-ufo-sfx',this.sfx);if(!this.sfx)this.stopVoices();else this.unlock(event);return this.sfx;}
  stopVoices(){for(const voice of [...this.voices]){try{voice.source.stop();}catch{}voice.clean();}}
  duck(depth,duration){
   if(!this.musicSource||this.ctx?.state!=='running')return;const now=this.ctx.currentTime,param=this.musicBus.gain;
   this.duckDepth=now<this.duckUntil?Math.min(this.duckDepth,depth):depth;this.duckUntil=Math.max(now+duration,this.duckUntil);
   if(param.cancelAndHoldAtTime)param.cancelAndHoldAtTime(now);else{const value=param.value;param.cancelScheduledValues(now);param.setValueAtTime(value,now);}
   param.linearRampToValueAtTime(this.musicLevel()*this.duckDepth,now+.018);param.setValueAtTime(this.musicLevel()*this.duckDepth,this.duckUntil);param.linearRampToValueAtTime(this.musicLevel(),this.duckUntil+.18);
  }
  speech(active){
   this.speechDuck=!!active;if(!this.musicSource||this.ctx?.state!=='running')return;const now=this.ctx.currentTime,param=this.musicBus.gain;
   if(param.cancelAndHoldAtTime)param.cancelAndHoldAtTime(now);else{const value=param.value;param.cancelScheduledValues(now);param.setValueAtTime(value,now);}
   if(active){param.linearRampToValueAtTime(Math.min(this.musicLevel()*this.duckDepth,this.musicLevel()*.35),now+.05);return;}
   if(now<this.duckUntil){param.linearRampToValueAtTime(this.musicLevel()*this.duckDepth,now+.04);param.setValueAtTime(this.musicLevel()*this.duckDepth,this.duckUntil);param.linearRampToValueAtTime(this.musicLevel(),this.duckUntil+.18);}
   else param.linearRampToValueAtTime(this.musicLevel(),now+.18);
  }
  voice(source,level,duration,delay=0,filter=null){
   if(this.voices.size>=32){const oldest=this.voices.values().next().value;try{oldest.source.stop();}catch{}oldest.clean();}
   const c=this.ctx,at=c.currentTime+delay,gain=c.createGain(),voice={source,clean:null};
   gain.gain.setValueAtTime(.0001,at);gain.gain.linearRampToValueAtTime(level,at+.003);gain.gain.exponentialRampToValueAtTime(.0001,at+duration);
   source.connect(filter||gain);if(filter)filter.connect(gain);gain.connect(this.sfxBus);
   voice.clean=()=>{this.voices.delete(voice);for(const node of [source,filter,gain])try{node?.disconnect();}catch{}};
   source.onended=voice.clean;this.voices.add(voice);source.start(at);source.stop(at+duration+.006);
  }
  tone(from,to,duration,level,type='sine',delay=0){const o=this.ctx.createOscillator();o.type=type;const at=this.ctx.currentTime+delay;o.frequency.setValueAtTime(from,at);o.frequency.exponentialRampToValueAtTime(to,at+duration);this.voice(o,level,duration,delay);}
  grit(duration,level,type,frequency,delay=0){
   const c=this.ctx;if(!this.noise){this.noise=c.createBuffer(1,Math.ceil(c.sampleRate*.65),c.sampleRate);const data=this.noise.getChannelData(0),rnd=random(0x726f636b);for(let i=0;i<data.length;i++)data[i]=rnd();}
   const source=c.createBufferSource(),filter=c.createBiquadFilter();source.buffer=this.noise;filter.type=type;filter.frequency.value=frequency;filter.Q.value=.65;this.voice(source,level,duration,delay,filter);
  }
  play(kind){
   if(!this.active||!this.allowed||this.disposed||this.ctx?.state!=='running')return false;
   const ducks={contact:[.6,.1],breakup:[.22,.4],correct:[.42,.22],wrong:[.42,.22],'game-over':[.12,.9]};
   if(ducks[kind])this.duck(...ducks[kind]);
   if(!this.sfx)return false;
   switch(kind){
    case 'fire':this.tone(1450,380,.105,.085,'triangle');this.tone(110,65,.08,.05);this.grit(.03,.045,'highpass',2300);break;
    case 'contact':this.grit(.045,.14,'bandpass',1500);this.tone(520,240,.045,.07);break;
    case 'breakup':this.tone(106,42,.24,.26);this.grit(.26,.13,'lowpass',650);this.grit(.085,.15,'bandpass',900);this.grit(.32,.038,'highpass',2200,.025);this.tone(190,75,.085,.07,'triangle',.045);break;
    case 'correct':this.tone(587,587,.19,.055,'sine');this.tone(880,880,.17,.04,'sine',.045);break;
    case 'wrong':this.tone(260,190,.16,.055,'triangle');this.tone(183,146,.12,.035,'sine',.045);break;
    case 'shield':this.tone(1500,900,.12,.045,'triangle');this.tone(400,400,.18,.035);break;
    case 'wave':this.tone(220,440,.12,.028,'sine');break;
    case 'game-over':for(const [i,f] of [349,261,196,146].entries())this.tone(f,f,.24,i===3?.07:.045,'triangle',i*.09);break;
    default:return false;
   }return true;
  }
  get state(){return {context:this.ctx?.state||'locked',music:this.music,sfx:this.sfx,musicInstances:this.musicSource?1:0,voices:this.voices.size,active:this.active,speechDuck:this.speechDuck,failed:this.failed};}
 }
 return {create:options=>new Audio(options),Audio,compose,BPM};
});
