'use strict';
// Presentation/session adapter: physics still owns A/B/C correctness and timing.
(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory;
 else root.MeteorLearning=factory({words,VocabularyDataset,HSK,LearningEngine,ChoiceMemory,LearningAudio,shuffle,distinct,storage:root.localStorage,host:root});
})(typeof window==='undefined'?globalThis:window,deps=>{
 const labels=['A','B','C'],languageKey='hanzi-ui-language-v1',levelKey='hanzi-ufo-level-v1';
 const copy=w=>w&&({id:w.id,canonicalId:w.canonicalId,zh:w.zh,py:w.py,th:w.th,english:w.english,level:w.level,hskLevel:w.hskLevel,partOfSpeech:w.partOfSpeech});
 const read=(key,fallback)=>{try{return deps.storage?.getItem(key)||fallback;}catch{return fallback;}};
 const write=(key,value)=>{try{deps.storage?.setItem(key,value);}catch{}};
 const validLanguage=value=>['th','en'].includes(value)?value:'th';
 const sameType=(a,b)=>a.partOfSpeech&&b.partOfSpeech&&String(a.partOfSpeech).split('、')[0]===String(b.partOfSpeech).split('、')[0];
 class Session{
  constructor({onResult=()=>{}}={}){
   this.language=validLanguage(read(languageKey,'th'));this.level=deps.HSK.normalize(read(levelKey,'1'));if(this.level==='all')this.level='1';
   this.onResult=onResult;this.current=null;this.recent=[];this.session=0;this.lastResult=null;this.speaking=false;
  }
  start(){this.cancelSpeech();this.session++;this.current=null;this.recent=[];this.lastResult=null;deps.LearningEngine.begin();}
  pool(){return deps.words.filter(w=>String(w.level)===this.level&&w.zh&&w.py&&w.th&&w.english);}
  wave(targetLabel,wave){
   const pool=this.pool(),recent=new Set(this.recent),fresh=pool.filter(w=>!recent.has(w.id)),source=fresh.length?fresh:pool;
   const target=deps.LearningEngine.roundDistinct(source,1,'ufo-meteor:hsk-'+this.level)[0]||pool[0];
   const typed=pool.filter(w=>w.id!==target.id&&sameType(target,w)),distractorSource=typed.length>=8?[...typed,...pool.filter(w=>!sameType(target,w))]:pool;
   let options=deps.ChoiceMemory.choose(distractorSource,3,[target]);
   if(options.length<3)options=deps.distinct(pool,3,options,true);
   const distractors=deps.shuffle(options.filter(w=>w.id!==target.id)).slice(0,2),byLabel={};let index=0;
   for(const label of labels)byLabel[label]=label===targetLabel?target:distractors[index++];
   this.recent.push(target.id);this.recent=this.recent.slice(-5);this.current={wave,target,targetLabel,byLabel};this.lastResult=null;deps.LearningEngine.mark();return this.current;
  }
  answer(label){return this.current?.byLabel[label]||null;}
  meaning(word=this.current?.target){return this.language==='en'?word?.english:word?.th;}
  prompt(){return this.current?(this.language==='th'?'ยิง: ':'Shoot: ')+this.meaning():this.language==='th'?'เลือก HSK แล้วเริ่มบิน':'Choose HSK and launch';}
  feedback(type,label,collision){
   if(!this.current)return null;const correct=type==='correct',target=this.current.target,chosen=this.answer(label),responseMs=deps.LearningEngine.elapsed();
   deps.LearningEngine.record(target,correct,responseMs);
   const payload=Object.freeze({mode:'ufo-meteor',session:this.session,wave:this.current.wave,hsk:+this.level,language:this.language,type,correct,target:copy(target),chosen:copy(chosen),collision:Object.freeze({x:collision.x,y:collision.y}),responseMs});
   this.lastResult=payload;this.onResult(payload);try{deps.host?.dispatchEvent?.(new CustomEvent('hanzi-ufo-learning-result',{detail:payload}));}catch{}return payload;
  }
  resultText(result=this.lastResult){if(!result)return '';if(result.correct)return `✓ ${result.target.zh} · ${result.target.py} · ${this.meaning(result.target)}`;return `✕ ${result.chosen.zh} · ${result.chosen.py} · ${this.language==='th'?'เป้า':'Target'}: ${result.target.zh}`;}
  setLanguage(value){this.language=validLanguage(value);write(languageKey,this.language);return this.language;}
  setLevel(value){const level=deps.HSK.normalize(value);this.level=level==='all'?'1':level;write(levelKey,this.level);return this.level;}
  speakCorrect(onEnd=()=>{}){const word=this.current?.target;if(!word)return false;this.cancelSpeech();this.speaking=true;deps.LearningAudio.speak(word.zh,()=>{this.speaking=false;onEnd(true);},()=>{this.speaking=false;onEnd(false);},.78);return true;}
  cancelSpeech(){this.speaking=false;deps.LearningAudio.cancel();}
  get dataset(){return deps.VocabularyDataset;}
  get progress(){return {engine:'LearningEngine',store:'hanzi-learning-v1',cloud:false};}
 }
 return {create:options=>new Session(options),Session};
});
