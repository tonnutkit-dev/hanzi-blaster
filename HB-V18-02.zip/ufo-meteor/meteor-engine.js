'use strict';
// Phase A only. No vocabulary, persistence, shared game state or audio dependencies.
(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory();
 else root.MeteorPhysics=factory();
})(typeof globalThis!=='undefined'?globalThis:this,()=>{
 const clamp=(v,min,max)=>Math.max(min,Math.min(max,v));
 const mix=(a,b,t)=>a+(b-a)*t;
 const RULES=Object.freeze({cooldown:.35,projectileSpeed:900,projectileLife:1.2,projectileCap:2,effectCap:12,waveBeat:.6});
 // Intersection in relative coordinates handles BOTH moving objects, including tunneling.
 function sweep(ax,ay,bx,by,r){
  const c=ax*ax+ay*ay-r*r;if(c<=0)return 0;
  const dx=bx-ax,dy=by-ay,a=dx*dx+dy*dy;if(a<1e-12)return null;
  const b=2*(ax*dx+ay*dy),d=b*b-4*a*c;if(d<0)return null;
  const t=(-b-Math.sqrt(d))/(2*a);return t>=0&&t<=1?t:null;
 }
 class Engine{
  constructor(width=360,height=600){this.width=width;this.height=height;this.phase='READY';this.ufo={x:width/2,y:height*.89};this.meteors=[];this.projectiles=[];this.effects=[];this.events=[];this.serial=0;this.wave=0;this.shield=3;this.score=0;this.combo=0;this.time=0;this.lastFire=-Infinity;this.penaltyCommitted=false;this.waveResolved=false;this.reason='';this.measure(width,height);}
  measure(w,h){this.width=Math.max(240,w);this.height=Math.max(180,h);this.danger=this.height*.68;this.radius=clamp(Math.min(this.width/10,this.height/9),22,44);this.bounds={left:32,right:this.width-32,top:this.height*.80,bottom:this.height-24};}
  emit(type,data={}){this.events.push({type,wave:this.wave,...data});if(this.events.length>32)this.events.shift();}
  drain(){const events=this.events;this.events=[];return events;}
  effect(kind,x,y){this.effects.push({id:++this.serial,kind,x,y,life:kind==='muzzle'?.12:.6});if(this.effects.length>RULES.effectCap)this.effects.shift();}
  start(){this.shield=3;this.score=this.combo=this.wave=this.time=0;this.lastFire=-Infinity;this.effects=[];this.events=[];this.ufo={x:this.width/2,y:mix(this.bounds.top,this.bounds.bottom,.6)};this.phase='READY';this.nextWave();}
  nextWave(){
   if(!['READY','FEEDBACK','GAME_OVER'].includes(this.phase))return false;
   if(this.phase!=='READY'&&this.shield===0){this.phase='GAME_OVER';return false;}
   this.wave++;this.target=['A','B','C'][(this.wave-1)%3];this.penaltyCommitted=this.waveResolved=false;this.projectiles=[];this.effects=[];this.lastFire=-Infinity;this.reason='';this.transitionRemaining=0;this.phase='ACTIVE';
   this.meteors=['A','B','C'].map((label,slot)=>{
    const x=this.width*(slot+.5)/3,y=clamp(this.height*(.14+((slot+this.wave)%3)*.11),this.radius+12,this.danger-this.radius-20);
    return {id:++this.serial,label,correct:label===this.target,slot,x,y,r:this.radius,vx:slot===1?-5:5,vy:Math.max(2,(this.danger-this.radius-y)/12),alive:true};
   });this.emit('wave');return true;
  }
  moveTo(x,y){if(this.phase!=='ACTIVE'||!Number.isFinite(x)||!Number.isFinite(y))return false;this.ufo.x=clamp(x,this.bounds.left,this.bounds.right);this.ufo.y=clamp(y,this.bounds.top,this.bounds.bottom);return true;}
  fire(){
   if(this.phase!=='ACTIVE'||this.waveResolved||this.time-this.lastFire<RULES.cooldown-1e-9||this.projectiles.length>=RULES.projectileCap)return false;
   const p={id:++this.serial,x:this.ufo.x,y:this.ufo.y-17,r:3,age:0,alive:true};this.projectiles.push(p);this.lastFire=this.time;this.effect('muzzle',p.x,p.y);this.emit('fire',{x:p.x,y:p.y});return true;
  }
  penalty(){if(this.penaltyCommitted)return false;this.penaltyCommitted=true;this.shield=Math.max(0,this.shield-1);return true;}
  resolve(reason){if(this.waveResolved||this.phase!=='ACTIVE')return;this.waveResolved=true;this.reason=reason;this.phase=this.shield===0?'GAME_OVER':'FEEDBACK';this.transitionRemaining=this.phase==='FEEDBACK'?RULES.waveBeat:0;this.projectiles=[];this.emit('resolved',{reason,target:this.target});}
  step(dt){
   if(this.phase==='PAUSED'||this.phase==='EXITING'||this.phase==='READY')return;
   if(!Number.isFinite(dt)||dt<=0)return;dt=Math.min(dt,.1);
   for(const e of this.effects)e.life-=dt;this.effects=this.effects.filter(e=>e.life>0);
   if(this.phase==='FEEDBACK'){this.transitionRemaining=Math.max(0,this.transitionRemaining-dt);if(this.transitionRemaining<1e-9)this.nextWave();return;}
   if(this.phase!=='ACTIVE')return;this.time+=dt;
   const motions=new Map(),events=[];
   for(const m of this.meteors){
    if(!m.alive)continue;const old={x:m.x,y:m.y};
    const center=this.width*(m.slot+.5)/3,margin=Math.max(0,this.width/6-m.r-10);
    const x=clamp(m.x+m.vx*dt,center-margin,center+margin);if(x!==m.x+m.vx*dt)m.vx*=-1;
    m.x=x;m.y+=m.vy*dt;motions.set(m.id,{old,end:{x:m.x,y:m.y}});
    if(m.y+m.r>=this.danger){const dy=m.y-old.y;events.push({t:dy>0?clamp((this.danger-m.r-old.y)/dy,0,1):0,kind:'escape',m});}
   }
   for(const p of this.projectiles){
    const old={x:p.x,y:p.y};p.y-=RULES.projectileSpeed*dt;p.age+=dt;
    for(const m of this.meteors){
     const motion=motions.get(m.id);if(!motion)continue;
     const t=sweep(old.x-motion.old.x,old.y-motion.old.y,p.x-motion.end.x,p.y-motion.end.y,m.r+p.r);
     if(t!==null)events.push({t,kind:'hit',m,p,x:mix(old.x,p.x,t),y:mix(old.y,p.y,t)});
    }
   }
   events.sort((a,b)=>a.t-b.t||(a.kind==='hit'?0:1)-(b.kind==='hit'?0:1)||a.m.id-b.m.id||(a.p?.id||0)-(b.p?.id||0));
   for(const e of events){
    if(this.phase!=='ACTIVE')break;if(!e.m.alive||(e.p&&!e.p.alive))continue;
    e.m.alive=false;
    if(e.kind==='hit'){
     e.p.alive=false;this.effect(e.m.correct?'correct':'wrong',e.x,e.y);
     if(e.m.correct){this.combo++;this.score+=100+Math.min(this.combo-1,5)*20;this.emit('correct',{label:e.m.label,x:e.x,y:e.y});this.resolve('correct');}
     else{const penalized=this.penalty();this.combo=0;this.emit('wrong',{label:e.m.label,penalized,x:e.x,y:e.y});}
    }else if(e.m.correct){const penalized=this.penalty();this.combo=0;this.emit('escape-correct',{penalized});this.resolve('escaped');}
    else this.emit('escape-distractor',{label:e.m.label});
   }
   this.projectiles=this.projectiles.filter(p=>p.alive&&p.y>=-p.r&&p.age<RULES.projectileLife);
  }
  pause(reason='manual'){if(!['ACTIVE','FEEDBACK','GAME_OVER'].includes(this.phase))return false;this.resumePhase=this.phase;this.phase='PAUSED';this.pauseReason=reason;return true;}
  resume(){if(this.phase!=='PAUSED')return false;this.phase=this.resumePhase;return true;}
  resize(w,h){
   if(!Number.isFinite(w)||!Number.isFinite(h)||w<=0||h<=0)return false;
   this.pause('resize');const sx=Math.max(240,w)/this.width,sy=Math.max(180,h)/this.height;this.measure(w,h);
   this.ufo.x=clamp(this.ufo.x*sx,this.bounds.left,this.bounds.right);this.ufo.y=clamp(this.ufo.y*sy,this.bounds.top,this.bounds.bottom);
   for(const m of this.meteors){m.x*=sx;m.y=clamp(m.y*sy,this.radius+4,this.danger-this.radius-1);m.r=this.radius;m.vy*=sy;const center=this.width*(m.slot+.5)/3,margin=Math.max(0,this.width/6-m.r-10);m.x=clamp(m.x,center-margin,center+margin);}
   // A new coordinate system must never create a phantom collision from an old shot.
   this.projectiles=[];this.effects=[];return true;
  }
  exit(){this.phase='EXITING';this.projectiles=[];this.meteors=[];this.effects=[];this.events=[];this.resumePhase=null;this.transitionRemaining=0;}
 }
 return {Engine,sweep,RULES};
});
