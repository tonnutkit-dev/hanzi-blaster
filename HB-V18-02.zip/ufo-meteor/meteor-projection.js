'use strict';
// Camera only. No simulation state, input conversion, clock or side effects.
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.MeteorProjection=factory();})(typeof globalThis!=='undefined'?globalThis:this,()=>{
 function create(width,danger,strength=.3){
  if(!(width>0&&danger>0&&strength>=0&&strength<=.3))throw new RangeError('Invalid meteor camera');
  const a=1-strength,b=strength/danger,c=width/2;
  // A planar perspective camera ends exactly at the danger line. The entire
  // player/input plane remains identity; all approaching actors share this map.
  const matrix=[a,0,0,0,-c*b,a,0,-b,0,0,1,0,c*strength,0,0,1];
  const inverse=[1,0,0,0,c*b,1,0,b,0,0,1,0,-c*strength,0,0,a];
  const css='matrix3d('+matrix.join(',')+')',undo='matrix3d('+inverse.join(',')+')';
  function point(x,y){if(y>=danger)return {x,y,scale:1};const scale=a/(1-b*y);return {x:c+(x-c)*scale,y:y*scale,scale};}
  function unproject(x,y){if(y>=danger)return {x,y};const d=a+b*y;return {x:c+(x-c)/d,y:y/d};}
  function transform(x,y,planeY=y){return (planeY<danger?css+' ':'')+`translate(${x}px,${y}px)`;}
  // Cancel the parent's camera for live text only. Rock silhouette/collider,
  // projectile core and impact contact keep the same projective transform.
  function billboard(left,top,x,y,width){return `translate(${-left}px,${-top}px) ${undo} translate(${x-width/2}px,${y}px) translateY(-50%)`;}
  return Object.freeze({width,danger,matrix:Object.freeze(matrix),inverse:Object.freeze(inverse),point,unproject,transform,billboard});
 }
 return Object.freeze({create});
});
