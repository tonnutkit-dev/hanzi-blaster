'use strict';
// Pinned Hanzi Writer rendererOverride adapter. Only input transport is customized;
// all matching, order, stroke paths, and canonical fill remain in Hanzi Writer.
const WritingEngine=(()=>{
 const ns='http://www.w3.org/2000/svg';
 const options=Object.freeze({leniency:1,acceptBackwardsStrokes:false,markStrokeCorrectAfterMisses:false,showHintAfterMisses:false,highlightOnComplete:true});
 class Target{
  constructor(node,defs){this.node=this.svg=node;this.defs=defs;this.pointer=null;this.controller=new AbortController();}
  createSubRenderTarget(){const g=document.createElementNS(ns,'g');this.svg.appendChild(g);return new Target(g,this.defs);}
  getBoundingClientRect(){return this.node.getBoundingClientRect();}
  updateDimensions(w,h){this.node.setAttribute('width',w);this.node.setAttribute('height',h);}
  addPointerStartListener(fn){this.start=fn;}
  addPointerMoveListener(fn){this.move=fn;}
  addPointerEndListener(fn){this.end=fn;}
  event(e){const r=this.getBoundingClientRect();return {getPoint:()=>({x:e.clientX-r.left,y:e.clientY-r.top}),preventDefault:()=>e.preventDefault()};}
  bind(onCancel,canStart=()=>true){
   const listen=(name,fn)=>this.node.addEventListener(name,fn,{passive:false,signal:this.controller.signal});
   listen('pointerdown',e=>{if(!canStart()||this.pointer!==null||e.isPrimary===false||(e.pointerType==='mouse'&&e.button!==0))return;e.preventDefault();this.pointer=e.pointerId;try{this.node.setPointerCapture(e.pointerId);this.start(this.event(e));}catch(error){this.release();throw error;}});
   listen('pointermove',e=>{if(e.pointerId!==this.pointer)return;e.preventDefault();const points=e.getCoalescedEvents?.();for(const p of points?.length?points:[e])this.move(this.event(p));});
   listen('pointerup',e=>{if(e.pointerId!==this.pointer)return;e.preventDefault();try{this.move(this.event(e));}finally{this.release();}this.end();});
   const cancel=e=>{if(e.pointerId!==this.pointer)return;this.release();onCancel();};
   listen('pointercancel',cancel);listen('lostpointercapture',cancel);
   // iOS fallbacks: block browser gestures only on this surface, never the dialog.
   for(const name of ['touchstart','touchmove','contextmenu','selectstart','dragstart'])listen(name,e=>e.preventDefault());
  }
  release(){const id=this.pointer;this.pointer=null;if(id!==null&&this.node.hasPointerCapture(id))this.node.releasePointerCapture(id);}
  destroy(){this.release();this.controller.abort();}
 }
 const createTarget=(element,width,height)=>{const svg=document.createElementNS(ns,'svg'),defs=document.createElementNS(ns,'defs');svg.appendChild(defs);element.appendChild(svg);const target=new Target(svg,defs);target.updateDimensions(width,height);return target;};
 return {options,createTarget};
})();
