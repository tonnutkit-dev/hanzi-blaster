'use strict';
const BubbleField=(()=>{
 let particles=[],raf=null,last=0,width=0,height=0,size=0,paused=false,remaining=0,limit=18000;
 const root=$('targets');
 const stage=()=>Math.min(4,1+Math.floor(answered/5));
 function bounds(){width=Math.max(240,root.clientWidth||300);height=Math.max(340,root.clientHeight||420);size=Math.min(112,Math.floor((width-24)/3));}
 function place(){bounds();const cols=Math.max(1,Math.floor(width/(size+4))),rows=Math.ceil(particles.length/cols),xs=width/cols,ys=height/rows;size=Math.min(size,ys-6);particles.forEach((p,i)=>{p.x=(i%cols)*xs+(xs-size)/2;p.y=Math.floor(i/cols)*ys+(ys-size)/2;p.el.style.width=p.el.style.height=size+'px';paint(p)});}
 function paint(p){p.el.style.transform=`translate(${p.x}px,${p.y}px)`;}
 function step(dt){for(const p of particles){p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.x<0||p.x>width-size){p.x=Math.max(0,Math.min(width-size,p.x));p.vx*=-1;}if(p.y<0||p.y>height-size){p.y=Math.max(0,Math.min(height-size,p.y));p.vy*=-1;}}
  for(let i=0;i<particles.length;i++)for(let j=i+1;j<particles.length;j++){const a=particles[i],b=particles[j],dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy);if(d>0&&d<size+3){const nx=dx/d,ny=dy/d,overlap=(size+3-d)/2;a.x-=nx*overlap;a.y-=ny*overlap;b.x+=nx*overlap;b.y+=ny*overlap;const closing=(a.vx-b.vx)*nx+(a.vy-b.vy)*ny;if(closing>0){a.vx-=closing*nx;a.vy-=closing*ny;b.vx+=closing*nx;b.vy+=closing*ny;}}}
  for(const p of particles){p.x=Math.max(0,Math.min(width-size,p.x));p.y=Math.max(0,Math.min(height-size,p.y));paint(p);}}
 function frame(now){raf=null;if(!active||sessionMode!=='bubbles'||locked||paused)return;step(Math.min(.035,Math.max(0,(now-last)/1000)));last=now;raf=requestAnimationFrame(frame);}
 function freeze(){if(raf!==null)cancelAnimationFrame(raf);raf=null;}
 function stop(){freeze();particles=[];paused=false;$('bubble-status').hidden=true;$('bubble-cover').hidden=true;document.querySelector('.arena').classList.remove('bubble-mode');}
 function show(){freeze();paused=false;$('bubble-cover').hidden=true;document.querySelector('.arena').classList.add('bubble-mode');$('bubble-status').hidden=false;const n=stage(),speed=24+n*15;limit=18000-(n-1)*2000;questionDeadline=performance.now()+limit;particles=[...root.children].map((el,i)=>{const angle=(i*2.399)+Math.random()*.4;return {el,x:0,y:0,vx:Math.cos(angle)*speed,vy:Math.sin(angle)*speed}});place();$('bubble-stage').textContent=`ด่าน ${n}/4 · ${particles.length} ฟอง · ${limit/1000} วินาที/ข้อ`;$('bubble-pause').disabled=false;last=performance.now();raf=requestAnimationFrame(frame);if(document.hidden)pause();}
 function pause(){if(!active||locked||sessionMode!=='bubbles'||paused)return;remaining=Math.max(0,questionDeadline-performance.now());paused=true;freeze();$('bubble-cover').hidden=false;}
 function resume(){if(!paused||!active||sessionMode!=='bubbles')return;paused=false;LearningEngine.mark();$('bubble-cover').hidden=true;questionDeadline=performance.now()+remaining;last=performance.now();raf=requestAnimationFrame(frame);}
 function tick(){if(paused||locked)return;const left=Math.max(0,questionDeadline-performance.now());$('timebar').style.width=(left/limit*100)+'%';$('timebar').style.background=left<4000?'#ff7180':'var(--lime)';if(!left)shoot(-1);}
 $('bubble-pause').onclick=pause;$('bubble-resume').onclick=resume;
 document.addEventListener('visibilitychange',()=>{if(document.hidden)pause()});window.addEventListener('resize',()=>{if(active&&sessionMode==='bubbles'){if(!locked)pause();place();}});
 return {stage,show,stop,freeze,tick,pause,resume,get paused(){return paused}};
})();
function showBubbleQuestion(){locked=false;LearningEngine.mark();MiniEvents.before();current=draw();const count=Math.min(10,6+(BubbleField.stage()-1)*2);choices=shuffle(ChoiceMemory.choose(selectedWords(),count,[current]));$('prompt').dataset.learning='true';$('prompt').textContent=UI.meaning(current);$('question-label').textContent='แตะฟองคำจีนที่แปลว่า';$('feedback').textContent='แตะฟองที่ถูก · คีย์บอร์ด 1–9 และ 0 · ตอบแล้วไปต่ออัตโนมัติ';$('feedback').style.color='';$('listen').hidden=true;$('next').hidden=true;$('targets').replaceChildren();choices.forEach((w,i)=>{const b=document.createElement('button');b.className='target word-bubble bubble-'+i%4;b.setAttribute('aria-label',`ตัวเลือก ${i+1}: ${w.zh}${config.pinyin?' '+w.py:''}`);const k=document.createElement('span');k.className='key';k.textContent=i===9?'0':i+1;const z=document.createElement('span');z.className='hanzi';z.lang='zh-CN';z.textContent=w.zh;const p=document.createElement('span');p.className='pinyin';p.textContent=w.py;b.append(k,z);if(Pinyin.enabled)b.append(p);b.onpointerdown=e=>{if(e.button>0)return;e.preventDefault();shoot(i)};b.onclick=e=>{if(e.detail===0)shoot(i)};$('targets').append(b)});hud();BubbleField.show();}
function startBubbles(){if(active)return;$('mode').value='bubbles';settings();start();}
$('bubble-card').onclick=startBubbles;
function featureMode(){
 const modes=[
  ...(['1','2','all'].includes($('level').value)?[{id:'sentences',label:'เล่นภารกิจประโยค ↗',meta:'เติมคำ · แปลความหมาย · ตอบบทสนทนา',play:()=>sentenceGame.open()}]:[]),
  ...(LearningEngine.weak(selectedWords()).length?[{id:'weak',label:'ทบทวนคำที่ยังไม่แม่น ↗',meta:'รอบสั้นจากคำที่ควรกลับมาฝึก',play:()=>startWeakRound()}]:[]),
  {id:'bubbles',label:'เล่นฟองศัพท์เด้ง ↗',meta:'6–10 ฟอง · เร็วขึ้นทุก 5 ข้อ · 3 ชีวิต',play:startBubbles},
  {id:'campaign',label:'ออกผจญภัยจีน ↗',meta:'ฝึกคำ → สู้บอส → ปลดล็อกภารกิจ',play:()=>$('quick-start').onclick()},
  {id:'combat',label:'ท้าผู้พิทักษ์สายฟ้า ↗',meta:'ฟังแล้วหลบ · ยิงเกราะ · ปล่อยสายฟ้า',play:()=>$('open-combat').onclick()},
  {id:'daily',label:'ทบทวนวันนี้ ↗',meta:'ทบทวนสั้น ๆ 5 คำ · เก็บคำที่ยังไม่แม่น',play:()=>$('daily-review').onclick()},
  ...[['practice','ฝึกจำคำศัพท์','ค่อย ๆ จำ · ตอบแล้วไปต่ออัตโนมัติ'],['match','เล่นจับคู่คำศัพท์','จับคู่คำจีนกับความหมาย'],['timed','เล่นยิงจับเวลา','แข่งกับเวลา · เก็บคอมโบทำคะแนน'],['endless','เล่นไม่สิ้นสุด','3 ชีวิต · ดูว่าจะไปได้ไกลแค่ไหน'],['arcade','เล่นท้าทาย 15 คำ','ตอบให้แม่น · ทำคะแนนให้ดีที่สุด']].map(([id,label,meta])=>({id,label:label+' ↗',meta,play:()=>{if(active)return;$('mode').value=id;settings();start();}}))
 ];
 const selected=modes.find(m=>m.id===(LearningEngine.weak(selectedWords()).length?'weak':'daily'));featureMode.last=selected.id;
 try{localStorage.setItem('hanzi-featured-mode',selected.id);}catch{}
 $('open-bubbles').textContent=selected.label;$('open-bubbles').onclick=selected.play;
 $('open-bubbles').dataset.mode=selected.id;$('featured-meta').textContent=selected.meta;
}
featureMode();
window.addEventListener('pageshow',event=>{if(event.persisted)featureMode();});
