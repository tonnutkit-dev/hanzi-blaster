'use strict';
// Move the original controls without cloning their handlers or progress child IDs.
(()=>{
 const grid=document.querySelector('.mode-grid');
 // Preserve Guardian's control/handler for reuse, but remove it from the hub.
 const guardian=document.getElementById('open-combat');if(guardian)guardian.hidden=true;
 const feature=document.createElement('section');feature.className='featured-mission';feature.dataset.featured='true';feature.setAttribute('aria-labelledby','ufo-meteor-title');
 const scene=document.createElement('img');scene.className='mission-scene';scene.src='assets/hub-ufo-v1r.webp';scene.alt='';scene.decoding='async';scene.width=700;scene.height=467;scene.setAttribute('aria-hidden','true');
 const copy=document.createElement('div');copy.className='mission-copy';
 const kicker=document.createElement('span');kicker.className='mission-kicker';kicker.textContent='โหมดแนะนำ';
 const title=document.createElement('h3');title.id='ufo-meteor-title';title.innerHTML='<span>UFO</span><span>METEOR</span>';
 const description=document.createElement('p');description.textContent='ยิงคำจีนให้ตรงความหมาย';
 const levelLabel=document.createElement('label');levelLabel.className='mission-level';levelLabel.setAttribute('for','mission-level');
 const levelName=document.createElement('span');levelName.className='sr-only';levelName.textContent='ระดับคำศัพท์';
 const level=document.createElement('select');level.id='mission-level';levelLabel.append(levelName,level);
 copy.append(kicker,title,levelLabel,description);
 const ufo=document.createElement('button');ufo.id='ufo-meteor-card';ufo.className='mission-play';ufo.dataset.mode='ufo-meteor-card';ufo.dataset.worldMode='ufo-meteor';ufo.dataset.tier='featured';ufo.setAttribute('aria-label','เล่น UFO METEOR');
 const playIcon=document.createElement('span');playIcon.textContent='▶';playIcon.setAttribute('aria-hidden','true');const playText=document.createElement('span');playText.textContent='เล่น';ufo.append(playIcon,playText);
 const ufoCopy=()=>{kicker.textContent=UI.t('โหมดแนะนำ');description.textContent=UI.t('ยิงคำจีนให้ตรงความหมาย');playText.textContent=UI.t('เล่น');ufo.setAttribute('aria-label',UI.t('เล่น UFO METEOR'));};
 ufo.onclick=()=>{LearningAudio.cancel();battleAudio.stop();location.assign('ufo-meteor/');};ufoCopy();UI.onChange?.(ufoCopy);
 const foreground=document.createElement('div');foreground.className='mission-foreground';foreground.setAttribute('aria-hidden','true');foreground.append(scene);
 const rocks=document.createElement('div');rocks.className='mission-rocks';
 const rockImage=document.createElement('img');rockImage.className='mission-rock-image';rockImage.src='assets/hub-rocks-v1r.webp';rockImage.alt='';rockImage.width=700;rockImage.height=350;rockImage.decoding='async';rocks.append(rockImage);foreground.append(rocks);
 for(const [glyph,cls] of [['汉','hanzi-rock-one'],['学','hanzi-rock-two']]){const energy=document.createElement('span');energy.className=cls;energy.textContent=glyph;energy.setAttribute('lang','zh-CN');rocks.append(energy);}
 feature.append(foreground,copy,ufo);grid.append(feature);
 const entries=[
  ['quick-start','adventure','✦',1],['open-writing','writing','✎',6],
  ['bubble-card','bubbles','◉',2],['practice','practice','◎',6],['daily-review','daily','↻',10],['match','match','↔',5],
  ['timed','timed','➤',4],['endless','endless','∞',7],['arcade','arcade','✧',8],
  ['listening','listening','♫',3],['sentence-card','sentences','字',9]
 ];
 const boundaries=[0,313,626,914,1254];
 for(const [id,mode,icon,sceneIndex] of entries){
  const card=document.getElementById(id)||grid.querySelector('[data-mode="'+id+'"]');if(!card)continue;
  if(mode==='bubbles'){const heading=document.createElement('h3');heading.className='mode-group-heading';heading.textContent='อาร์เคดฝึกภาษา';grid.append(heading);}
  card.dataset.artCell=String(entries.findIndex(e=>e[1]===mode)-2);card.dataset.worldMode=mode;card.dataset.tier=['adventure','writing'].includes(mode)?'major':'standard';
  const row=Math.floor(sceneIndex/3),height=boundaries[row+1]-boundaries[row];
  card.style.setProperty('--art-x',(sceneIndex%3)*50+'%');
  card.style.setProperty('--art-y',boundaries[row]/(1254-height)*100+'%');
  card.style.setProperty('--art-height',1254/height*100+'%');
  const modeCopy=document.createElement('span');modeCopy.className='mode-copy';while(card.firstChild)modeCopy.append(card.firstChild);
  const art=document.createElement('span');art.className='mode-art';art.setAttribute('aria-hidden','true');
  const emblem=document.createElement('span');emblem.className='mode-emblem';emblem.textContent=icon;art.append(emblem);
  if(['bubbles','practice','daily'].includes(mode)){const glyph=document.createElement('span');glyph.className='arcade-hanzi';glyph.textContent='字';glyph.setAttribute('lang','zh-CN');art.append(glyph);}
  if(mode==='writing'){const hanzi=document.createElement('span');hanzi.className='destination-hanzi';hanzi.textContent='永';hanzi.setAttribute('lang','zh-CN');art.append(hanzi);}
  card.append(art,modeCopy);grid.append(card);
 }
 const openSettings=$('open-settings').onclick;
 $('open-settings').onclick=()=>{document.body.classList.add('setup-open');openSettings();};
 $('chapters').addEventListener('click',()=>document.body.classList.add('setup-open'),true);
 const settingsLink=document.createElement('button');settingsLink.className='secondary progress-settings';settingsLink.textContent='ระดับศัพท์ / ตั้งค่า';
 settingsLink.onclick=()=>$('open-settings').click();document.querySelector('.learning').append(settingsLink);
 const arena=document.querySelector('.arena');const markMode=()=>{arena.dataset.worldMode=$('mode').value;};markMode();
 $('mode').addEventListener('change',markMode);
 document.addEventListener('click',markMode);
})();
