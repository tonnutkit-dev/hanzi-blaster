'use strict';
// Expose existing modes; these buttons call the established round lifecycle.
for(const [id,icon] of [['listening','🔊'],['timed','⚡'],['endless','∞'],['practice','🎯'],['match','↔'],['arcade','✦']]){
 const tile=document.createElement('button');tile.className='mode-tile';tile.dataset.mode=id;
 const kicker=document.createElement('span');kicker.className='tile-kicker';kicker.textContent=icon+' / '+id.toUpperCase();
 const title=document.createElement('strong');title.textContent=MODES[id].name;
 const help=document.createElement('span');help.textContent=MODES[id].meta;
 const play=document.createElement('b');play.textContent='เริ่มเล่น ↗';tile.append(kicker,title,help,play);
 tile.onclick=()=>{if(active)return;$('mode').value=id;settings();start();};document.querySelector('.mode-grid').append(tile);
}
