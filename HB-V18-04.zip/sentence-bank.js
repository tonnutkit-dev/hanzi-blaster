'use strict';
const SentenceBank=(()=>{
 // Other modes retain their original 54-item context bank and cumulative HSK1–2 behavior.
 const context=typeof SENTENCE_CONTEXT==='undefined'?SENTENCES:SENTENCE_CONTEXT;
 const indexed=new Map();for(const q of context)for(const zh of q.targets||[]){if(!indexed.has(zh))indexed.set(zh,[]);indexed.get(zh).push(q);}
 function available(level,target=null){const max=level==='mix'||level==='all'?2:+level;if(max>2||max<1)return [];return (target?indexed.get(target.zh)||[]:context).filter(q=>q.level<=max);}
 function missionAvailable(level){if(level==='mix'||level==='all')return [...SENTENCES];return SENTENCES.filter(q=>q.level===Number(level));}
 function target(q){return words.find(w=>w.zh===(q.targets||[])[0]&&w.level<=q.level)||words.find(w=>(q.targets||[]).includes(w.zh)&&w.level<=q.level);}
 function asType(q,type){if(type!=='meaning')return {...q};return {...q,type:'meaning',prompt:q.full,py:q.fullPy,th:'ประโยคนี้หมายถึงอะไร?',contextEnglish:'What does this sentence mean?',answer:q.meaning,options:shuffle([q.meaning,...shuffle(q.meaningDistractors).slice(0,3)])};}
 function translate(q,text){return UI.language==='en'?(q.translations?.[text]||UI.t(text)):text;}
 function round(level,count=10,focusWords=[]){
  const focus=new Set(focusWords.map(w=>w.zh)),pool=missionAvailable(level).filter(q=>!focus.size||q.targets.some(zh=>focus.has(zh)));
  const key='hanzi-sentence-recent-v2:'+level;let recent=[];
  try{const saved=JSON.parse(localStorage.getItem(key)||'[]');if(Array.isArray(saved))recent=saved.filter(x=>typeof x==='string').slice(-20);}catch{}
  const types=shuffle(['fill','fill','fill','meaning','meaning','meaning','meaning','dialogue','dialogue','dialogue']),picked=[];
  for(let i=0;i<Math.min(count,pool.length);i++){
   const remaining=pool.filter(q=>!picked.some(p=>p.id===q.id||p.full===q.full));if(!remaining.length)break;
   let candidates=remaining.filter(q=>q.compatibleTypes.includes(types[i%types.length]));if(!candidates.length)candidates=remaining;
   const fresh=candidates.filter(q=>!recent.includes(q.full));if(fresh.length)candidates=fresh;else{const oldest=Math.min(...candidates.map(q=>recent.lastIndexOf(q.full)));candidates=candidates.filter(q=>recent.lastIndexOf(q.full)===oldest);}
   const last=picked.at(-1)?.full||recent.at(-1);const different=candidates.filter(q=>q.full!==last);if(different.length)candidates=different;
   const penalty=q=>picked.slice(-2).filter(p=>p.grammar===q.grammar).length*4+picked.slice(-3).filter(p=>p.targets.some(t=>q.targets.includes(t))).length*2;
   const best=Math.min(...candidates.map(penalty));candidates=shuffle(candidates.filter(q=>penalty(q)===best));
   // Novelty first, then bounded weak-word weighting. No sentence IDs enter vocabulary storage.
   const weights=candidates.map(q=>LearningEngine.state(target(q)||{})==='WEAK'?3:1);
   let r=Math.random()*weights.reduce((a,b)=>a+b,0),q=candidates.at(-1);
   for(let j=0;j<candidates.length;j++){r-=weights[j];if(r<=0){q=candidates[j];break;}}
   picked.push(asType(q,q.compatibleTypes.includes(types[i%types.length])?types[i%types.length]:q.type));
  }
  try{localStorage.setItem(key,JSON.stringify([...recent,...picked.map(q=>q.full)].slice(-20)));}catch{}
  return picked;
 }
 return {available,missionAvailable,target,asType,translate,round};
})();
