'use strict';
// Shared V2A/V2B presentation adapter. The original round/answer/audio owners remain intact.
(()=>{
 const arena=document.querySelector('.arena'),hud=arena.querySelector('.hud');
 const question=arena.querySelector('.question'),field=$('field'),bottom=arena.querySelector('.bottom');
 const overdrive=$('overdrive-panel'),foot=arena.querySelector('.arena-foot');
 const language=document.querySelector('.language-picker'),sound=$('sound'),combo=$('combo');
 const shell=document.createElement('div');shell.className='gameplay-shell';
 const controls=document.createElement('div');controls.className='gameplay-controls';
 const utilities=document.createElement('div');utilities.className='gameplay-utilities';
 const options=document.createElement('details');options.className='gameplay-options';
 const optionsTrigger=document.createElement('summary');optionsTrigger.textContent='⚙';
 optionsTrigger.setAttribute('aria-label',UI.t('ตัวเลือกเพิ่มเติม'));
 options.append(optionsTrigger,utilities);
 const progress=document.createElement('progress');progress.className='gameplay-progress';
 progress.setAttribute('aria-label',UI.t('คำที่'));
 const hudTrack=document.createElement('div');hudTrack.className='gameplay-hud-track';
 const dock=document.createElement('div');dock.className='gameplay-dock';
 // Decorative scene has no answer data, hit targets, timers or input handlers.
 const scene=document.createElement('div');scene.className='gameplay-scene';
 scene.setAttribute('aria-hidden','true');
 for(const name of ['stage','orbit','dust','halo','platform-energy']){const layer=document.createElement('div');layer.className='gameplay-'+name;scene.append(layer);
  if(name==='orbit'){const track=document.createElement('div');track.className='gameplay-orbit-track';layer.append(track);}
 }
 // Independent compositor layers give the existing artwork visible life.
 // Keep text/HUD/input nodes outside these transforms. No frame-loop owner.
 const world=document.createElement('div');world.className='gameplay-world';world.setAttribute('aria-hidden','true');
 for(const name of ['base','structures','haze','particles']){const layer=document.createElement('div');layer.className='gameplay-world-'+name;world.append(layer);}
 const dailyTitle=document.createElement('span');dailyTitle.className='gameplay-daily-title';dailyTitle.textContent=UI.t('ทบทวนวันนี้');
 const timer=arena.querySelector('.timer'),coverage=$('endless-coverage');
 const parked=new Map();let mounted=false,visualMode=null,lastScore=null,lastRound=null;
 const score=$('score'),roundValue=$('round'),resultTitle=$('result-title');
 const results=$('results'),resultIdentity=document.createElement('p');
 resultIdentity.className='training-result-identity';
 let resultMode=null,resultLevel=null;
 // Alternate bounded CSS names instead of reflow, timers or animation callbacks.
 // Only committed value changes retrigger; repeated HUD writes are not events.
 function accent(node,key){node.setAttribute(key,node.getAttribute(key)==='a'?'b':'a');}
 const batchModes=new Set(['match','timed','endless','arcade','listening']);
 function updateScene(){
  if(!mounted)return;
  // Read only the verdict classes already committed by the round owner.
  // Wrong takes priority because the owner also reveals the correct choice.
  for(const answer of field.querySelectorAll('.target'))answer.classList.toggle('gameplay-long-answer',[...answer.textContent].length>30);
  const wrong=!!field.querySelector('.target.wrong')||!!field.querySelector('.match-card.wrong');
  const correct=!wrong&&(!!field.querySelector('.target.correct')||!!field.querySelector('.match-card.matched'));
  shell.classList.toggle('arena-wrong',wrong);shell.classList.toggle('arena-correct',correct);
  const paused=document.hidden||!!$('exit-dialog').open||!!$('howto-dialog')?.open;
  shell.classList.toggle('ambient-paused',paused);
  // Explicit ownership also pauses root-level world layers on Safari; it does
  // not depend on :has(), Hub intersection state, or an animation reset.
  document.body.classList.toggle('practice-ambient-paused',paused);
 }

 function move(node,parent){
  const marker=document.createComment('V2A original position');
  node.parentNode.insertBefore(marker,node);parked.set(node,marker);parent.append(node);
 }
 function updateProgress(){
  if(!mounted)return;
  const currentScore=score.textContent,currentRound=roundValue.textContent;
  if(lastScore!==null&&currentScore!==lastScore)accent(score,'data-training-score');
  if(lastRound!==null&&currentRound!==lastRound){accent(roundValue,'data-training-progress');accent(progress,'data-training-progress');}
  lastScore=currentScore;lastRound=currentRound;
  const match=$('round').textContent.match(/^(\d+)\s*\/\s*(\d+)$/);
  if(match){progress.max=+match[2];progress.value=+match[1];}
  progress.hidden=!match; // Endless and pair counts never imply a finite endpoint.
  progress.setAttribute('aria-label',UI.t('คำที่')+' '+$('round').textContent);
  question.classList.toggle('gameplay-long-prompt',[...$('prompt').textContent].length>28);
  question.classList.toggle('gameplay-meaning-prompt',!/[\u3400-\u9fff]/.test($('prompt').textContent));
 }
 function mount(mode){
  if(mounted)return;mounted=true;visualMode=mode;lastScore=lastRound=null;arena.append(shell);shell.append(dock);
  move(hud,shell);move(question,shell);move(field,shell);move(bottom,shell);
  move($('mini-event'),dock);move(overdrive,dock);move(foot,dock);
  hud.append(hudTrack);move(combo,hudTrack);hudTrack.prepend(progress);
  foot.append(controls,options);
  for(const id of ['round-pause','howto','exit'])move($(id),controls);
  move(language,utilities);move(sound,utilities);shell.append(dock);
  question.prepend(scene);document.body.prepend(world);
  if(mode==='practice')document.body.classList.add('practice-pilot');
  else{document.body.classList.add('training-pilot');shell.setAttribute('data-training-mode',mode);
   if(['timed','match','arcade'].includes(mode))move(timer,hudTrack);
   if(mode==='endless')move(coverage,dock);
   if(mode==='daily')hud.querySelector('.session-identity')?.prepend(dailyTitle);
  }
  updateProgress();updateScene();
  // Cancel the legacy start() centering scroll. Presentation never delays input.
  window.scrollTo({top:0,left:0,behavior:'instant'});
 }
 function unmount(){
  if(!mounted)return;mounted=false;lastScore=lastRound=null;score.removeAttribute('data-training-score');roundValue.removeAttribute('data-training-progress');progress.removeAttribute('data-training-progress');document.body.classList.remove('practice-pilot','training-pilot','practice-ambient-paused');visualMode=null;dailyTitle.remove();shell.removeAttribute('data-training-mode');world.remove();question.classList.remove('gameplay-long-prompt','gameplay-meaning-prompt');
  // Reverse order restores children before their original containers.
  for(const [node,marker] of [...parked].reverse()){marker.replaceWith(node);}
  parked.clear();for(const answer of field.querySelectorAll('.target'))answer.classList.remove('gameplay-long-answer');options.open=false;scene.remove();shell.classList.remove('arena-wrong','arena-correct','ambient-paused');shell.remove();hudTrack.remove();dock.remove();controls.remove();options.remove();
 }
 function resultLabel(){
  if(!resultMode)return;
  const name=resultMode==='daily'?UI.t('ทบทวนวันนี้'):typeof MODES!=='undefined'?UI.t(MODES[resultMode].name):'';
  const level=typeof HSK!=='undefined'?HSK.label(resultLevel):'';
  const label=[name,level].filter(Boolean).join(' · ');
  if(resultIdentity.textContent!==label)resultIdentity.textContent=label;
 }
 function suspendResult(){
  if(results.getAttribute('data-training-result-mode')===null)return;
  document.body.classList.remove('training-results');
  results.removeAttribute('data-training-result-mode');resultIdentity.remove();
  if(!mounted)world.remove();
 }
 function releaseResult(){
  if(!resultMode)return;
  suspendResult();resultMode=resultLevel=null;
 }
 function presentResult(mode){
  if(results.getAttribute('data-training-result-mode')===mode)return;
  // Keep only presentation provenance, before unmount clears the live owner.
  // Daily's authoritative flag has already been reset by finish().
  const resuming=resultMode===mode;
  if(!resuming){resultMode=mode;resultLevel=config.level;}
  resultLabel();results.prepend(resultIdentity);
  results.setAttribute('data-training-result-mode',mode);
  document.body.classList.add('training-results');document.body.prepend(world);
  // A report's context action can open a dedicated modal without hiding the
  // report. Recover only focus that its close handler left in the hidden lobby.
  const focused=document.activeElement;
  if(resuming&&focused&&!results.contains(focused)&&!focused.getClientRects?.().length)results.focus({preventScroll:true});
 }
 function sync(){
  // Daily keeps its distinct identity; ordinary Review reuses Practice unchanged.
  const daily=typeof dailySession!=='undefined'&&dailySession&&config.review;
  const mode=daily?'daily':sessionMode;
  const enabled=active&&(batchModes.has(mode)||daily||mode==='practice');
  const dedicated=document.body.classList.contains('adventure-view')||document.body.classList.contains('tailored-pilot');
  if(active||results.hidden)releaseResult();
  else if(dedicated)suspendResult();
  // The mounted Training owner identifies its own result, including Daily whose
  // semantic flag is already reset by finish(). Excluded mode results stay plain.
  if(active||$('results').hidden)resultTitle.removeAttribute('data-training-result');
  else if(mounted)accent(resultTitle,'data-training-result');
  if(enabled){
   if(mounted&&visualMode!==mode)unmount();
   // Later adapters must restore their shared nodes before we park them. Their
   // existing body-class cleanup triggers this lifecycle observer again in the
   // same mutation checkpoint; no timer, input lock or gameplay delay is added.
   if(!mounted&&(document.body.classList.contains('adventure-view')||document.body.classList.contains('tailored-pilot')))return;
   mount(mode);updateScene();
  }else{
   const completed=mounted&&!results.hidden&&!dedicated?visualMode:null;
   unmount();
   if(completed)presentResult(completed);
   else if(resultMode&&!dedicated)presentResult(resultMode);
  }
 }
 const lifecycle=new MutationObserver(sync);
 lifecycle.observe(document.body,{attributes:true,attributeFilter:['class']});
 lifecycle.observe(arena,{attributes:true,attributeFilter:['data-world-mode']});
 lifecycle.observe($('results'),{attributes:true,attributeFilter:['hidden']});
 const round=new MutationObserver(updateProgress);
 round.observe($('round'),{childList:true,characterData:true,subtree:true});
 round.observe($('prompt'),{childList:true,characterData:true,subtree:true});
 round.observe(score,{childList:true,characterData:true,subtree:true});
 const presentation=new MutationObserver(updateScene);
 presentation.observe(field,{childList:true,subtree:true,attributes:true,attributeFilter:['class']});
 presentation.observe($('exit-dialog'),{attributes:true,attributeFilter:['open']});
 if($('howto-dialog'))presentation.observe($('howto-dialog'),{attributes:true,attributeFilter:['open']});
 document.addEventListener('visibilitychange',updateScene);
 UI.onChange(()=>{dailyTitle.textContent=UI.t('ทบทวนวันนี้');optionsTrigger.setAttribute('aria-label',UI.t('ตัวเลือกเพิ่มเติม'));if(mounted)updateProgress();resultLabel();});sync();
})();
