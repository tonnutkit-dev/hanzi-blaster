'use strict';
// Short synthesized arcade cues; no downloads and no sound before a gesture.
const battleAudio=(()=>{
 let ctx=null,enabled=true,ducked=false;try{enabled=localStorage.getItem('hanzi-fx')!=='off'}catch{}
 const global=window.HanziAudio;let lastBoost=0;const voices=new Map();
 function own(source,gain,filter){while(voices.size>=12){const [old,clean]=voices.entries().next().value;try{old.stop();}catch{}clean();}const clean=()=>{if(!voices.has(source))return;voices.delete(source);global?.releaseSfx(source);source.onended=null;for(const node of [source,filter,gain])try{node?.disconnect();}catch{}};voices.set(source,clean);source.onended=clean;global?.adoptSfx(source,clean);}let blasterNoise=null;
 function unlock(){if(global){ctx=global.ctx;return;}if(!enabled)return;try{ctx??=new(window.AudioContext||window.webkitAudioContext)();if(ctx.state==='suspended')ctx.resume().catch(()=>{});}catch{}}
 const patterns={'break':[[180,.09],[90,.16],[55,.22]],'power-hit':[[150,.08],[75,.16],[110,.12]],move:[[420,.05]],shoot:[[880,.045],[360,.07]],hit:[[220,.08],[110,.12]],correct:[[660,.08],[990,.12]],wrong:[[180,.13],[130,.15]],charge:[[220,.08],[330,.08],[440,.12]],shield:[[520,.1],[780,.16]],dodge:[[660,.06],[880,.08]],spell:[[220,.09],[440,.09],[880,.15]],win:[[523,.13],[659,.13],[784,.13],[1046,.3]],overdrive:[[440,.08],[660,.08],[880,.16]]};
 function play(name,delay=0){if(global)enabled=global.prefs.sfx;if(!enabled)return;unlock();if(global&&!name.startsWith('blaster-')){const mode=typeof sessionMode==='undefined'?'':sessionMode;let kind=name;if(name==='correct'||name==='wrong'){const ok=name==='correct';kind=mode==='bubbles'?'bubble-'+name:mode==='match'?'match-'+name:name;const boost=typeof overdriveShots==='undefined'?0:overdriveShots;if(ok&&boost===3&&lastBoost!==3)kind='overdrive';else if(ok&&typeof overdriveCharge!=='undefined'&&overdriveCharge===4)kind='charge';else if(ok&&typeof combo!=='undefined'&&combo>0&&combo%3===0)kind='combo';lastBoost=boost;}global.cue(kind);return;}if(!ctx||ctx.state!=='running')return;let at=ctx.currentTime+delay;
 if(name.startsWith('blaster-')){
  if(global&&name==='blaster-confirm-right'){const boost=typeof overdriveShots==='undefined'?0:overdriveShots;if(boost===3&&lastBoost!==3)global.cue('overdrive');lastBoost=boost;}
  // Timed-only synthesized layers; all tails end before the 380ms learning voice.
  const fire=name==='blaster-fire',confirm=name.startsWith('blaster-confirm-'),wrong=name.endsWith('-wrong');
  function envelope(source,level,duration,filter=null){
   const g=ctx.createGain();g.gain.setValueAtTime(.0001,at);g.gain.linearRampToValueAtTime(ducked?level*.15:level,at+.002);g.gain.exponentialRampToValueAtTime(.0001,at+duration);
   source.connect(filter||g);if(filter)filter.connect(g);g.connect(global?global.sfxBus:ctx.destination);
   own(source,g,filter);source.start(at);source.stop(at+duration+.005);
  }
  const layers=fire?[[2600,700,.018,.012,'square'],[155,65,.10,.032,'sine'],[1050,320,.13,.018,'triangle']]:confirm?[[wrong?340:880,wrong?180:1320,.075,.034,'triangle']]:[[180,60,.06,.034,'sine'],[wrong?280:610,wrong?130:300,.055,.018,'triangle']];
  for(const [from,to,duration,level,type] of layers){const o=ctx.createOscillator();o.type=type;o.frequency.setValueAtTime(from,at);o.frequency.exponentialRampToValueAtTime(to,at+duration);envelope(o,level,duration);}
  if(fire){
   // One small reusable buffer per AudioContext; never fetched or stacked on repeat taps.
   if(!blasterNoise){blasterNoise=ctx.createBuffer(1,Math.ceil(ctx.sampleRate*.085),ctx.sampleRate);const data=blasterNoise.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=Math.random()*2-1;}
   const noise=ctx.createBufferSource(),filter=ctx.createBiquadFilter();noise.buffer=blasterNoise;filter.type='bandpass';filter.frequency.setValueAtTime(1400,at);filter.frequency.exponentialRampToValueAtTime(450,at+.08);filter.Q.setValueAtTime(.7,at);envelope(noise,.025,.08,filter);
  }return;
 }
 for(const [frequency,duration] of patterns[name]||patterns.correct){const o=ctx.createOscillator(),g=ctx.createGain();o.type=['hit','wrong','shoot'].includes(name)?'sawtooth':'triangle';o.frequency.setValueAtTime(frequency,at);g.gain.setValueAtTime(0,at);g.gain.linearRampToValueAtTime(ducked?.008:.055,at+.008);g.gain.exponentialRampToValueAtTime(.0001,at+duration);o.connect(g);g.connect(global?global.sfxBus:ctx.destination);own(o,g);o.start(at);o.stop(at+duration+.02);at+=duration;}}
 function stop(){for(const [o,clean] of [...voices]){try{o.stop()}catch{}clean();}}
 function toggle(){if(global){global.setPreference('sfx',!global.prefs.sfx);return global.prefs.sfx;}enabled=!enabled;if(!enabled)stop();try{localStorage.setItem('hanzi-fx',enabled?'on':'off')}catch{}sync();if(enabled){unlock();play('correct')}return enabled;}
 function sync(){sound=enabled;$('sound').textContent=enabled?'เอฟเฟกต์: เปิด':'เอฟเฟกต์: ปิด';$('sound').setAttribute('aria-pressed',String(enabled));$('sound').setAttribute('aria-label','เปิดหรือปิดเสียงเอฟเฟกต์');}
 if(!global){document.addEventListener('pointerdown',unlock);document.addEventListener('keydown',unlock);}document.addEventListener('visibilitychange',()=>{if(document.hidden)stop()});
 $('sound').onclick=toggle;if(global){enabled=global.prefs.sfx;global.subscribe(p=>{enabled=p.sfx;if(!enabled)stop();sync();});}sync();
 return {play:(...args)=>global?global.guard(()=>{try{return play(...args);}catch(error){stop();throw error;}}):play(...args),unlock,toggle,stop,duck:v=>{ducked=v;global?.speech(v,'combat')},get enabled(){return enabled}};
})();
