'use strict';
const WritingLab=(()=>{
 const card=document.createElement('button');card.id='open-writing';card.className='mode-tile';
 card.innerHTML='<span class="tile-kicker">WRITE</span><strong>ฝึกเขียนจีน</strong><span>ฝึกทีละขีด → เขียนจากความจำ</span><b>เริ่มฝึก ↗</b>';
 document.querySelector('.mode-grid').append(card);
 const dialog=document.createElement('dialog');dialog.id='writing-lab';dialog.setAttribute('aria-label','ฝึกเขียนจีน');document.body.append(dialog);
 const t=value=>UI.t(value),esc=value=>String(value).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
 let sessionScope={level:'1',cumulative:false};
 let words=[],index=0,stage='trace',characterIndex=0,strokeIndex=0,completed=0,attempts=0,mistakes=0,hints=0;
 let writer=null,data=null,observer=null,generation=0,ready=false,characterDone=false,loadFailed=false,saveFailed=false;
 const cache=new Map(),pending=new Map(),loads=[],word=()=>words[index],characters=()=>[...word().zh];let loading=0;
 const message=value=>{const el=dialog.querySelector('.writing-message');if(el)el.textContent=t(value);};
 function heading(){return `<header class="writing-head"><div><span class="eyebrow">WRITING LAB / <span class="session-hsk">${HSK.label(sessionScope.level,sessionScope.cumulative)}</span></span><h2>${t('ฝึกเขียนจีน')}</h2></div><button data-write="close" aria-label="${t('ออกจากโหมดเขียน')}">✕</button></header>`;}
 function dispose(){LearningAudio.cancel();generation++;ready=false;observer?.disconnect();observer=null;if(writer){writer.target.destroy();writer.cancelQuiz();writer=null;}}
 // At most two requests in flight. Demand jumps ahead of queued preloads; failures can retry.
 function pump(){while(loading<2&&loads.length){const task=loads.shift();loading++;(async()=>{try{const response=await fetch('writing-data/'+encodeURIComponent(task.char)+'.json');if(!response.ok)throw Error('Stroke data unavailable');const result=await response.json();if(!result.strokes?.length||result.strokes.length!==result.medians?.length)throw Error('Invalid stroke data');cache.set(task.char,result);task.resolve(result);}catch(error){task.reject(error);}finally{pending.delete(task.char);loading--;pump();}})();}}
 function loadCharacter(char,preload=false){if(cache.has(char))return Promise.resolve(cache.get(char));if(pending.has(char))return pending.get(char);let resolve,reject;const request=new Promise((yes,no)=>{resolve=yes;reject=no;});pending.set(char,request);const task={char,resolve,reject};preload?loads.push(task):loads.unshift(task);pump();return request;}
 function preloadAhead(){if(!dialog.open||stage==='done'||stage==='result')return;const following=characters().slice(characterIndex+1);if(index+1<words.length)following.push(...[...words[index+1].zh]);for(const char of [...new Set(following)].slice(0,3))loadCharacter(char,true).catch(()=>{});}
 function progress(){
  const el=dialog.querySelector('.writing-characters');if(!el)return;
  el.innerHTML=characters().map((c,i)=>`<span lang="zh-CN" class="${i===characterIndex?'current':''}" ${i===characterIndex?'aria-current="step"':''}>${esc(c)}<small>${i<characterIndex||i===characterIndex&&characterDone?'✓':i===characterIndex?'←':''}</small></span>`).join('');
  const status=dialog.querySelector('.writing-strokes');status.textContent=data?`${t('ขีด')} ${Math.min(strokeIndex+1,data.strokes.length)} / ${data.strokes.length}${characterDone?' ✓':''}`:t('กำลังโหลดขีด…');
 }
 function guide(){
  const svg=dialog.querySelector('.writing-stroke-guide');if(!svg||!writer||!data)return;svg.replaceChildren();
  if(stage!=='trace'||characterDone||strokeIndex>=data.strokes.length)return;
  const {width,height}=writer.target.getBoundingClientRect();const transform=HanziWriter.getScalingTransform(width,height,16);
  const g=document.createElementNS('http://www.w3.org/2000/svg','g');g.setAttribute('transform',transform.transform);
  const path=document.createElementNS('http://www.w3.org/2000/svg','path');path.setAttribute('d',data.strokes[strokeIndex]);path.setAttribute('fill','#79dce0');path.setAttribute('opacity','.38');g.appendChild(path);
  const dot=document.createElementNS('http://www.w3.org/2000/svg','circle');dot.setAttribute('cx',data.medians[strokeIndex][0][0]);dot.setAttribute('cy',data.medians[strokeIndex][0][1]);dot.setAttribute('r','13');dot.setAttribute('fill','#ffe39a');g.appendChild(dot);svg.appendChild(g);
 }
 function quiz(){
  const own=writer,token=generation;ready=false;
  own.quiz({...WritingEngine.options,quizStartStrokeNum:strokeIndex,
   onCorrectStroke:event=>{if(token!==generation)return;window.HanziAudio?.cue('stroke-correct');strokeIndex=event.strokeNum+1;progress();guide();message('ดีมาก · ขีดถัดไป');},
   onMistake:()=>{if(token!==generation)return;window.HanziAudio?.cue('stroke-wrong');mistakes++;message('ลองใหม่ · เริ่มให้ถูกจุดและลากตามทิศทาง');const surface=dialog.querySelector('.writing-surface');surface.classList.remove('stroke-miss');void surface.offsetWidth;surface.classList.add('stroke-miss');},
   onComplete:()=>{if(token!==generation)return;window.HanziAudio?.cue('character-complete');ready=false;characterDone=true;writer.target.release();progress();guide();dialog.querySelector('[data-write="advance"]').disabled=false;message('ครบทุกขีดแล้ว');}
  });
  // quiz() schedules setup after data; input starts after that microtask.
  Promise.resolve().then(()=>{if(token===generation)ready=true;});
 }
 async function mount(){
  const token=generation;loadFailed=false;data=null;progress();
  try{
   const loaded=await loadCharacter(characters()[characterIndex]);if(token!==generation)return;data=loaded;
   const surface=dialog.querySelector('.writing-surface'),target=dialog.querySelector('.writing-target');const rect=surface.getBoundingClientRect();
   writer=new HanziWriter(target,{width:rect.width-4,height:rect.height-4,padding:16,showCharacter:false,showOutline:stage==='trace',outlineColor:'#284a64',strokeColor:'#ecfaf7',drawingColor:'#ffdc87',drawingWidth:Math.min(9,Math.max(7,rect.width/44)),highlightColor:'#89ebe0',strokeFadeDuration:140,drawingFadeDuration:120,strokeHighlightSpeed:1.8,charDataLoader:()=>loaded,rendererOverride:{createRenderTarget:WritingEngine.createTarget}});
   await writer.setCharacter(characters()[characterIndex]);if(token!==generation)return;
   writer.target.bind(()=>{if(ready&&!characterDone){writer.cancelQuiz();quiz();}},()=>ready&&!characterDone);
   // Guard input during loading, after completion and while changing stage.
   const baseStart=writer.target.start;writer.target.start=e=>{if(ready&&!characterDone)baseStart(e);};
   quiz();progress();guide();preloadAhead();message(stage==='trace'?'เริ่มที่จุดสีทอง · ลากตามขีดสีฟ้า':'เขียนตามลำดับจากความจำ · ขอคำใบ้ได้');
   observer=new ResizeObserver(()=>{if(!writer||token!==generation)return;const r=surface.getBoundingClientRect();if(writer.target.pointer!==null){writer.target.release();writer.cancelQuiz();quiz();}writer.updateDimensions({width:r.width-4,height:r.height-4,padding:16});guide();});observer.observe(surface);
  }catch(error){if(token!==generation)return;ready=false;loadFailed=true;message('ไม่มีข้อมูลขีดสำหรับตัวนี้ · ลองโหลดใหม่หรือข้ามคำ');dialog.querySelector('.writing-actions').innerHTML=`<button data-write="reload">${t('โหลดใหม่')}</button><button data-write="skip">${t('ข้ามคำ')}</button>`;}
 }
 function render(){
  dispose();characterDone=false;strokeIndex=0;
  if(stage==='done'){dialog.innerHTML=heading()+`<div class="writing-body writing-finish"><span class="eyebrow">SESSION COMPLETE</span><h3>${t('ฝึกครบแล้ว')} ${completed}/${words.length} ${t('คำ')}</h3><p>${t(saveFailed?'บันทึกจำนวนครั้งที่ฝึกไม่ได้บนเครื่องนี้':'บันทึกการฝึกบนเครื่องนี้ · ยังไม่เพิ่มคะแนนหรือระดับความชำนาญ')}</p><p class="writing-message" role="status"></p><div class="writing-actions"><button class="primary" data-write="restart">${t('ฝึกอีกชุด')} ↗</button><button data-write="close">${t('กลับเลือกโหมด')}</button></div></div>`;return;}
  const w=word();
  if(stage==='result'){dialog.innerHTML=heading()+`<div class="writing-body writing-finish"><span class="eyebrow">${index+1} / ${words.length} · RESULT</span><h3 lang="zh-CN">${esc(w.zh)}</h3><div class="writing-reading">${Pinyin.html(w.py,'writing-pinyin')}<span data-learning>${esc(UI.meaning(w))}</span></div><p>${t('ผ่านการฝึกขีดครบทุกตัว · ไม่ใช่การประเมินลายมือ')}</p><div class="writing-actions"><button data-write="voice" aria-label="${t('ฟังเสียง')}">♪</button><button data-write="retry">${t('ลองเขียนอีกครั้ง')}</button><button class="primary" data-write="next">${t(index===words.length-1?'ดูสรุป':'คำถัดไป')} →</button></div><p class="writing-message" role="status"></p></div>`;wordVoice();return;}
  dialog.innerHTML=heading()+`<div class="writing-body" data-stage="${stage}"><div class="writing-prompt"><span class="eyebrow">${index+1} / ${words.length} · ${stage==='trace'?'TRACE':'RECALL'}</span><strong lang="zh-CN">${esc(w.zh)}</strong><div class="writing-reading">${Pinyin.html(w.py,'writing-pinyin')}<span data-learning>${esc(UI.meaning(w))}</span></div></div><div class="writing-progress"><div class="writing-characters" aria-label="${t('ตัวอักษรในคำ')}"></div><span class="writing-strokes" role="status"></span></div><div class="writing-surface" role="group" aria-label="${t('พื้นที่เขียน')}: ${esc(characters()[characterIndex])}"><div class="writing-target"></div><svg class="writing-stroke-guide" aria-hidden="true"></svg></div><div class="writing-actions"><button data-write="hint">${t('ดูขีด')} ↗</button><button data-write="reset">${t('เริ่มตัวนี้ใหม่')}</button><button data-write="voice" aria-label="${t('ฟังเสียง')}">♪</button><button class="primary" data-write="advance" disabled>${t(characterIndex<characters().length-1?'ตัวถัดไป':stage==='trace'?'เขียนเอง':'ดูผล')} →</button></div><p class="writing-message" role="status">${t('กำลังโหลดขีด…')}</p><a class="writing-credit" href="writing-data/ATTRIBUTION.md" target="_blank" rel="noopener">Hanzi Writer · Make Me a Hanzi / Arphic</a></div>`;
  mount();
 }
 function wordVoice(){const token=generation;LearningAudio.speak(word().zh,()=>{},()=>{if(dialog.open&&token===generation)message('เสียงจีนไม่พร้อม');});}
 function storePractice(){try{const key='hanzi-writing-v1',saved=JSON.parse(localStorage.getItem(key)||'{}'),all=saved&&typeof saved==='object'&&!Array.isArray(saved)?saved:{},old=all[word().id]||{};all[word().id]={...old,sessions:(Number(old.sessions)||0)+1,recallAttempts:(Number(old.recallAttempts)||0)+attempts,strokeSessions:(Number(old.strokeSessions)||0)+1,strokeMistakes:(Number(old.strokeMistakes)||0)+mistakes,strokeHints:(Number(old.strokeHints)||0)+hints,lastPracticed:new Date().toISOString()};localStorage.setItem(key,JSON.stringify(all));return true;}catch{saveFailed=true;return false;}}
 function chooseWords(source,count,level){
  const key='hanzi-writing-recent-v1:'+level;let recent=[];try{const saved=JSON.parse(localStorage.getItem(key)||'[]');if(Array.isArray(saved))recent=saved.filter(x=>typeof x==='string').slice(-15);}catch{}
  // One representative per spelling; keep the weakest ID eligible for the weighted engine.
  const byText=new Map();for(const w of source){const old=byText.get(w.zh);if(!old||LearningEngine.priority(w)>LearningEngine.priority(old))byText.set(w.zh,w);}
  const unique=[...byText.values()],fresh=unique.filter(w=>!recent.includes(w.zh)),size=Math.min(count,unique.length);
  const selected=LearningEngine.round(fresh,size,'writing:'+level);
  if(selected.length<size){const remaining=unique.filter(w=>!selected.some(x=>x.zh===w.zh));selected.push(...LearningEngine.round(remaining,size-selected.length,'writing:fill:'+level));}
  const result=selected.slice(0,size);try{localStorage.setItem(key,JSON.stringify([...recent,...result.map(w=>w.zh)].slice(-15)));}catch{}
  return result;
 }
 function next(save=true){const saved=!save||storePractice();if(save)completed++;index++;characterIndex=attempts=mistakes=hints=0;stage=index===words.length?'done':'trace';render();if(!saved)message('บันทึกจำนวนครั้งที่ฝึกไม่ได้บนเครื่องนี้');}
 function start(){if(dialog.open||active||document.getElementById('combat')?.open||document.getElementById('sentence-dialog')?.open)return;const source=selectedWords().filter(w=>w.zh&&w.py&&(w.th||w.english));if(!source.length)return;sessionScope=HSK.scope();LearningEngine.begin();words=chooseWords(source,5,$('level').value);index=completed=characterIndex=attempts=mistakes=hints=0;saveFailed=false;stage='trace';dialog.showModal();document.body.classList.add('writing-open');render();}
 function close(){dispose();window.speechSynthesis?.cancel();dialog.close();document.body.classList.remove('writing-open');card.focus({preventScroll:true});}
 dialog.addEventListener('click',event=>{const button=event.target.closest('[data-write]'),action=button?.dataset.write;if(!action||button.disabled)return;
  if(action==='close')return close();if(action==='restart'){close();return start();}
  if(action==='voice'){wordVoice();return;}
  if(action==='reload'&&loadFailed)return render();if(action==='skip'&&loadFailed)return next(false);
  if(action==='hint'&&ready&&!characterDone){hints++;writer.highlightStroke(strokeIndex);return;}
  if(action==='reset'&&ready){render();return;}
  if(action==='advance'&&characterDone){if(++characterIndex===characters().length){characterIndex=0;if(stage==='trace'){stage='recall';attempts++;}else stage='result';}render();return;}
  if(action==='retry'&&stage==='result'){stage='recall';characterIndex=0;attempts++;render();return;}
  if(action==='next'&&stage==='result')next();
 });
 dialog.addEventListener('cancel',event=>{event.preventDefault();close();});
 function refreshReading(){if(!dialog.open)return;const badge=dialog.querySelector('.session-hsk');if(badge)badge.textContent=HSK.label(sessionScope.level,sessionScope.cumulative);if(stage==='done')return;const reading=dialog.querySelector('.writing-reading');if(reading)reading.innerHTML=`${Pinyin.html(word().py,'writing-pinyin')}<span data-learning>${esc(UI.meaning(word()))}</span>`;}
 UI.onChange(refreshReading);$('pinyin').addEventListener('change',refreshReading);
 card.addEventListener('click',start);return {start};
})();
