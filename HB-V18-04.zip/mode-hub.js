'use strict';
// Presentation only. Existing handlers, HSK normalization and UI language own state.
(()=>{
 // Root is Home. URL hashes, not a preview-only marker, own top-level destinations.
 const lobby=$('mode-lobby'),heading=lobby.querySelector('.lobby-heading h2');
 heading.textContent='เลือกภารกิจของคุณ';
 const level=$('mission-level'),levelKey='hanzi-ufo-level-v1';
 // Only real UFO-supported levels, copied from the authoritative production selector.
 for(const option of $('level').options){if(!/^[1-5]$/.test(option.value))continue;const item=document.createElement('option');item.value=option.value;item.textContent=HSK.label(option.value);level.append(item);}
 try{const saved=HSK.normalize(localStorage.getItem(levelKey));level.value=saved==='all'?'1':saved;}catch{level.value='1';}
 level.addEventListener('change',()=>{HSK.select(level.value);});
 const syncLevel=()=>{const value=HSK.normalize($('level').value);level.value=value==='all'?'1':value;try{localStorage.setItem(levelKey,level.value);}catch{}};
 $('level').addEventListener('change',syncLevel);
 // Reuse the existing persisted HSK preference; no Home-specific storage owner.
 HSK.select(level.value);
 const nav=document.createElement('nav');nav.className='mission-nav';nav.setAttribute('aria-label',UI.t('เมนูหลัก'));
 const icons=['<path d="M3 13 14 4l11 9M6 11v13h6v-8h4v8h6V11"/>','<circle cx="14" cy="14" r="7" fill="currentColor" stroke="none"/><ellipse cx="14" cy="14" rx="13" ry="4" transform="rotate(-25 14 14)"/>','<path d="M5 24V16h4v8M12 24V5h4v19M19 24V11h4v13"/>'];
 for(const [index,[href,label]] of [['./#launch','หน้าแรก'],['#mode-lobby','โหมดเกม'],['#learning-progress','ความคืบหน้า']].entries()){
  const link=document.createElement('a');link.href=href;const symbol=document.createElement('span');symbol.innerHTML='<svg viewBox="0 0 28 28" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'+icons[index]+'</svg>';symbol.setAttribute('aria-hidden','true');const text=document.createElement('span');text.textContent=label;link.append(symbol,text);nav.append(link);
  link.addEventListener('click',event=>{const hash=link.getAttribute('href').split('#')[1];if('#'+hash===location.hash||hash==='launch'&&!location.hash){event.preventDefault();window.scrollTo({top:0,left:0,behavior:'auto'});}});
 }
 document.body.append(nav);
 const isHome=()=>!location.hash||location.hash==='#launch';
 const isTopLevel=()=>isHome()||['#mode-lobby','#learning-progress'].includes(location.hash);
 // Incoming decoration only: route truth/input never await it. A completion
 // promise belongs to its route generation; cancelled/old entries cannot win.
 let shellRoute=null,shellIdle=false,entrySerial=0;
 const clearShellEntry=()=>{entrySerial++;document.body.removeAttribute('data-shell-entry');};
 function enterShell(destination){
  if(window.matchMedia?.('(prefers-reduced-motion: reduce)').matches)return;
  const serial=entrySerial;
  document.body.setAttribute('data-shell-entry',destination);
  const target=destination==='home'?document.querySelector('.home-brand'):$(destination==='modes'?'mode-lobby':'learning-progress');
  const animation=target?.getAnimations?.().find(item=>item.animationName==='shell-route-enter');
  // Unsupported animation APIs or a static CSS branch need no pending state.
  if(!animation){clearShellEntry();return;}
  const settled=()=>{if(serial===entrySerial)clearShellEntry();};
  animation.finished.then(settled,settled);
 }
 function syncNavigation(){
  const occupied=document.body.classList.contains('playing')||document.body.classList.contains('adventure-view')||!!$('results')&&!$('results').hidden;
  const home=isHome()&&!occupied;
  if(document.body.classList.contains('home-view')!==home)document.body.classList.toggle('home-view',home);
  const hidden=!isTopLevel()||occupied;if(nav.hidden!==hidden)nav.hidden=hidden;
  if((occupied||document.querySelector('dialog[open]'))&&document.body.getAttribute('data-shell-entry'))clearShellEntry();
  for(const link of nav.children){const hash='#'+link.getAttribute('href').split('#')[1],selected=hash===location.hash||hash==='#launch'&&isHome();if(selected)link.setAttribute('aria-current','page');else link.removeAttribute('aria-current');}
 }
 function route(event){
  if(settingsDialog.open)settingsDialog.close();
  const hub=location.hash==='#mode-lobby',progress=location.hash==='#learning-progress';
  document.body.classList.toggle('mode-hub-view',hub);
  document.body.classList.toggle('hub-progress-view',progress);
  (isTopLevel()?$('mission-settings-slot'):triggerParent).append(trigger);
  trigger.classList.toggle('mission-settings',isTopLevel());
  trigger.textContent=isTopLevel()?'⚙':UI.t('ระดับศัพท์และตัวช่วย');
  syncNavigation();
  const destination=isHome()?'home':hub?'modes':progress?'progress':null;
  const idle=!!destination&&!nav.hidden&&!document.querySelector('dialog[open]');
  const changed=destination!==shellRoute,restoring=event?.type==='pageshow';
  const incoming=changed&&shellRoute&&shellIdle&&idle&&!restoring;
  if(changed||!idle||restoring)clearShellEntry();
  shellRoute=destination;shellIdle=idle;
  if(incoming)enterShell(destination);
  if(isTopLevel())requestAnimationFrame(()=>window.scrollTo({top:0,left:0,behavior:'instant'}));
 }
 // The canonical settings control/panel is moved, never cloned; its existing
 // handlers and values remain authoritative in both Home and mission selection.
 const languageButtons=[...document.querySelectorAll('.mission-language button')];
 const syncLanguage=()=>{for(const button of languageButtons)button.setAttribute('aria-pressed',String(button.dataset.uiLanguage===UI.language));};
 for(const button of languageButtons)button.addEventListener('click',()=>UI.set(button.dataset.uiLanguage));
 syncLanguage();UI.onChange(syncLanguage);
 const settings=$('settings-panel'),parent=settings.parentNode,next=settings.nextSibling,trigger=$('open-settings'),triggerParent=trigger.parentNode,originalOpen=trigger.onclick;
 const settingsDialog=document.createElement('dialog');settingsDialog.className='mission-settings-dialog';
 const close=document.createElement('button');close.type='button';close.className='mission-settings-close';close.textContent='×';close.onclick=()=>settingsDialog.close();settingsDialog.append(close);document.body.append(settingsDialog);
 $('mission-settings-slot').append(trigger);trigger.classList.add('mission-settings');trigger.textContent='⚙';
 const syncSettings=()=>{trigger.textContent=isTopLevel()?'⚙':UI.t('ระดับศัพท์และตัวช่วย');trigger.setAttribute('aria-label',UI.t('ระดับศัพท์และตัวช่วย'));settingsDialog.setAttribute('aria-label',UI.t('ระดับศัพท์และตัวช่วย'));close.setAttribute('aria-label',UI.t('ปิดการตั้งค่า'));};syncSettings();UI.onChange(syncSettings);
 let wasSetupOpen=false;
 trigger.onclick=()=>{if(!isTopLevel()){originalOpen();return;}wasSetupOpen=document.body.classList.contains('setup-open');settingsDialog.append(settings);settingsDialog.showModal();originalOpen();};
 settingsDialog.addEventListener('close',()=>{if(next?.parentNode===parent)parent.insertBefore(settings,next);else parent.append(settings);document.body.classList.toggle('setup-open',wasSetupOpen);});
 $('results-home')?.addEventListener('click',()=>{
  // Explicit Training/Review return uses the approved router even when the
  // session began in Adventure or Progress. Completion itself keeps its route.
  const training=['practice','match','timed','endless','arcade','listening'].includes(sessionMode);
  if(!isTopLevel()&&!training)return;
  location.hash='mode-lobby';route();
 });
 if(typeof MutationObserver!=='undefined'){const lifecycle=new MutationObserver(syncNavigation);lifecycle.observe(document.body,{attributes:true,attributeFilter:['class']});if($('results'))lifecycle.observe($('results'),{attributes:true,attributeFilter:['hidden']});}
 // No frame loop. Stop decorative animation when the Hub leaves view or the tab hides.
 let inView=true;const ambient=()=>document.body.classList.toggle('hub-ambient-paused',!inView||document.hidden);
 if(typeof IntersectionObserver!=='undefined')new IntersectionObserver(entries=>{inView=entries.some(entry=>entry.isIntersecting);ambient();}).observe(lobby);
 document.addEventListener('visibilitychange',ambient);
 window.addEventListener('hashchange',route);window.addEventListener('pageshow',route);route();
 // Reuse the existing translation catalog/observer; no second translation owner.
 UI.apply(lobby);UI.apply(nav);
 UI.onChange(()=>{heading.textContent=UI.t('เลือกภารกิจของคุณ');nav.setAttribute('aria-label',UI.t('เมนูหลัก'));});
})();
