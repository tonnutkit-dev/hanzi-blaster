'use strict';
// V2B Batch 2 presentation. No answer, clock, speech, storage or pointer owner.
(()=>{
 const body=document.body,arena=document.querySelector('.arena');
 const sentence=$('sentence-dialog'),sentenceBody=$('sentence-body'),writing=$('writing-lab');
 const language=document.querySelector('.language-picker');
 let current=null,world=null,languageMarker=null,tools=null,lastStroke='',lastBubblePrompt='',lastBubbleLives=null;
 let sentenceView=null,sentenceBoundary='',writingView=null;
 function worldLayers(){
  const root=document.createElement('div');root.className='tailored-world';root.setAttribute('aria-hidden','true');
  for(const name of ['base','structures','haze','particles']){const layer=document.createElement('div');layer.className='tailored-world-'+name;root.append(layer);}
  return root;
 }
 function restoreLanguage(){if(languageMarker){languageMarker.replaceWith(language);languageMarker=null;}tools?.remove();tools=null;}
 function placeLanguage(host){
  if(!languageMarker){languageMarker=document.createComment('original language control');language.parentNode.insertBefore(languageMarker,language);}
  if(!tools){tools=document.createElement('div');tools.className='tailored-tools';}
  host.append(tools);tools.append(language);
 }
 function bubbleMode(){
  if(active&&sessionMode==='bubbles')return 'bubbles';
  if(!active&&sessionMode==='bubbles'&&$('results')&&!$('results').hidden)return 'bubble-results';
  return null;
 }
 function clearBubblePresentation(){
  arena.classList.remove('bubble-target-change','bubble-life-change','bubble-life-low','bubble-time-pressure');
  delete arena.dataset.bubbleVerdict;body.classList.remove('bubble-results');lastBubblePrompt='';lastBubbleLives=null;
 }
 function pulseBubbleClass(name){arena.classList.remove(name);void arena.offsetWidth;arena.classList.add(name);}
 function bubblePresentation(){
  const targets=$('targets'),prompt=$('prompt'),lives=$('lives'),timebar=$('timebar');
  const nextPrompt=prompt?.textContent||'',targetChanged=!!nextPrompt&&nextPrompt!==lastBubblePrompt;
  if(targetChanged){lastBubblePrompt=nextPrompt;arena.classList.remove('bubble-life-change','bubble-time-pressure');pulseBubbleClass('bubble-target-change');}
  const verdict=targets?.querySelector('.word-bubble.wrong')?'wrong':targets?.querySelector('.word-bubble.correct')?'correct':'';
  if(verdict)arena.dataset.bubbleVerdict=verdict;else delete arena.dataset.bubbleVerdict;
  const filled=lives?[...lives.textContent].filter(char=>char==='♥').length:null;
  if(filled!==null){if(lastBubbleLives!==null&&filled<lastBubbleLives)pulseBubbleClass('bubble-life-change');lastBubbleLives=filled;arena.classList.toggle('bubble-life-low',filled<=1);}
  if(!targetChanged&&timebar){const danger=/ff7180|255\s*,\s*113\s*,\s*128/i.test(timebar.style.background);arena.classList.toggle('bubble-time-pressure',danger);}
 }
 function closePresentation(){
  restoreLanguage();world?.remove();world=null;current=null;lastStroke='';
  sentenceView=writingView=null;sentenceBoundary='';
  clearBubblePresentation();body.classList.remove('tailored-pilot','tailored-ambient-paused');delete body.dataset.tailoredMode;
 }
 // Focus is a reading anchor, never a text input, answer or drawing owner.
 // Only reclaim focus lost by owner DOM replacement, not a live utility/control.
 function readingAnchor(dialog,region){
  if(region.tabIndex!==-1)region.tabIndex=-1;
  const focused=document.activeElement;
  if(focused===body||focused===dialog)region.focus?.({preventScroll:true});
 }
 function sentenceContinuity(){
  const view=sentenceBody.firstElementChild;if(!view||view===sentenceView)return;
  sentenceView=view;
  const boundary=sentenceBody.dataset.tailoredPhase+':'+(sentenceBody.querySelector('.sentence-hud b')?.textContent||'');
  // Pause/replay/locale repaint keeps the current reading position. A new task
  // or result/setup boundary returns to its heading, without a smooth delay.
  if(boundary!==sentenceBoundary){sentenceBoundary=boundary;if(sentence.scrollTop)sentence.scrollTop=0;}
  readingAnchor(sentence,sentenceBody);
 }
 function writingContinuity(){
  const region=writing.querySelector('.writing-body');if(!region||region===writingView)return;
  writingView=region;
  const stage=region.dataset.stage||(region.querySelector('[data-write="restart"]')?'complete':'result');
  if(region.dataset.focusStage!==stage)region.dataset.focusStage=stage;
  if(writing.scrollTop)writing.scrollTop=0;
  readingAnchor(writing,region);
 }
 function sentencePresentation(){
  const phase=sentenceBody.querySelector('.sentence-options')?'question':sentenceBody.querySelector('.sentence-verdict')?'answer':sentenceBody.querySelector('#sentence-level')?'setup':'result';
  sentenceBody.dataset.tailoredPhase=phase;sentenceBody.classList.toggle('tailored-long-answers',[...sentenceBody.querySelectorAll('.sentence-options button')].some(n=>[...n.textContent].length>100));
  if(phase==='question'&&!sentenceBody.querySelector('.tailored-scroll')){
   const scroll=document.createElement('section');scroll.className='tailored-scroll';
   const line=sentenceBody.querySelector('.sentence-zh');line.before(scroll);scroll.dataset.long=String([...line.textContent].length>16);
   for(const node of [...sentenceBody.children])if(node.matches('.sentence-zh,.sentence-py,.sentence-context,.eyebrow'))scroll.append(node);
  }
  // The owner replaces body HTML every phase; decorations stay outside it.
  if(world.parentNode!==sentence)sentence.prepend(world);
  if(language.parentNode?.parentNode!==sentence)placeLanguage(sentence);
  sentenceContinuity();
 }
 function writingPresentation(){
  // Owner rebuilds the dialog. Never wrap/reparent surface or drawing SVG.
  if(world.parentNode!==writing)writing.prepend(world);
  const head=writing.querySelector('.writing-head');if(head&&language.parentNode?.parentNode!==head)placeLanguage(head);
  const region=writing.querySelector('.writing-body'),surface=writing.querySelector('.writing-surface');
  if(region&&surface&&!region.querySelector('.tailored-writing-frame')){
   const frame=document.createElement('div');frame.className='tailored-writing-frame';frame.setAttribute('aria-hidden','true');surface.before(frame);
  }
  const status=writing.querySelector('.writing-strokes'),next=status?.textContent||'';
  if(status&&next!==lastStroke){
   // Correct-stroke status is authoritative; an old miss accent must not
   // survive into that state, especially the static Reduced Motion border.
   if(surface?.classList.contains('stroke-miss'))surface.classList.remove('stroke-miss');
   if(lastStroke&&/\d/.test(next)){status.classList.remove('tailored-stroke-pulse');void status.offsetWidth;status.classList.add('tailored-stroke-pulse');}
   lastStroke=next;region?.classList.toggle('tailored-character-complete',next.includes('✓'));
  }
  writingContinuity();
 }
 function sync(){
  const mode=writing.open?'writing':sentence.open?'sentences':bubbleMode();
  if(mode!==current){closePresentation();if(mode){current=mode;world=worldLayers();body.classList.add('tailored-pilot');body.dataset.tailoredMode=mode;}}
  if(!current)return;
  if(mode==='sentences')sentencePresentation();
  else if(mode==='writing')writingPresentation();
  else if(mode==='bubbles'){body.prepend(world);placeLanguage(arena.querySelector('.arena-foot'));bubblePresentation();}
  else{body.prepend(world);body.classList.add('bubble-results');}
  const paused=document.hidden||!!sentenceBody.querySelector('[data-sentence="resume"]')||!!$('exit-dialog').open||!!$('howto-dialog')?.open||(mode==='bubbles'&&!$('bubble-cover').hidden);
  body.classList.toggle('tailored-ambient-paused',paused);
 }
 // Observer callbacks may see our presentation mutations: move only when needed.
 function stableSync(){
  const before=writing.open?'writing':sentence.open?'sentences':bubbleMode();
  if(before===current&&current){
   if(current==='sentences'&&sentence.querySelector('.tailored-world')&&sentenceBody.dataset.tailoredPhase===(sentenceBody.querySelector('.sentence-options')?'question':sentenceBody.querySelector('.sentence-verdict')?'answer':sentenceBody.querySelector('#sentence-level')?'setup':'result')&&(!sentenceBody.querySelector('.sentence-options')||sentenceBody.querySelector('.tailored-scroll'))){sentenceContinuity();return pauseOnly();}
   if(current==='writing'&&writing.querySelector('.tailored-world')&&(!writing.querySelector('.writing-surface')||writing.querySelector('.tailored-writing-frame'))&&lastStroke===(writing.querySelector('.writing-strokes')?.textContent||'')){writingContinuity();return pauseOnly();}
   if(current==='bubbles'){bubblePresentation();return pauseOnly();}
   if(current==='bubble-results'&&document.querySelector('.tailored-world'))return pauseOnly();
  }
  sync();
 }
 function pauseOnly(){const paused=document.hidden||!!sentenceBody.querySelector('[data-sentence="resume"]')||!!$('exit-dialog').open||!!$('howto-dialog')?.open||(current==='bubbles'&&!$('bubble-cover').hidden);body.classList.toggle('tailored-ambient-paused',paused);}
 const observer=new MutationObserver(stableSync);
 observer.observe(body,{attributes:true,attributeFilter:['class']});
 for(const host of [sentence,writing])observer.observe(host,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['open']});
 observer.observe(arena,{attributes:true,attributeFilter:['class']});
 for(const host of [$('targets'),$('prompt'),$('lives'),$('timebar'),$('results')])if(host)observer.observe(host,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['class','style','hidden']});
 for(const host of [$('exit-dialog'),$('howto-dialog'),$('bubble-cover')])if(host)observer.observe(host,{attributes:true,attributeFilter:['open','hidden']});
 document.addEventListener('visibilitychange',pauseOnly);sync();
})();
