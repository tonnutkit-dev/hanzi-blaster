 'use strict';
let roundBefore=new Set();
$('quick-start').onclick=()=>{if(active)return;$('mode').value='campaign';selectedChapter=Math.min(stageUnlocked(),5);settings();start();};
$('open-settings').onclick=()=>{$('settings-panel').open=true;$('settings-panel').scrollIntoView({behavior:'smooth',block:'start'});$('mode').focus();};
function polishResult(reason){const seen=new Map(history.map(h=>[h.word.id,h.word])),missed=new Set(),recovered=new Set();for(const h of history){if(!h.ok){missed.add(h.word.id);recovered.delete(h.word.id);}else if(missed.has(h.word.id))recovered.add(h.word.id);}const newly=[...seen.values()].filter(w=>!roundBefore.has(w.id)&&learning[w.id]?.streak>=3);$('learning-summary').textContent=`ฝึก ${seen.size} คำ · เริ่มแม่นเพิ่ม ${newly.length} คำ · แก้คำที่พลาดได้ ${recovered.size} คำ — เป็นผลรอบนี้ ยังควรกลับมาทบทวน`;$('next-chapter').classList.toggle('primary',reason==='victory');$('again').textContent=reason==='lives'?'กลับไปฝึกแล้วแก้มือ →':'เล่นอีกรอบ →';}

// Five familiar, due or weak words. Device-local history is the source of truth.
let dailySession=false;
function dailyWords(){const list=selectedWords(),now=Date.now();const priority=w=>{const l=learning[w.id];return !l?3:l.wrong>0&&l.streak<3?0:l.due<=now?1:2;};return shuffle(list).sort((a,b)=>priority(a)-priority(b)||(learning[b.id]?.wrong||0)-(learning[a.id]?.wrong||0)).slice(0,5);}
function dailyStatus(){const list=dailyWords(),seen=list.filter(w=>learning[w.id]).length;$('daily-status').textContent=seen?`ทบทวนสั้น ๆ จากคำที่เคยฝึก · HSK ${$('level').value==='all'?'ผสม':$('level').value}`:'ยังไม่มีประวัติ? เริ่มเก็บศัพท์ชุดแรกได้เลย';}
$('daily-review').onclick=()=>{if(active)return;start(dailyWords());dailySession=true;$('mode-text').textContent='ทบทวนวันนี้ · 5 คำ';$('round-label').textContent='คำทบทวน';};
const originalPolishResult=polishResult;
polishResult=function(reason){originalPolishResult(reason);if(dailySession){if(reason==='complete'){$('result-title').textContent='ทบทวนวันนี้ครบแล้ว!';$('saved-score').textContent='เก็บความคืบหน้าคำศัพท์แล้ว · ภารกิจนี้ไม่รวมในอันดับ';try{localStorage.setItem('hanzi-daily-last',new Date().toISOString())}catch{}battleAudio.play('win');}else $('result-title').textContent='พักไว้ก่อน กลับมาทบทวนได้เสมอ';dailySession=false;}dailyStatus();};
dailyStatus();
