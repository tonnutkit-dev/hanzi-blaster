'use strict';
let exitSnapshot=null;
function requestRoundExit(){
 if(!active||exitPaused)return;
 const now=performance.now();exitSnapshot={at:now,run,clockRunning:RoundClock.phase==='ACTIVE',callback:autoCallback,remaining:Math.max(0,autoDeadline-now),bubblePaused:sessionMode==='bubbles'&&BubbleField.paused};
 if(timed())RoundClock.pause('READY');exitPaused=true;clearInterval(interval);interval=null;clearTimeout(auto);auto=null;
 if(sessionMode==='bubbles')BubbleField.pause();
 clearShotEffects();if(sessionMode==='timed')battleAudio.stop();answerGate?.pause();LearningAudio.cancel();
 const noRank=config.review||sessionMode==='campaign'||['arcade','timed','match','listening','bubbles'].includes(sessionMode);
 $('exit-description').textContent=`ตอบไปแล้ว ${history.length} ข้อ · ${score} คะแนน\nความคืบหน้าคำศัพท์ที่ตอบแล้วจะยังอยู่${noRank?' แต่รอบที่จบตอนนี้จะไม่บันทึกอันดับ':''} เมื่อกลับมาเล่นจะเริ่มรอบใหม่`;
 $('exit-title').textContent='ออกจากรอบนี้ไหม?';$('exit-dialog').showModal();$('exit-cancel').focus();
}
function cancelRoundExit(){
 if(!exitPaused||!exitSnapshot)return;
 const saved=exitSnapshot,elapsed=performance.now()-saved.at;exitSnapshot=null;exitPaused=false;$('exit-dialog').close();
 if(!active||run!==saved.run)return;
 deadline+=elapsed;questionDeadline+=elapsed;LearningEngine.excludePause(elapsed);
 if(sessionMode==='bubbles'&&!saved.bubblePaused)BubbleField.resume();
 if(saved.callback)later(saved.callback,saved.remaining);else answerGate?.resume();
 if(saved.clockRunning)playable();interval=setInterval(tick,80);$('exit').focus();
}
$('exit-cancel').onclick=cancelRoundExit;
$('exit-confirm').onclick=()=>{if(!exitPaused)return;exitPaused=false;exitSnapshot=null;autoCallback=null;$('exit-dialog').close();finish('exit');};
$('exit-dialog').addEventListener('cancel',e=>{e.preventDefault();cancelRoundExit();});

function requestRoundPause(){if(!active||exitPaused)return;requestRoundExit();$('exit-title').textContent='พักเกม';$('exit-description').textContent='เวลาและชีวิตหยุดอยู่ · กดเล่นต่อเพื่อกลับไปข้อเดิม หรือจบรอบเพื่อดูผล';}
if(document.getElementById('round-pause'))$('round-pause').onclick=requestRoundPause;
