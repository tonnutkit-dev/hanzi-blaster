'use strict';
const sentenceGame=(()=>{
 const dialog=$('sentence-dialog'),body=$('sentence-body');let queue=[],index=0,results=[],locked=false,timer=null,deadline=0,remaining=0,paused=false,level='1',phase='setup',voiceToken=0,focusWords=[],transition=0,automatic=true;
 const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const local=(th,en)=>UI.language==='en'?en:th;
 let learning={};try{const saved=JSON.parse(localStorage.getItem('hanzi-sentences-v1')||'{}');if(saved&&typeof saved==='object'&&!Array.isArray(saved))learning=saved;}catch{}
 function silence(){voiceToken++;window.HanziAudio?.speech(false,'sentence');if('speechSynthesis'in window)window.speechSynthesis.cancel();}
 function stop(){transition++;clearTimeout(timer);timer=null;body.classList.remove('sentence-leaving','sentence-entering');silence();}
 function say(text,done=()=>{}){
  silence();const token=voiceToken;let settled=false;
  const finish=(ok=false)=>{if(token!==voiceToken||settled)return;settled=true;window.HanziAudio?.speech(false,'sentence');done(ok);};
  if(!('speechSynthesis'in window)||typeof SpeechSynthesisUtterance==='undefined'){status('เครื่องนี้ไม่มีเสียงอ่าน ยังเล่นจากข้อความได้');finish();return;}
  try{const u=new SpeechSynthesisUtterance(text);u.lang='zh-CN';u.rate=.85;u.onend=()=>finish(true);u.onerror=e=>{if(token!==voiceToken||settled)return;if(!['canceled','interrupted'].includes(e.error))status('เสียงยังไม่พร้อม กดฟังซ้ำได้');finish();};window.HanziAudio?.speech(true,'sentence');window.speechSynthesis.speak(u);}catch{status('เสียงยังไม่พร้อม กดฟังซ้ำได้');finish();}
 }
 function status(text){const el=$('sentence-status');if(el)el.textContent=UI.t(text);}
 function paint(html){body.innerHTML=html;UI.apply(body);}
 function button(label,action,cls=''){return `<button class="${cls}" data-sentence="${action}">${UI.t(label)}</button>`;}
 function open(focus=[]){if(active||$('combat')?.open)return;stop();focusWords=Array.isArray(focus)?focus:[];phase='setup';level=['1','2','3','4','5'].includes($('level').value)?$('level').value:'mix';dialog.showModal();setup();}
 function setup(){stop();phase='setup';paint(`<span class="eyebrow">${local('句子任务 / ภารกิจประโยค','句子任务 / Sentence Mission')}</span><h2>จากคำศัพท์ สู่ประโยค</h2><p>เติมคำ · แปลความหมาย · ตอบบทสนทนา สูงสุด 10 ข้อ · ไม่จับเวลาตอบ</p><label for="sentence-level">ระดับประโยค</label><select id="sentence-level">${[1,2,3,4,5].map(l=>`<option value="${l}">HSK ${l} · ${SentenceBank.missionAvailable(l).length} ${local('ประโยค','sentences')}</option>`).join('')}<option value="mix">${local('ผสม HSK 1–5','Mixed HSK 1–5')}</option></select>${focusWords.length?'<p class="context-note">ประโยคจากคำที่เพิ่งฝึก</p>':''}<p class="sentence-coverage">${local('ชุดเริ่มต้น '+SENTENCES.length+' ประโยค · เลือกระดับเพื่อฝึกเฉพาะระดับนั้น','A '+SENTENCES.length+'-sentence starter bank · Practice the selected level only')}<br>${local('HSK5 มี 50 ประโยคฝึกเริ่มต้น ยังไม่ครอบคลุมทุกคำศัพท์หรือไวยากรณ์','HSK5 has 50 starter sentences, not complete vocabulary or grammar coverage')}</p><label><input id="sentence-pinyin" type="checkbox" ${Pinyin.enabled?'checked':''}> แสดงพินอิน</label><div class="sentence-actions">${button('เริ่มภารกิจ','start','primary')}${button('ทบทวนข้อที่พลาด','review')}</div><p id="sentence-status" role="status"></p>`);$('sentence-level').value=level;}
 function begin(review=false){stop();level=$('sentence-level').value;HSK.select(level);automatic=$('feedback-mode')?.value!=='manual';Pinyin.set($('sentence-pinyin').checked);LearningEngine.begin();const pool=SentenceBank.missionAvailable(level).filter(q=>!focusWords.length||q.targets.some(zh=>focusWords.some(w=>w.zh===zh)));if(review){queue=shuffle(pool.filter(q=>(learning[q.id]?.wrong||0)>0&&!learning[q.id]?.lastOK)).slice(0,10);if(!queue.length){status('ยังไม่มีข้อที่ต้องทบทวนในระดับนี้ ลองเริ่มภารกิจได้เลย');return;}}else{queue=SentenceBank.round(level,10,focusWords);if(!queue.length){status('ยังไม่มีประโยคที่ตรงกับคำชุดนี้ในระดับที่เลือก');return;}}index=0;results=[];paused=false;try{window.BetaCloud?.startSession('sentences',level==='mix'?null:+level);}catch{}show();}
 function line(zh,py){return `<div class="sentence-zh" lang="zh-CN">${esc(zh)}</div>${Pinyin.html(py,'sentence-py')}`;}
 let options=[];
 function sessionLabel(){return `<strong class="session-mode">${UI.t('ภารกิจประโยค')}</strong><span class="session-hsk">${HSK.label(level)}</span>`;}
 function scene(q){return UI.language==='en'?q.sceneEnglish:q.scene;}
 function renderQuestion(){const q=queue[index];body.dataset.exercise=q.type;paint(`<div class="sentence-hud"><span class="sentence-levels">${sessionLabel()}<span>${level==='mix'?`HSK ${q.level} · `:''}${esc(scene(q))}</span></span><b>${index+1} / ${queue.length}</b></div><progress max="${queue.length}" value="${index}"></progress><span class="eyebrow">${q.type==='fill'?'ยิงเติมคำ':q.type==='meaning'?'เข้าใจความหมาย':'ตอบบทสนทนา'}</span>${line(q.prompt,q.py)}<p class="sentence-context" data-learning>${esc(local(q.th,q.contextEnglish))}</p><div class="sentence-options">${options.map((a,i)=>button(`<small>${i+1}</small> <span lang="${q.type==='meaning'?UI.language:'zh-CN'}">${esc(SentenceBank.translate(q,a))}</span>${Pinyin.html(q.optionPinyin?.[a],'sentence-option-py')}`,'answer-'+i)).join('')}</div><div class="sentence-actions">${button('▶ ฟังโจทย์','voice')}</div><p id="sentence-status" role="status">${q.type==='fill'?UI.t('เลือกคำเติมช่องว่าง'):q.type==='meaning'?local('เลือกความหมายของประโยค','Choose the meaning of the sentence'):UI.t('เลือกประโยคให้ตรงกับสถานการณ์')}</p>`);}
 function questionSpeech(q){return q.type==='fill'?q.prompt.replace('___','什么'):q.prompt;}
 function show(){stop();phase='question';locked=false;paused=false;LearningEngine.mark();options=shuffle(queue[index].options);renderQuestion();say(questionSpeech(queue[index]));}
 function renderAnswer(){const {q,ok,chosen}=results.at(-1),language=q.type==='meaning'?UI.language:'zh-CN';const choice=(value,correct)=>`<span class="sentence-verdict-choice" lang="${language}" data-learning>${esc(SentenceBank.translate(q,value))}</span><b aria-hidden="true">${correct?'✓':'✕'}</b>`;paint(`<div class="sentence-hud"><span class="sentence-levels">${sessionLabel()}<span>${level==='mix'?`HSK ${q.level} · `:''}${esc(scene(q))}</span></span><b>${index+1} / ${queue.length}</b></div><section class="sentence-verdict ${ok?'is-correct':'is-wrong'}" role="status" aria-live="polite"><strong class="sentence-verdict-title"><span aria-hidden="true">${ok?'✓':'✕'}</span> ${local(ok?'ตอบถูก!':'ตอบผิด',ok?'Correct!':'Incorrect')}</strong><div class="sentence-verdict-row ${ok?'is-answer':'is-chosen'}"><span>${local('คุณเลือก:','You chose:')}</span>${choice(chosen,ok)}</div>${ok?'':`<div class="sentence-verdict-row is-answer"><span>${local('คำตอบที่ถูก:','Correct answer:')}</span>${choice(q.answer,true)}</div>`}</section><div class="sentence-answer-detail">${line(q.full,q.fullPy)}<h3 data-learning>${esc(UI.sentenceMeaning(q))}</h3><p class="sentence-explanation" data-learning>${esc(local(q.note,q.noteEnglish))}</p></div><div class="sentence-actions">${button('▶ ฟังซ้ำ','voice')}${automatic?button(paused?'เล่นต่อ':'พักอ่านเฉลย',paused?'resume':'pause'):''}${button('ไปต่อ','continue')}</div><p id="sentence-status" role="status">${UI.t(!automatic?'กดไปต่อเมื่อพร้อม':paused?'พักอยู่ · กดเล่นต่อเมื่อพร้อม':'ฟังจบแล้วไปต่ออัตโนมัติ · กดพักเพื่ออ่านต่อได้')}</p>`);}
 function answer(i){if(phase!=='question'||locked||!options[i])return;locked=true;phase='answer';const q=queue[index],ok=options[i]===q.answer;results.push({q,ok,chosen:options[i]});const target=SentenceBank.target(q);if(target)LearningEngine.record(target,ok,LearningEngine.elapsed());const old=learning[q.id]||{correct:0,wrong:0};learning[q.id]={correct:old.correct+(ok?1:0),wrong:old.wrong+(ok?0:1),lastOK:ok,last:Date.now()};try{localStorage.setItem('hanzi-sentences-v1',JSON.stringify(learning));}catch{}battleAudio.unlock();battleAudio.play(ok?'correct':'wrong');renderAnswer();dialog.scrollTop=0;const spoken=schedule(ok?2000:2200,true,q.full);say(q.full,spoken);}
 function next(){if(phase!=='answer')return;stop();index++;if(index>=queue.length)summary();else show();}
 // One transition timer waits for BOTH the reading minimum and initial speech.
 // The generous watchdog handles missing callbacks; it never cancels a voice still speaking.
 function schedule(ms,waitForSpeech=false,text=''){
  clearTimeout(timer);timer=null;const token=++transition,question=index;
  remaining=ms;deadline=performance.now()+ms;let speechDone=!waitForSpeech,speechReadyAt=0,fading=false;
  const speechDeadline=performance.now()+Math.min(60000,Math.max(15000,[...text].length*1500+5000));
  const valid=()=>token===transition&&question===index&&dialog.open&&!paused&&phase==='answer';
  function check(){
   if(!valid()||!automatic||fading)return;
   clearTimeout(timer);timer=null;const now=performance.now();
   if(!speechDone&&now>=speechDeadline){
    if(window.speechSynthesis?.speaking){
     // Some engines never emit onend or keep speaking=true forever. Hand control
     // to the learner rather than cutting a healthy utterance or looping forever.
     transition++;remaining=0;paused=true;renderAnswer();status('เสียงอ่านใช้เวลานาน · กดไปต่อเมื่อพร้อม');return;
    }
    speechDone=true;
   }
   if(now>=Math.max(deadline,speechReadyAt)&&speechDone){
    if(fading)return;fading=true;body.classList.add('sentence-leaving');
    const fade=window.matchMedia?.('(prefers-reduced-motion:reduce)').matches?0:160;
    timer=setTimeout(()=>{if(valid()&&automatic){next();if(phase==='question')body.classList.add('sentence-entering');}},fade);return;
   }
   timer=setTimeout(check,Math.max(0,speechDone?Math.max(deadline,speechReadyAt)-now:now<deadline?deadline-now:speechDeadline-now));
  }
  check();return (ok=false)=>{if(!valid()||speechDone)return;speechDone=true;speechReadyAt=ok?performance.now()+600:performance.now();check();};
 }
 function pause(){if(phase!=='answer'||paused)return;remaining=Math.max(0,deadline-performance.now());stop();paused=true;renderAnswer();}
 function resume(){if(!paused||phase!=='answer')return;silence();paused=false;renderAnswer();schedule(Math.max(remaining,1000));}
 function renderSummary(){const right=results.filter(r=>r.ok),wrong=results.filter(r=>!r.ok);paint(`<span class="eyebrow">ภารกิจเสร็จแล้ว</span><h2>${local('ตอบถูก '+right.length+' / '+results.length+' ข้อ',right.length+' / '+results.length+' correct')}</h2><p>ตอบถูกครั้งนี้เป็นก้าวแรก กลับมาทบทวนเพื่อให้จำได้แม่นขึ้น</p>${[['ประโยคที่ตอบถูก',right],['ประโยคที่ควรทบทวน',wrong]].map(([title,list])=>`<h3>${UI.t(title)} · ${list.length}</h3>${list.map(({q})=>`<div class="sentence-review">${line(q.full,q.fullPy)}<p data-learning>${esc(UI.sentenceMeaning(q))}</p></div>`).join('')}`).join('')}<div class="sentence-actions">${button('เล่นชุดใหม่','setup','primary')}${wrong.length?button('ฝึกข้อที่พลาดรอบนี้','retry'):''}${button('กลับหน้าหลัก','close')}</div><p>บันทึกความคืบหน้าประโยคแยกจากศัพท์ ในเบราว์เซอร์เครื่องนี้</p>`);}
 function summary(){window.HanziAudio?.cue('complete');try{window.BetaCloud?.endSession({score:0,combo:0,correct:results.filter(r=>r.ok).length,wrong:results.filter(r=>!r.ok).length,reason:'complete'});}catch{}stop();phase='result';renderSummary();}
 function close(){if(['question','answer'].includes(phase))try{window.BetaCloud?.endSession({score:0,combo:0,correct:results.filter(r=>r.ok).length,wrong:results.filter(r=>!r.ok).length,reason:'exit'});}catch{}stop();phase='setup';dialog.close();$('sentence-card').focus();}
 body.addEventListener('change',e=>{if(e.target.id==='sentence-level'&&phase==='setup'){level=e.target.value;HSK.select(level);}});
 body.addEventListener('click',e=>{const a=e.target.closest('[data-sentence]')?.dataset.sentence;if(!a)return;if(a.startsWith('answer-'))return answer(+a.slice(7));if(a==='start')begin();if(a==='review')begin(true);if(a==='setup')setup();if(a==='close')close();if(a==='continue')next();if(a==='pause')pause();if(a==='resume')resume();if(a==='voice'){const q=queue[index];if(q){if(phase==='answer')pause();say(phase==='answer'?q.full:q.type==='fill'?q.prompt.replace('___','什么'):q.prompt);}}if(a==='retry'&&phase==='result'){queue=shuffle(results.filter(r=>!r.ok).map(r=>r.q));if(!queue.length)return;index=0;results=[];try{window.BetaCloud?.startSession('sentence-review',level==='mix'?null:+level);}catch{}show();}});
 UI.onChange(()=>{if(!dialog.open)return;if(phase==='question')renderQuestion();else if(phase==='answer')renderAnswer();else if(phase==='result')renderSummary();else{level=$('sentence-level').value;const enabled=$('sentence-pinyin').checked;setup();$('sentence-pinyin').checked=enabled;}});
 $('sentence-close').onclick=close;dialog.addEventListener('cancel',e=>{e.preventDefault();close();});document.addEventListener('visibilitychange',()=>{if(document.hidden&&dialog.open)pause();});document.addEventListener('keydown',e=>{if(!dialog.open||e.repeat||['INPUT','SELECT','TEXTAREA'].includes(e.target.tagName))return;if(/^[1-4]$/.test(e.key)){e.preventDefault();answer(+e.key-1);}});$('sentence-card').onclick=()=>open();
 return {open};
})();
