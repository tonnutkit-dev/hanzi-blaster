'use strict';
// The existing #level change event owns settings persistence and Home synchronization.
const HSK=(()=>{
 const normalize=value=>value==='mix'?'all':['1','2','3','4','5','all'].includes(String(value))?String(value):'1';
 function select(value){const el=document.getElementById('level');el.value=normalize(value);el.dispatchEvent(new Event('change',{bubbles:true}));}
 function scope(){return {level:normalize(document.getElementById('level').value),cumulative:document.getElementById('mode').value==='endless'&&!!document.getElementById('endless-prerequisites')?.checked};}
 function label(level,cumulative=false){level=normalize(level);return level==='all'?UI.t('ผสม · HSK 1–5'):cumulative&&level!=='1'?UI.t('สะสมถึง HSK')+' '+level:'HSK '+level;}
 return {normalize,select,scope,label};
})();
// Learning speech is independent of arcade FX. Only one utterance owns callbacks.
const LearningAudio=(()=>{
 let epoch=0;
 function cancel(){epoch++;window.HanziAudio?.speech(false);try{window.speechSynthesis?.cancel();}catch{}}
 function speak(text,end=()=>{},error=()=>{},rate=.8){
  cancel();const token=epoch;let settled=false;
  const settle=(ok,event)=>{if(token!==epoch||settled)return;settled=true;window.HanziAudio?.speech(false);(ok?end:error)(event);};
  if(!window.speechSynthesis||typeof SpeechSynthesisUtterance==='undefined'){settle(false,{error:'unavailable'});return;}
  try{const u=new SpeechSynthesisUtterance(text);u.lang='zh-CN';u.rate=rate;const voices=window.speechSynthesis.getVoices?.()||[];u.voice=voices.find(v=>/^zh[-_](CN|Hans)/i.test(v.lang))||voices.find(v=>/^zh/i.test(v.lang))||null;u.onend=()=>settle(true);u.onerror=e=>settle(false,e||{error:'unknown'});window.HanziAudio?.speech(true);window.speechSynthesis.speak(u);}catch{settle(false,{error:'unavailable'});}
 }
 // One timer, two conditions: reading minimum AND speech completion + a short beat.
 function feedback({text,min,buffer=250,advance,valid=()=>true,onHold=()=>{},onError=()=>{}}){
  let live=true,paused=false,timer=null,done=false,readyAt=0,remaining=min;
  const started=performance.now();let minimum=started+min;
  const limit=started+Math.min(60000,Math.max(15000,[...text].length*1500+5000));
  const validNow=()=>live&&!paused&&valid();
  function check(){
   if(!validNow())return;clearTimeout(timer);timer=null;const now=performance.now();
   if(!done&&now>=limit){if(window.speechSynthesis?.speaking){live=false;onHold();return;}done=true;readyAt=now;}
   if(done&&now>=Math.max(minimum,readyAt)){live=false;advance();return;}
   const due=done?Math.max(minimum,readyAt):now<minimum?Math.min(minimum,limit):limit;
   timer=setTimeout(check,Math.max(0,due-now));
  }
  const gate={cancel(){live=false;clearTimeout(timer);cancel();},pause(){if(!live)return;remaining=Math.max(0,minimum-performance.now());paused=true;clearTimeout(timer);cancel();},resume(){if(!live||!paused)return;paused=false;done=true;minimum=performance.now()+Math.max(remaining,500);readyAt=0;check();}};
  check();speak(text,()=>{if(!validNow())return;done=true;readyAt=performance.now()+buffer;check();},()=>{if(!validNow())return;done=true;readyAt=performance.now();onError();check();});return gate;
 }
 return {speak,cancel,feedback};
})();
// One persisted preference, shared by every gameplay renderer.
const Pinyin=(()=>{
 const key='hanzi-pinyin-v1';let enabled=true;
 try{const value=localStorage.getItem(key);if(value!==null)enabled=value==='true';}catch{}
 const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 function set(value){enabled=!!value;try{localStorage.setItem(key,String(enabled));}catch{}for(const id of ['pinyin','sentence-pinyin','home-pinyin']){const el=document.getElementById(id);if(el)el.checked=enabled;}document.getElementById('field')?.classList.toggle('no-pinyin',!enabled);}
 function html(py,cls='pinyin'){return enabled&&py?`<span class="${cls}" lang="zh-Latn">${esc(py)}</span>`:'';}
 set(enabled);return {get enabled(){return enabled},set,html,inline:py=>enabled&&py?' ('+py+')':''};
})();
