'use strict';
// Central TH/EN catalog plus a legacy DOM adapter. No network translation.
const UI=(()=>{
 const key='hanzi-ui-language-v1';let language=typeof navigator==='undefined'||/^th/i.test(navigator.language||'th')?'th':'en';
 try{const saved=localStorage.getItem(key);if(['th','en'].includes(saved))language=saved;}catch{}
 const messages=typeof UI_MESSAGES==='undefined'?{}:UI_MESSAGES;
 const keys=Object.keys(messages).filter(k=>k.length>=8).sort((a,b)=>b.length-a.length);
 const pattern=keys.length?new RegExp(keys.map(k=>k.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|'),'g'):null;
 function t(text){if(language==='th')return text;const raw=String(text),trim=raw.trim();if(!/[ก-๙]/.test(raw))return raw;if(messages[trim])return raw.replace(trim,messages[trim]);let out=pattern?raw.replace(pattern,k=>messages[k]):raw;
 const fragments={'ฟอง':'bubbles','วินาที':'seconds','จบรอบ':'Finished','ฝึกจำ':'Practice','คะแนน':'points','รายการ':'entries','ด่าน':'missions','เพิ่ม':'additional','คัดสรร':'selected','ผสม':'mixed','คำตอบ':'answers','ตอบไปแล้ว':'Answered','ข้อ':'questions','คำ':'words','คู่':'pairs','ด่านที่เลือก:':'Selected pool:','วงคำ':'Word pool','ฝึก':'Practiced','เริ่มแม่นเพิ่ม':'Newly familiar','แก้คำที่พลาดได้':'Recovered','ยังไม่แม่น':'Weak','ถึงเวลาทบทวน':'Due for review','เหลือ':'left','ถูกติดกัน':'Correct streak','อีก':'more','ชาร์จเต็มได้คะแนน':'Fully charged: score','ตอบผิดสิ้นสุดพลัง':'A mistake ends the boost','ถัดไป':'Next','ความคืบหน้าคำศัพท์ที่ตอบแล้วจะยังอยู่':'Answered word progress will be kept','รอบวน':'Deck cycle','พบ':'Seen','ทบทวนคำที่ยังไม่แม่น':'Reviewing weak words','ภาค':'Term','ผ่าน':'Completed','จาก':'of'};
 // Only whole UI fragments bounded by whitespace, punctuation or digits.
 for(const [th,en] of Object.entries(fragments))out=out.replace(new RegExp('(^|[\\s·:()/0-9])'+th+'(?=$|[\\s·:()/0-9])','g'),(_,lead)=>lead+en+' ');
 return out;
 }
 const originals=new WeakMap(),attributes=new WeakMap(),subscribers=new Set();
 const skip='script,style,input,textarea,[data-learning],#prompt-pinyin,#targets,#match-left,#match-right,.sentence-options,.sentence-zh,.sentence-py,.pinyin,.combat-pinyin,[lang="zh-CN"],[lang="zh-Latn"]';
 function translateNode(node){if(!node?.parentElement||node.parentElement.closest(skip))return;const previous=originals.get(node);const source=previous&&node.nodeValue===previous.output?previous.source:node.nodeValue;const output=t(source);originals.set(node,{source,output});if(node.nodeValue!==output)node.nodeValue=output;}
 function apply(root=document.body){if(!document.createTreeWalker||!root)return; if(root.nodeType===3){translateNode(root);return;}if(root.nodeType!==1)return;const walker=document.createTreeWalker(root,4);let n;while(n=walker.nextNode())translateNode(n);for(const el of [root,...root.querySelectorAll('[aria-label],[title],[placeholder]')]){if(el.closest?.('[data-learning]'))continue;let saved=attributes.get(el)||{};for(const a of ['aria-label','title','placeholder']){const value=el.getAttribute?.(a);if(value===null||value===undefined)continue;const before=saved[a];const source=before&&value===before.output?before.source:value;const output=t(source);saved[a]={source,output};if(output!==value)el.setAttribute(a,output);}attributes.set(el,saved);}}
 function set(next){if(!['th','en'].includes(next))return;language=next;try{localStorage.setItem(key,next);}catch{}if(document.documentElement)document.documentElement.lang=next;const select=document.getElementById('ui-language');if(select)select.value=next;apply();for(const refresh of subscribers)refresh();}
 function onChange(refresh){subscribers.add(refresh);return ()=>subscribers.delete(refresh);}
 function meaning(w){return language==='en'&&w.english?w.english:w.th;}
 function sentenceMeaning(q){return language==='en'?q.english:q.meaning;}
 function content(text){if(language==='th'||typeof SENTENCES==='undefined')return text;const q=SENTENCES.find(q=>q.meaning===text);return q?.english||text;}
 function boot(){const select=document.getElementById('ui-language');if(select){select.value=language;select.addEventListener('change',()=>set(select.value));}set(language);if(typeof MutationObserver!=='undefined')new MutationObserver(records=>{for(const r of records){if(r.type==='characterData')translateNode(r.target);else for(const node of r.addedNodes)apply(node);}}).observe(document.body,{childList:true,subtree:true,characterData:true});}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
 return {get language(){return language},t,set,onChange,apply,meaning,sentenceMeaning,content};
})();
